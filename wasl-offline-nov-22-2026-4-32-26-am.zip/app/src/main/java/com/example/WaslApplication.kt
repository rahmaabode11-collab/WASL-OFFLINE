package com.example

import android.app.Application
import com.example.crypto.KeystoreManager
import com.example.crypto.LocalStorageCipher
import com.example.data.local.PreferencesRepository
import com.example.data.local.WaslDatabase
import com.example.media.MediaFileManager
import com.example.media.VoiceRecorderManager
import com.example.mesh.MeshEngine

class WaslApplication : Application() {

    val database: WaslDatabase by lazy { WaslDatabase.getInstance(this) }
    val keystoreManager: KeystoreManager by lazy { KeystoreManager(this) }
    val localStorageCipher: LocalStorageCipher by lazy {
        LocalStorageCipher { keystoreManager.getOrCreateLocalStorageKey() }
    }
    val preferencesRepository: PreferencesRepository by lazy { PreferencesRepository(this) }
    val mediaFileManager: MediaFileManager by lazy { MediaFileManager(this) }
    val voiceRecorderManager: VoiceRecorderManager by lazy {
        VoiceRecorderManager(this, mediaFileManager)
    }
    val meshEngine: MeshEngine by lazy {
        MeshEngine(
            context = this,
            database = database,
            keystoreManager = keystoreManager,
            localCipher = localStorageCipher,
            prefsRepo = preferencesRepository,
            mediaFileManager = mediaFileManager
        )
    }
}
