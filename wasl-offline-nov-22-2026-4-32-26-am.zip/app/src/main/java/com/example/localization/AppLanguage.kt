package com.example.localization

enum class AppLanguage(val code: String, val nativeLabel: String) {
    ARABIC("ar", "العربية"),
    ENGLISH("en", "English");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            if (code == ENGLISH.code) ENGLISH else ARABIC
    }
}
