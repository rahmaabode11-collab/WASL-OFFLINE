package com.example.mesh

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class BleMeshTransport(
    private val context: Context,
    private val listener: TransportListener
) : MeshTransport {

    override val transportType: TransportType = TransportType.BLE

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? get() = bluetoothManager?.adapter

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var gattServer: BluetoothGattServer? = null

    private val discoveredDevices = ConcurrentHashMap<String, BluetoothDevice>()
    private val connectedGatts = ConcurrentHashMap<String, BluetoothGatt>()
    private val gattWriteChars = ConcurrentHashMap<String, BluetoothGattCharacteristic>()
    private val pendingWriteAcks = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val rxBuffers = ConcurrentHashMap<String, ByteArrayOutputStream>()
    private val rxExpectedSize = ConcurrentHashMap<String, Int>()

    @Volatile
    private var isStarted = false
    @Volatile
    private var batterySaverMode = true
    @Volatile
    private var localNodeId = ""

    override fun start(localNodeId: String, localDisplayName: String, batterySaver: Boolean) {
        if (isStarted) return
        val caps = DeviceCapabilityInspector.inspect(context).firstOrNull { it.type == TransportType.BLE }
        if (caps?.status != TechStatus.READY) {
            listener.onTransportStatusChanged(transportType, false, "BLE not ready: ${caps?.status}")
            return
        }
        this.localNodeId = localNodeId
        this.batterySaverMode = batterySaver
        isStarted = true

        try {
            startGattServer()
            startAdvertising(localNodeId)
            startScanning()
            listener.onTransportStatusChanged(transportType, true, "BLE GATT + Scanner active")
        } catch (sec: SecurityException) {
            isStarted = false
            listener.onTransportStatusChanged(transportType, false, sec.message ?: "BLE permission error")
        }
    }

    override fun stop() {
        isStarted = false
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            scanner?.stopScan(scanCallback)
            gattServer?.close()
            connectedGatts.values.forEach { it.close() }
        } catch (_: Exception) {
        }
        connectedGatts.keys.toList().forEach { addr ->
            listener.onPeerDisconnected(addr, transportType)
        }
        connectedGatts.clear()
        gattWriteChars.clear()
        discoveredDevices.clear()
        rxBuffers.clear()
        rxExpectedSize.clear()
        gattServer = null
        listener.onTransportStatusChanged(transportType, false, "BLE stopped")
    }

    override fun triggerScan() {
        if (!isStarted) return
        try {
            scanner?.stopScan(scanCallback)
            startScanning()
        } catch (_: Exception) {
        }
    }

    override suspend fun sendPacket(endpointKey: String, data: ByteArray): Boolean {
        val gatt = connectedGatts[endpointKey] ?: return false
        val char = gattWriteChars[endpointKey] ?: return false
        // Frame: [4-byte total length][payload] split into 180-byte BLE chunks
        val framed = ByteBuffer.allocate(4 + data.size).putInt(data.size).put(data).array()
        val chunkSize = 180
        var offset = 0
        while (offset < framed.size) {
            val end = minOf(offset + chunkSize, framed.size)
            val chunk = framed.copyOfRange(offset, end)
            val ack = CompletableDeferred<Boolean>()
            pendingWriteAcks[endpointKey] = ack
            @Suppress("DEPRECATION")
            char.value = chunk
            @Suppress("DEPRECATION")
            val initiated = gatt.writeCharacteristic(char)
            if (!initiated) {
                pendingWriteAcks.remove(endpointKey)
                return false
            }
            val ok = withTimeoutOrNull(3000L) { ack.await() } ?: false
            pendingWriteAcks.remove(endpointKey)
            if (!ok) return false
            offset = end
        }
        return true
    }

    override suspend fun broadcastPacket(data: ByteArray): Int {
        var count = 0
        for (addr in connectedGatts.keys.toList()) {
            if (sendPacket(addr, data)) count++
        }
        return count
    }

    override fun connectedEndpointKeys(): List<String> = connectedGatts.keys.toList()

    private fun startGattServer() {
        val manager = bluetoothManager ?: return
        gattServer = manager.openGattServer(context, gattServerCallback)
        val service = BluetoothGattService(WASL_SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val packetChar = BluetoothGattCharacteristic(
            WASL_PACKET_CHAR_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        service.addCharacteristic(packetChar)
        gattServer?.addService(service)
    }

    private fun startAdvertising(nodeId: String) {
        val btAdapter = adapter ?: return
        advertiser = btAdapter.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(
                if (batterySaverMode) AdvertiseSettings.ADVERTISE_MODE_LOW_POWER
                else AdvertiseSettings.ADVERTISE_MODE_BALANCED
            )
            .setConnectable(true)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(WASL_SERVICE_UUID))
            .addServiceData(ParcelUuid(WASL_SERVICE_UUID), nodeId.take(12).toByteArray(Charsets.UTF_8))
            .build()
        advertiser?.startAdvertising(settings, data, advertiseCallback)
    }

    private fun startScanning() {
        val btAdapter = adapter ?: return
        scanner = btAdapter.bluetoothLeScanner ?: return
        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(WASL_SERVICE_UUID))
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(
                if (batterySaverMode) ScanSettings.SCAN_MODE_LOW_POWER
                else ScanSettings.SCAN_MODE_BALANCED
            )
            .build()
        scanner?.startScan(listOf(filter), settings, scanCallback)
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartFailure(errorCode: Int) {
            listener.onTransportStatusChanged(transportType, isStarted, "BLE Adv error $errorCode")
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val addr = device.address ?: return
            val rawNodeBytes = result.scanRecord?.getServiceData(ParcelUuid(WASL_SERVICE_UUID))
            val remoteNodeId = rawNodeBytes?.let { String(it, Charsets.UTF_8) }?.takeIf { it.startsWith("WSL-") }
            discoveredDevices[addr] = device

            listener.onPeerDiscovered(
                LivePeerLink(
                    endpointKey = addr,
                    nodeId = remoteNodeId,
                    displayName = remoteNodeId ?: (device.name ?: addr),
                    transport = transportType,
                    isConnected = connectedGatts.containsKey(addr),
                    rssiDbm = result.rssi
                )
            )

            if (!connectedGatts.containsKey(addr) && (remoteNodeId == null || localNodeId < remoteNodeId)) {
                connectGattClient(device)
            }
        }
    }

    private fun connectGattClient(device: BluetoothDevice) {
        val addr = device.address ?: return
        if (connectedGatts.containsKey(addr)) return
        device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    connectedGatts[addr] = gatt
                    gatt.requestMtu(247)
                    scope.launch {
                        delay(250)
                        gatt.discoverServices()
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connectedGatts.remove(addr)
                    gattWriteChars.remove(addr)
                    pendingWriteAcks.remove(addr)?.complete(false)
                    gatt.close()
                    listener.onPeerDisconnected(addr, transportType)
                }
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    val char = gatt.getService(WASL_SERVICE_UUID)?.getCharacteristic(WASL_PACKET_CHAR_UUID)
                    if (char != null) {
                        gattWriteChars[addr] = char
                        listener.onPeerConnected(
                            LivePeerLink(
                                endpointKey = addr,
                                nodeId = null,
                                displayName = device.name ?: addr,
                                transport = transportType,
                                isConnected = true
                            )
                        )
                    }
                }
            }

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {
                pendingWriteAcks[addr]?.complete(status == BluetoothGatt.GATT_SUCCESS)
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            val addr = device.address ?: return
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                rxBuffers.remove(addr)
                rxExpectedSize.remove(addr)
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray?
        ) {
            val addr = device.address ?: return
            if (value != null && characteristic.uuid == WASL_PACKET_CHAR_UUID) {
                handleIncomingChunk(addr, value)
            }
            if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
            }
        }
    }

    private fun handleIncomingChunk(addr: String, chunk: ByteArray) {
        val buf = rxBuffers.getOrPut(addr) { ByteArrayOutputStream() }
        val expected = rxExpectedSize[addr]
        if (expected == null && buf.size() == 0 && chunk.size >= 4) {
            val totalLen = ByteBuffer.wrap(chunk, 0, 4).int
            if (totalLen in 1..MAX_BLE_PACKET_BYTES) {
                rxExpectedSize[addr] = totalLen
                buf.write(chunk, 4, chunk.size - 4)
            }
        } else if (expected != null) {
            buf.write(chunk)
        }
        val target = rxExpectedSize[addr] ?: return
        if (buf.size() >= target) {
            val fullBytes = buf.toByteArray().copyOf(target)
            rxBuffers.remove(addr)
            rxExpectedSize.remove(addr)
            listener.onPacketReceived(addr, transportType, fullBytes)
        }
    }

    companion object {
        val WASL_SERVICE_UUID: UUID = UUID.fromString("00005741-0000-1000-8000-00805F9B34FB")
        val WASL_PACKET_CHAR_UUID: UUID = UUID.fromString("00005742-0000-1000-8000-00805F9B34FB")
        private const val MAX_BLE_PACKET_BYTES = 131_072
    }
}
