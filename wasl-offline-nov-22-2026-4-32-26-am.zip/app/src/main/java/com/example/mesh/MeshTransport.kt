package com.example.mesh

import java.io.File

interface TransportListener {
    fun onPeerDiscovered(link: LivePeerLink)
    fun onPeerConnected(link: LivePeerLink)
    fun onPeerDisconnected(endpointKey: String, transport: TransportType)
    fun onPacketReceived(fromEndpointKey: String, transport: TransportType, bytes: ByteArray)
    fun onFileReceived(fromEndpointKey: String, transport: TransportType, file: File)
    fun onTransportStatusChanged(transport: TransportType, active: Boolean, note: String)
}

interface MeshTransport {
    val transportType: TransportType
    fun start(localNodeId: String, localDisplayName: String, batterySaver: Boolean)
    fun stop()
    fun triggerScan()
    suspend fun sendPacket(endpointKey: String, data: ByteArray): Boolean
    suspend fun broadcastPacket(data: ByteArray): Int
    suspend fun sendFile(endpointKey: String, file: File): Boolean = false
    fun connectedEndpointKeys(): List<String>
}
