package com.example.mesh

import android.content.Context
import android.os.ParcelFileDescriptor
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

class NearbyConnectionsTransport(
    private val context: Context,
    private val listener: TransportListener
) : MeshTransport {

    override val transportType: TransportType = TransportType.NEARBY_CONNECTIONS

    private val client: ConnectionsClient by lazy { Nearby.getConnectionsClient(context) }
    private val discoveredNames = ConcurrentHashMap<String, String>()
    private val connectedEndpoints = ConcurrentHashMap<String, LivePeerLink>()
    private val pendingOutgoing = ConcurrentHashMap.newKeySet<String>()
    private val incomingFiles = ConcurrentHashMap<Long, Payload>()

    @Volatile
    private var localEndpointName: String = ""

    @Volatile
    private var localNodeId: String = ""

    @Volatile
    private var isStarted: Boolean = false

    override fun start(localNodeId: String, localDisplayName: String, batterySaver: Boolean) {
        if (isStarted) return
        val caps = DeviceCapabilityInspector.inspect(context)
            .firstOrNull { it.type == TransportType.NEARBY_CONNECTIONS }
        if (caps?.status != TechStatus.READY) {
            listener.onTransportStatusChanged(transportType, false, "Nearby not ready: ${caps?.status}")
            return
        }
        this.localNodeId = localNodeId
        this.localEndpointName = "$localNodeId|$localDisplayName"
        isStarted = true
        startAdvertising()
        startDiscovery()
    }

    override fun stop() {
        isStarted = false
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {
        }
        connectedEndpoints.keys.toList().forEach { key ->
            listener.onPeerDisconnected(key, transportType)
        }
        connectedEndpoints.clear()
        discoveredNames.clear()
        pendingOutgoing.clear()
        incomingFiles.clear()
        listener.onTransportStatusChanged(transportType, false, "Stopped")
    }

    override fun triggerScan() {
        if (!isStarted) return
        try {
            client.stopDiscovery()
            startDiscovery()
        } catch (_: Exception) {
        }
    }

    override suspend fun sendPacket(endpointKey: String, data: ByteArray): Boolean {
        if (!connectedEndpoints.containsKey(endpointKey)) return false
        return awaitTaskSuccess(client.sendPayload(endpointKey, Payload.fromBytes(data)))
    }

    override suspend fun broadcastPacket(data: ByteArray): Int {
        val targets = connectedEndpoints.keys.toList()
        var sent = 0
        for (ep in targets) {
            if (sendPacket(ep, data)) sent++
        }
        return sent
    }

    override suspend fun sendFile(endpointKey: String, file: File): Boolean {
        if (!connectedEndpoints.containsKey(endpointKey) || !file.exists()) return false
        return try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val payload = Payload.fromFile(pfd)
            awaitTaskSuccess(client.sendPayload(endpointKey, payload))
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun awaitTaskSuccess(task: Task<Void>): Boolean =
        suspendCancellableCoroutine { cont ->
            task.addOnSuccessListener {
                if (cont.isActive) cont.resume(true)
            }.addOnFailureListener {
                if (cont.isActive) cont.resume(false)
            }
        }

    override fun connectedEndpointKeys(): List<String> = connectedEndpoints.keys.toList()

    private fun startAdvertising() {
        val options = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()
        client.startAdvertising(
            localEndpointName,
            SERVICE_ID,
            connectionLifecycleCallback,
            options
        ).addOnSuccessListener {
            listener.onTransportStatusChanged(transportType, true, "Advertising P2P_CLUSTER")
        }.addOnFailureListener { err ->
            listener.onTransportStatusChanged(transportType, false, err.message ?: "Advertise failed")
        }
    }

    private fun startDiscovery() {
        val options = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()
        client.startDiscovery(
            SERVICE_ID,
            endpointDiscoveryCallback,
            options
        ).addOnFailureListener { err ->
            listener.onTransportStatusChanged(transportType, false, err.message ?: "Discovery failed")
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val rawName = info.endpointName
            if (!rawName.startsWith("WSL-")) return
            discoveredNames[endpointId] = rawName
            val (remoteNodeId, remoteName) = parseEndpointName(rawName)
            listener.onPeerDiscovered(
                LivePeerLink(
                    endpointKey = endpointId,
                    nodeId = remoteNodeId,
                    displayName = remoteName,
                    transport = transportType,
                    isConnected = connectedEndpoints.containsKey(endpointId)
                )
            )
            // Deterministic tie-breaker prevents dual-request collision
            if (!connectedEndpoints.containsKey(endpointId) &&
                !pendingOutgoing.contains(endpointId) &&
                localNodeId < remoteNodeId
            ) {
                pendingOutgoing.add(endpointId)
                client.requestConnection(localEndpointName, endpointId, connectionLifecycleCallback)
                    .addOnFailureListener { pendingOutgoing.remove(endpointId) }
            }
        }

        override fun onEndpointLost(endpointId: String) {
            discoveredNames.remove(endpointId)
            pendingOutgoing.remove(endpointId)
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            discoveredNames[endpointId] = info.endpointName
            if (info.endpointName.startsWith("WSL-")) {
                client.acceptConnection(endpointId, payloadCallback)
            } else {
                client.rejectConnection(endpointId)
            }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            pendingOutgoing.remove(endpointId)
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                val rawName = discoveredNames[endpointId] ?: "WSL-PEER|Peer"
                val (remoteNodeId, remoteName) = parseEndpointName(rawName)
                val link = LivePeerLink(
                    endpointKey = endpointId,
                    nodeId = remoteNodeId,
                    displayName = remoteName,
                    transport = transportType,
                    isConnected = true
                )
                connectedEndpoints[endpointId] = link
                listener.onPeerConnected(link)
            }
        }

        override fun onDisconnected(endpointId: String) {
            connectedEndpoints.remove(endpointId)
            pendingOutgoing.remove(endpointId)
            listener.onPeerDisconnected(endpointId, transportType)
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    payload.asBytes()?.let { bytes ->
                        listener.onPacketReceived(endpointId, transportType, bytes)
                    }
                }
                Payload.Type.FILE -> {
                    incomingFiles[payload.id] = payload
                }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                val payload = incomingFiles.remove(update.payloadId) ?: return
                val pFile = payload.asFile()?.asJavaFile()
                if (pFile != null && pFile.exists()) {
                    listener.onFileReceived(endpointId, transportType, pFile)
                }
            } else if (update.status == PayloadTransferUpdate.Status.FAILURE ||
                update.status == PayloadTransferUpdate.Status.CANCELED
            ) {
                incomingFiles.remove(update.payloadId)
            }
        }
    }

    private fun parseEndpointName(raw: String): Pair<String, String> {
        val parts = raw.split("|", limit = 2)
        val nodeId = parts.firstOrNull().orEmpty().ifBlank { "WSL-UNKNOWN" }
        val name = parts.getOrNull(1).orEmpty().ifBlank { nodeId }
        return nodeId to name
    }

    companion object {
        private const val SERVICE_ID = "com.example.wasl.mesh.v1"
    }
}
