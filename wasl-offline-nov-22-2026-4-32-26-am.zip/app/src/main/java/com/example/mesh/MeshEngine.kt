package com.example.mesh

import android.content.Context
import com.example.crypto.CryptoManager
import com.example.crypto.DeviceIdentityKeys
import com.example.crypto.KeystoreManager
import com.example.crypto.LocalStorageCipher
import com.example.data.local.ContactEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.GroupEntity
import com.example.data.local.MessageEntity
import com.example.data.local.MessageType
import com.example.data.local.NotificationEntity
import com.example.data.local.NotificationType
import com.example.data.local.PacketQueueStatus
import com.example.data.local.PendingPacketEntity
import com.example.data.local.PreferencesRepository
import com.example.data.local.RelationshipStatus
import com.example.data.local.SeenPacketEntity
import com.example.data.local.UserSettings
import com.example.data.local.WaslDatabase
import com.example.localization.AppLanguage
import com.example.media.MediaFileManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.spec.SecretKeySpec

class MeshEngine(
    private val context: Context,
    private val database: WaslDatabase,
    private val keystoreManager: KeystoreManager,
    private val localCipher: LocalStorageCipher,
    private val prefsRepo: PreferencesRepository,
    val mediaFileManager: MediaFileManager
) : TransportListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val moshi: Moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val stringListAdapter = moshi.adapter<List<String>>(
        Types.newParameterizedType(List::class.java, String::class.java)
    )
    private val chatAdapter = moshi.adapter(InnerChatPayload::class.java)
    private val groupInviteAdapter = moshi.adapter(InnerGroupInvite::class.java)
    private val ackAdapter = moshi.adapter(InnerAckPayload::class.java)
    private val announceAdapter = moshi.adapter(InnerAnnouncePayload::class.java)
    private val mediaChunkAdapter = moshi.adapter(InnerMediaChunk::class.java)

    private var identity: DeviceIdentityKeys = keystoreManager.getOrCreateIdentity()
    private var router: MeshRouter = MeshRouter(identity)

    private val nearbyTransport = NearbyConnectionsTransport(context, this)
    private val bleTransport = BleMeshTransport(context, this)
    private val classicTransport = BluetoothClassicTransport(context, this)
    private val wifiDirectTransport = WifiDirectTransport(context, this)
    private val transports: List<MeshTransport> = listOf(
        nearbyTransport,
        wifiDirectTransport,
        classicTransport,
        bleTransport
    )

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _livePeers = MutableStateFlow<Map<String, LivePeerLink>>(emptyMap())
    val livePeers: StateFlow<Map<String, LivePeerLink>> = _livePeers.asStateFlow()

    private val _transportStates = MutableStateFlow<Map<TransportType, Pair<Boolean, String>>>(emptyMap())
    val transportStates: StateFlow<Map<TransportType, Pair<Boolean, String>>> = _transportStates.asStateFlow()

    private val _capabilities = MutableStateFlow<List<TechnologyCapability>>(emptyList())
    val capabilities: StateFlow<List<TechnologyCapability>> = _capabilities.asStateFlow()

    private val _activeRelayPeers = MutableStateFlow<Set<String>>(emptySet())
    val activeRelayPeers: StateFlow<Set<String>> = _activeRelayPeers.asStateFlow()

    private val chunkReassembly = ConcurrentHashMap<String, ConcurrentHashMap<Int, ByteArray>>()
    private val chunkMetadata = ConcurrentHashMap<String, InnerMediaChunk>()

    private var periodicJob: Job? = null

    fun currentIdentity(): DeviceIdentityKeys = identity

    fun refreshCapabilities() {
        _capabilities.value = DeviceCapabilityInspector.inspect(context)
    }

    fun startMesh() {
        refreshCapabilities()
        if (_isRunning.value) return
        _isRunning.value = true
        scope.launch {
            val settings = prefsRepo.settingsFlow.first()
            val name = settings.displayName.ifBlank { identity.nodeId }
            transports.forEach { it.start(identity.nodeId, name, settings.batterySaverScan) }
            startPeriodicLoop()
            broadcastNodeAnnounce(settings)
        }
    }

    fun stopMesh() {
        _isRunning.value = false
        periodicJob?.cancel()
        transports.forEach { it.stop() }
        _livePeers.value = emptyMap()
        _activeRelayPeers.value = emptySet()
        scope.launch {
            database.contactDao().clearAllDirectConnections()
        }
    }

    fun triggerImmediateScan() {
        refreshCapabilities()
        if (!_isRunning.value) {
            startMesh()
            return
        }
        transports.forEach { it.triggerScan() }
        scope.launch {
            val settings = prefsRepo.settingsFlow.first()
            broadcastNodeAnnounce(settings)
            flushPendingPackets()
        }
    }

    fun rotateIdentityKeys() {
        val wasRunning = _isRunning.value
        if (wasRunning) stopMesh()
        identity = keystoreManager.rotateIdentity()
        router = MeshRouter(identity)
        if (wasRunning) startMesh()
    }

    private fun startPeriodicLoop() {
        periodicJob?.cancel()
        periodicJob = scope.launch {
            while (isActive && _isRunning.value) {
                val settings = prefsRepo.settingsFlow.first()
                refreshCapabilities()
                sweepExpiredPackets(settings.language)
                flushPendingPackets()
                broadcastNodeAnnounce(settings)
                delay(if (settings.batterySaverScan) 45_000L else 20_000L)
            }
        }
    }

    suspend fun sendContactRequest(targetNodeId: String) {
        val settings = prefsRepo.settingsFlow.first()
        val contact = database.contactDao().getById(targetNodeId) ?: return
        database.contactDao().updateRelationship(targetNodeId, RelationshipStatus.REQUEST_SENT.name)

        val now = System.currentTimeMillis()
        val payloadB64 = Base64.getEncoder().encodeToString(
            (settings.displayName.ifBlank { identity.nodeId }).toByteArray(Charsets.UTF_8)
        )
        val packet = router.signOutgoingPacket(
            MeshPacket(
                packetType = PacketType.CONTACT_REQUEST.name,
                originNodeId = identity.nodeId,
                destinationNodeId = targetNodeId,
                senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = settings.maxHops,
                createdAt = now,
                expiresAt = now + settings.messageTtlHours * 3600_000L,
                encryptedPayloadB64 = payloadB64
            )
        )
        router.markLocalSeen(packet.packetId, now)
        enqueueAndTransmit(packet, contact.nodeId)
    }

    suspend fun acceptContactRequest(targetNodeId: String) {
        val settings = prefsRepo.settingsFlow.first()
        val contact = database.contactDao().getById(targetNodeId) ?: return
        database.contactDao().updateRelationship(targetNodeId, RelationshipStatus.APPROVED.name)

        val convId = privateConversationId(targetNodeId)
        if (database.conversationDao().getById(convId) == null) {
            database.conversationDao().upsert(
                ConversationEntity(
                    conversationId = convId,
                    isGroup = false,
                    title = contact.displayName,
                    peerNodeId = targetNodeId,
                    lastMessageAt = System.currentTimeMillis()
                )
            )
        }

        val now = System.currentTimeMillis()
        val packet = router.signOutgoingPacket(
            MeshPacket(
                packetType = PacketType.CONTACT_ACCEPT.name,
                originNodeId = identity.nodeId,
                destinationNodeId = targetNodeId,
                senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = settings.maxHops,
                createdAt = now,
                expiresAt = now + settings.messageTtlHours * 3600_000L,
                encryptedPayloadB64 = Base64.getEncoder().encodeToString("ACCEPT".toByteArray(Charsets.UTF_8))
            )
        )
        router.markLocalSeen(packet.packetId, now)
        enqueueAndTransmit(packet, targetNodeId)
    }

    suspend fun sendPrivateMessage(
        peerNodeId: String,
        text: String,
        messageType: MessageType = MessageType.TEXT,
        mediaFile: File? = null,
        mediaMimeType: String? = null,
        mediaFileName: String? = null
    ) {
        val contact = database.contactDao().getById(peerNodeId) ?: return
        if (contact.relationshipStatus == RelationshipStatus.BLOCKED.name) return
        val settings = prefsRepo.settingsFlow.first()
        val now = System.currentTimeMillis()
        val expiresAt = now + settings.messageTtlHours * 3600_000L
        val packetId = UUID.randomUUID().toString()
        val transferId = if (mediaFile != null) UUID.randomUUID().toString() else null

        val inner = InnerChatPayload(
            messageType = messageType.name,
            text = text,
            mediaFileName = mediaFileName ?: mediaFile?.name,
            mediaMimeType = mediaMimeType,
            mediaSizeBytes = mediaFile?.length() ?: 0L,
            mediaTransferId = transferId
        )
        val innerJsonBytes = chatAdapter.toJson(inner).toByteArray(Charsets.UTF_8)
        val encryptedB64 = CryptoManager.encryptForPeer(
            plaintext = innerJsonBytes,
            myEcdhPrivate = identity.ecdhPrivateKey,
            peerEcdhPublicB64 = contact.ecdhPubKeyB64
        )

        val packet = router.signOutgoingPacket(
            MeshPacket(
                packetId = packetId,
                packetType = PacketType.CHAT_MESSAGE.name,
                originNodeId = identity.nodeId,
                destinationNodeId = peerNodeId,
                senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = settings.maxHops,
                createdAt = now,
                expiresAt = expiresAt,
                encryptedPayloadB64 = encryptedB64
            )
        )

        val convId = privateConversationId(peerNodeId)
        val previewPlain = when (messageType) {
            MessageType.TEXT -> text
            MessageType.VOICE -> "🎤 Voice"
            MessageType.IMAGE -> "🖼 ${mediaFileName ?: "Photo"}"
            MessageType.VIDEO -> "🎬 ${mediaFileName ?: "Video"}"
            MessageType.FILE -> "📎 ${mediaFileName ?: "File"}"
        }
        val msgEntity = MessageEntity(
            packetId = packetId,
            conversationId = convId,
            senderNodeId = identity.nodeId,
            senderName = settings.displayName.ifBlank { identity.nodeId },
            messageType = messageType.name,
            contentEnc = localCipher.encryptText(text),
            mediaLocalPath = mediaFile?.absolutePath,
            mediaMimeType = mediaMimeType,
            mediaFileName = mediaFileName ?: mediaFile?.name,
            mediaSizeBytes = mediaFile?.length() ?: 0L,
            timestamp = now,
            expiresAt = expiresAt,
            deliveryStatus = DeliveryStatus.QUEUED.name,
            hopCount = 0,
            routePathJson = "[]",
            transportUsed = activeTransportSummary(),
            isOutgoing = true
        )
        database.messageDao().upsert(msgEntity)
        database.conversationDao().upsert(
            ConversationEntity(
                conversationId = convId,
                isGroup = false,
                title = contact.displayName,
                peerNodeId = peerNodeId,
                lastMessagePreviewEnc = localCipher.encryptText(previewPlain),
                lastMessageAt = now,
                unreadCount = 0
            )
        )

        router.markLocalSeen(packetId, now)
        val sentNow = enqueueAndTransmit(packet, peerNodeId)
        if (sentNow > 0) {
            database.messageDao().updateDelivery(
                packetId = packetId,
                status = DeliveryStatus.RELAYING.name,
                hopCount = 0,
                routePathJson = "[]",
                transportUsed = activeTransportSummary()
            )
        }

        if (mediaFile != null && transferId != null) {
            sendEncryptedMediaChunks(
                transferId = transferId,
                conversationId = convId,
                messagePacketId = packetId,
                destinationNodeId = peerNodeId,
                file = mediaFile,
                mimeType = mediaMimeType ?: "application/octet-stream",
                messageType = messageType,
                peerEcdhPubB64 = contact.ecdhPubKeyB64,
                groupKey = null,
                settings = settings
            )
        }
    }

    suspend fun createGroup(groupName: String, memberNodeIds: List<String>): String {
        val settings = prefsRepo.settingsFlow.first()
        val groupId = "GRP-${UUID.randomUUID().toString().take(8).uppercase()}"
        val groupKey = CryptoManager.generateAes256Key()
        val groupKeyB64 = Base64.getEncoder().encodeToString(groupKey.encoded)
        val allMembers = (memberNodeIds + identity.nodeId).distinct()

        val groupEntity = GroupEntity(
            groupId = groupId,
            name = groupName.trim(),
            creatorNodeId = identity.nodeId,
            groupKeyEnc = localCipher.encryptText(groupKeyB64),
            memberNodeIdsJson = stringListAdapter.toJson(allMembers),
            createdAt = System.currentTimeMillis()
        )
        database.groupDao().upsert(groupEntity)

        val convId = groupConversationId(groupId)
        database.conversationDao().upsert(
            ConversationEntity(
                conversationId = convId,
                isGroup = true,
                title = groupEntity.name,
                peerNodeId = null,
                lastMessagePreviewEnc = localCipher.encryptText(groupName),
                lastMessageAt = System.currentTimeMillis()
            )
        )

        // Distribute wrapped group key individually via E2EE to each member
        val now = System.currentTimeMillis()
        val invite = InnerGroupInvite(groupId, groupEntity.name, groupKeyB64, allMembers)
        val inviteBytes = groupInviteAdapter.toJson(invite).toByteArray(Charsets.UTF_8)
        for (memberId in memberNodeIds) {
            val contact = database.contactDao().getById(memberId) ?: continue
            val enc = CryptoManager.encryptForPeer(inviteBytes, identity.ecdhPrivateKey, contact.ecdhPubKeyB64)
            val pkt = router.signOutgoingPacket(
                MeshPacket(
                    packetType = PacketType.GROUP_INVITE.name,
                    originNodeId = identity.nodeId,
                    destinationNodeId = memberId,
                    senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                    senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                    senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                    hopCount = 0,
                    maxHops = settings.maxHops,
                    createdAt = now,
                    expiresAt = now + settings.messageTtlHours * 3600_000L,
                    encryptedPayloadB64 = enc
                )
            )
            router.markLocalSeen(pkt.packetId, now)
            enqueueAndTransmit(pkt, memberId)
        }
        return convId
    }

    suspend fun sendGroupMessage(
        groupId: String,
        text: String,
        messageType: MessageType = MessageType.TEXT,
        mediaFile: File? = null,
        mediaMimeType: String? = null,
        mediaFileName: String? = null
    ) {
        val group = database.groupDao().getById(groupId) ?: return
        val keyBytes = Base64.getDecoder().decode(localCipher.decryptText(group.groupKeyEnc))
        val groupKey = SecretKeySpec(keyBytes, "AES")
        val settings = prefsRepo.settingsFlow.first()
        val now = System.currentTimeMillis()
        val expiresAt = now + settings.messageTtlHours * 3600_000L
        val packetId = UUID.randomUUID().toString()
        val transferId = if (mediaFile != null) UUID.randomUUID().toString() else null

        val inner = InnerChatPayload(
            messageType = messageType.name,
            text = text,
            mediaFileName = mediaFileName ?: mediaFile?.name,
            mediaMimeType = mediaMimeType,
            mediaSizeBytes = mediaFile?.length() ?: 0L,
            mediaTransferId = transferId,
            groupId = groupId
        )
        val encryptedB64 = CryptoManager.encryptAesGcm(
            chatAdapter.toJson(inner).toByteArray(Charsets.UTF_8),
            groupKey
        )
        val dest = "${MeshRouter.GROUP_PREFIX}$groupId"
        val packet = router.signOutgoingPacket(
            MeshPacket(
                packetId = packetId,
                packetType = PacketType.GROUP_MESSAGE.name,
                originNodeId = identity.nodeId,
                destinationNodeId = dest,
                senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = settings.maxHops,
                createdAt = now,
                expiresAt = expiresAt,
                encryptedPayloadB64 = encryptedB64
            )
        )

        val convId = groupConversationId(groupId)
        database.messageDao().upsert(
            MessageEntity(
                packetId = packetId,
                conversationId = convId,
                senderNodeId = identity.nodeId,
                senderName = settings.displayName.ifBlank { identity.nodeId },
                messageType = messageType.name,
                contentEnc = localCipher.encryptText(text),
                mediaLocalPath = mediaFile?.absolutePath,
                mediaMimeType = mediaMimeType,
                mediaFileName = mediaFileName ?: mediaFile?.name,
                mediaSizeBytes = mediaFile?.length() ?: 0L,
                timestamp = now,
                expiresAt = expiresAt,
                deliveryStatus = DeliveryStatus.QUEUED.name,
                hopCount = 0,
                routePathJson = "[]",
                transportUsed = activeTransportSummary(),
                isOutgoing = true
            )
        )
        database.conversationDao().upsert(
            ConversationEntity(
                conversationId = convId,
                isGroup = true,
                title = group.name,
                lastMessagePreviewEnc = localCipher.encryptText(text.ifBlank { mediaFileName ?: messageType.name }),
                lastMessageAt = now
            )
        )
        router.markLocalSeen(packetId, now)
        val sentCount = enqueueAndTransmit(packet, dest)
        if (sentCount > 0) {
            database.messageDao().updateDelivery(
                packetId = packetId,
                status = DeliveryStatus.RELAYING.name,
                hopCount = 0,
                routePathJson = "[]",
                transportUsed = activeTransportSummary()
            )
        }

        if (mediaFile != null && transferId != null) {
            sendEncryptedMediaChunks(
                transferId = transferId,
                conversationId = convId,
                messagePacketId = packetId,
                destinationNodeId = dest,
                file = mediaFile,
                mimeType = mediaMimeType ?: "application/octet-stream",
                messageType = messageType,
                peerEcdhPubB64 = null,
                groupKey = groupKey,
                settings = settings
            )
        }
    }

    private suspend fun sendEncryptedMediaChunks(
        transferId: String,
        conversationId: String,
        messagePacketId: String,
        destinationNodeId: String,
        file: File,
        mimeType: String,
        messageType: MessageType,
        peerEcdhPubB64: String?,
        groupKey: SecretKeySpec?,
        settings: UserSettings
    ) {
        if (!file.exists()) return
        val bytes = file.readBytes()
        val chunkSize = 24_576
        val totalChunks = maxOf(1, (bytes.size + chunkSize - 1) / chunkSize)
        val now = System.currentTimeMillis()
        for (i in 0 until totalChunks) {
            val start = i * chunkSize
            val end = minOf(bytes.size, start + chunkSize)
            val slice = bytes.copyOfRange(start, end)
            val chunkObj = InnerMediaChunk(
                transferId = transferId,
                conversationId = conversationId,
                messagePacketId = messagePacketId,
                fileName = file.name,
                mimeType = mimeType,
                messageType = messageType.name,
                totalChunks = totalChunks,
                chunkIndex = i,
                chunkDataB64 = Base64.getEncoder().encodeToString(slice)
            )
            val chunkPlain = mediaChunkAdapter.toJson(chunkObj).toByteArray(Charsets.UTF_8)
            val encrypted = when {
                peerEcdhPubB64 != null -> CryptoManager.encryptForPeer(chunkPlain, identity.ecdhPrivateKey, peerEcdhPubB64)
                groupKey != null -> CryptoManager.encryptAesGcm(chunkPlain, groupKey)
                else -> return
            }
            val pkt = router.signOutgoingPacket(
                MeshPacket(
                    packetType = PacketType.MEDIA_CHUNK.name,
                    originNodeId = identity.nodeId,
                    destinationNodeId = destinationNodeId,
                    senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                    senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                    senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                    hopCount = 0,
                    maxHops = settings.maxHops,
                    createdAt = now,
                    expiresAt = now + settings.messageTtlHours * 3600_000L,
                    encryptedPayloadB64 = encrypted
                )
            )
            router.markLocalSeen(pkt.packetId, now)
            enqueueAndTransmit(pkt, destinationNodeId)
        }
    }

    private suspend fun enqueueAndTransmit(packet: MeshPacket, destination: String): Int {
        val raw = router.serializePacket(packet)
        database.pendingPacketDao().upsert(
            PendingPacketEntity(
                packetId = packet.packetId,
                destinationNodeId = destination,
                packetJson = String(raw, Charsets.UTF_8),
                hopCount = packet.hopCount,
                maxHops = packet.maxHops,
                createdAt = packet.createdAt,
                expiresAt = packet.expiresAt,
                status = PacketQueueStatus.PENDING.name
            )
        )
        return broadcastRawPacket(raw)
    }

    private suspend fun broadcastRawPacket(raw: ByteArray): Int {
        var total = 0
        for (transport in transports) {
            total += transport.broadcastPacket(raw)
        }
        return total
    }

    private suspend fun flushPendingPackets() {
        val now = System.currentTimeMillis()
        val pending = database.pendingPacketDao().getActivePendingPackets(now)
        if (pending.isEmpty()) return
        val hasConnectedPeers = _livePeers.value.values.any { it.isConnected }
        if (!hasConnectedPeers) return

        for (item in pending) {
            // Avoid hammering BLE/RFCOMM every tick; retry every 15s minimum
            if (now - item.lastAttemptAt < 15_000L) continue
            val sent = broadcastRawPacket(item.packetJson.toByteArray(Charsets.UTF_8))
            if (sent > 0) {
                database.pendingPacketDao().recordAttempt(item.packetId, now)
            }
        }
    }

    private suspend fun sweepExpiredPackets(lang: AppLanguage) {
        val now = System.currentTimeMillis()
        val expiring = database.pendingPacketDao().findNewlyExpiringPackets(now)
        if (expiring.isNotEmpty()) {
            database.pendingPacketDao().expireOldPackets(now)
            val expiredMsgs = database.messageDao().markExpiredMessages(now)
            if (expiredMsgs > 0) {
                val title = if (lang == AppLanguage.ARABIC) "انتهت صلاحية رسالة غير مسلّمة" else "Offline Message Expired"
                val body = if (lang == AppLanguage.ARABIC) {
                    "تعذّر تسليم $expiredMsgs رسالة قبل انتهاء المهلة. أضف هواتف وسيطة أو قرّب المسافة ثم أعد الإرسال."
                } else {
                    "$expiredMsgs message(s) expired before reaching a recipient. Additional intermediate relay phones may be needed."
                }
                database.notificationDao().insert(
                    NotificationEntity(
                        id = UUID.randomUUID().toString(),
                        type = NotificationType.MESSAGE_EXPIRED.name,
                        title = title,
                        body = body,
                        timestamp = now
                    )
                )
            }
        }
        database.seenPacketDao().pruneExpired(now)
    }

    private suspend fun broadcastNodeAnnounce(settings: UserSettings) {
        if (!_livePeers.value.values.any { it.isConnected }) return
        val now = System.currentTimeMillis()
        val announce = InnerAnnouncePayload(
            relayEnabled = settings.relayEnabled,
            supportedTransports = _capabilities.value.filter { it.status == TechStatus.READY }.map { it.type.wireName },
            knownDirectPeers = _livePeers.value.values.mapNotNull { it.nodeId }.distinct(),
            announcedAt = now
        )
        val payloadB64 = Base64.getEncoder().encodeToString(
            announceAdapter.toJson(announce).toByteArray(Charsets.UTF_8)
        )
        val packet = router.signOutgoingPacket(
            MeshPacket(
                packetType = PacketType.NODE_ANNOUNCE.name,
                originNodeId = identity.nodeId,
                destinationNodeId = MeshRouter.DESTINATION_BROADCAST,
                senderDisplayName = settings.displayName.ifBlank { identity.nodeId },
                senderSigningPubKeyB64 = identity.signingPublicKeyB64,
                senderEcdhPubKeyB64 = identity.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = 1,
                createdAt = now,
                expiresAt = now + 90_000L,
                encryptedPayloadB64 = payloadB64
            )
        )
        router.markLocalSeen(packet.packetId, now)
        broadcastRawPacket(router.serializePacket(packet))
    }

    override fun onPeerDiscovered(link: LivePeerLink) {
        val mapKey = "${link.transport.wireName}:${link.endpointKey}"
        _livePeers.value = _livePeers.value + (mapKey to link)
    }

    override fun onPeerConnected(link: LivePeerLink) {
        val mapKey = "${link.transport.wireName}:${link.endpointKey}"
        _livePeers.value = _livePeers.value + (mapKey to link)
        scope.launch {
            prefsRepo.recordSuccessfulConnection()
            val settings = prefsRepo.settingsFlow.first()
            broadcastNodeAnnounce(settings)
            flushPendingPackets()
        }
    }

    override fun onPeerDisconnected(endpointKey: String, transport: TransportType) {
        val mapKey = "${transport.wireName}:$endpointKey"
        val removed = _livePeers.value[mapKey]
        _livePeers.value = _livePeers.value - mapKey
        if (removed?.nodeId != null) {
            scope.launch {
                val stillConnected = _livePeers.value.values.any { it.nodeId == removed.nodeId && it.isConnected }
                if (!stillConnected) {
                    database.contactDao().updateLinkState(
                        nodeId = removed.nodeId,
                        connected = false,
                        seenAt = System.currentTimeMillis(),
                        transport = transport.wireName,
                        hops = 1,
                        rssi = null
                    )
                }
            }
        }
    }

    override fun onPacketReceived(fromEndpointKey: String, transport: TransportType, bytes: ByteArray) {
        scope.launch {
            val packet = router.deserializePacket(bytes) ?: return@launch
            val now = System.currentTimeMillis()
            val seenInDb = database.seenPacketDao().exists(packet.packetId)
            val existingContact = database.contactDao().getById(packet.originNodeId)
            val isBlocked = existingContact?.relationshipStatus == RelationshipStatus.BLOCKED.name
            val settings = prefsRepo.settingsFlow.first()
            val myGroupIds = database.groupDao().observeAllGroups().first().map { it.groupId }.toSet()

            val decision = router.evaluateIncomingPacket(
                packet = packet,
                now = now,
                alreadySeenInDb = seenInDb,
                isOriginBlocked = isBlocked,
                relayEnabled = settings.relayEnabled,
                localGroupIds = myGroupIds
            )

            when (decision) {
                is RouteDecision.DropDuplicateOrExpired,
                is RouteDecision.DropInvalidSignature,
                is RouteDecision.DropBlockedOrigin -> return@launch

                is RouteDecision.RelayOnly -> {
                    database.seenPacketDao().insertIgnore(SeenPacketEntity(packet.packetId, now, packet.expiresAt))
                    val forwardedBytes = router.serializePacket(decision.forwardedPacket)
                    database.pendingPacketDao().upsert(
                        PendingPacketEntity(
                            packetId = decision.forwardedPacket.packetId,
                            destinationNodeId = decision.forwardedPacket.destinationNodeId,
                            packetJson = String(forwardedBytes, Charsets.UTF_8),
                            hopCount = decision.forwardedPacket.hopCount,
                            maxHops = decision.forwardedPacket.maxHops,
                            createdAt = decision.forwardedPacket.createdAt,
                            expiresAt = decision.forwardedPacket.expiresAt
                        )
                    )
                    broadcastRawPacket(forwardedBytes)
                }

                is RouteDecision.DeliverLocally -> {
                    database.seenPacketDao().insertIgnore(SeenPacketEntity(packet.packetId, now, packet.expiresAt))
                    handleLocalDelivery(decision.packet, transport, fromEndpointKey, settings)
                    if (decision.shouldAlsoRelay && decision.forwardedPacket != null) {
                        broadcastRawPacket(router.serializePacket(decision.forwardedPacket))
                    }
                }
            }
        }
    }

    override fun onFileReceived(fromEndpointKey: String, transport: TransportType, file: File) {
        // Direct transport file payload saved as fallback local artifact if not chunked
        scope.launch {
            val settings = prefsRepo.settingsFlow.first()
            val title = if (settings.language == AppLanguage.ARABIC) "تم استلام ملف لاسلكياً" else "Offline File Received"
            database.notificationDao().insert(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    type = NotificationType.INCOMING_MESSAGE.name,
                    title = title,
                    body = "${file.name} (${transport.wireName})",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    override fun onTransportStatusChanged(transport: TransportType, active: Boolean, note: String) {
        _transportStates.value = _transportStates.value + (transport to (active to note))
    }

    private suspend fun handleLocalDelivery(
        packet: MeshPacket,
        transport: TransportType,
        fromEndpointKey: String,
        settings: UserSettings
    ) {
        val now = System.currentTimeMillis()
        val existingContact = database.contactDao().getById(packet.originNodeId)
        val isDirect = packet.hopCount == 0
        if (existingContact == null) {
            database.contactDao().upsert(
                ContactEntity(
                    nodeId = packet.originNodeId,
                    displayName = packet.senderDisplayName,
                    signingPubKeyB64 = packet.senderSigningPubKeyB64,
                    ecdhPubKeyB64 = packet.senderEcdhPubKeyB64,
                    fingerprint = CryptoManager.deriveFingerprint(packet.senderSigningPubKeyB64),
                    relationshipStatus = RelationshipStatus.DISCOVERED.name,
                    lastSeenAt = now,
                    lastTransport = transport.wireName,
                    isDirectlyConnected = isDirect,
                    hopDistance = packet.hopCount + 1
                )
            )
        } else {
            database.contactDao().upsert(
                existingContact.copy(
                    displayName = packet.senderDisplayName,
                    signingPubKeyB64 = packet.senderSigningPubKeyB64,
                    ecdhPubKeyB64 = packet.senderEcdhPubKeyB64,
                    lastSeenAt = now,
                    lastTransport = transport.wireName,
                    isDirectlyConnected = isDirect || existingContact.isDirectlyConnected,
                    hopDistance = minOf(existingContact.hopDistance, packet.hopCount + 1)
                )
            )
        }

        // Bind live link endpointKey -> nodeId if direct
        if (isDirect) {
            val mapKey = "${transport.wireName}:$fromEndpointKey"
            _livePeers.value[mapKey]?.let { link ->
                _livePeers.value = _livePeers.value + (mapKey to link.copy(
                    nodeId = packet.originNodeId,
                    displayName = packet.senderDisplayName
                ))
            }
        }

        when (PacketType.valueOf(packet.packetType)) {
            PacketType.NODE_ANNOUNCE -> {
                val json = String(Base64.getDecoder().decode(packet.encryptedPayloadB64), Charsets.UTF_8)
                val info = announceAdapter.fromJson(json)
                if (info?.relayEnabled == true) {
                    _activeRelayPeers.value = _activeRelayPeers.value + packet.originNodeId
                }
            }

            PacketType.CONTACT_REQUEST -> {
                if (existingContact?.relationshipStatus != RelationshipStatus.APPROVED.name) {
                    database.contactDao().updateRelationship(packet.originNodeId, RelationshipStatus.REQUEST_RECEIVED.name)
                    val title = if (settings.language == AppLanguage.ARABIC) "طلب تواصل جديد" else "New Contact Request"
                    val body = "${packet.senderDisplayName} (${packet.originNodeId})"
                    database.notificationDao().insert(
                        NotificationEntity(
                            id = UUID.randomUUID().toString(),
                            type = NotificationType.CONTACT_REQUEST.name,
                            title = title,
                            body = body,
                            relatedNodeId = packet.originNodeId,
                            timestamp = now
                        )
                    )
                    OfflineNotificationHelper.showOfflineAlert(context, packet.originNodeId.hashCode(), title, body)
                }
            }

            PacketType.CONTACT_ACCEPT -> {
                database.contactDao().updateRelationship(packet.originNodeId, RelationshipStatus.APPROVED.name)
                val convId = privateConversationId(packet.originNodeId)
                if (database.conversationDao().getById(convId) == null) {
                    database.conversationDao().upsert(
                        ConversationEntity(
                            conversationId = convId,
                            isGroup = false,
                            title = packet.senderDisplayName,
                            peerNodeId = packet.originNodeId,
                            lastMessageAt = now
                        )
                    )
                }
            }

            PacketType.CHAT_MESSAGE -> {
                val rel = database.contactDao().getById(packet.originNodeId)?.relationshipStatus
                if (settings.requireContactApproval && rel != RelationshipStatus.APPROVED.name) {
                    database.contactDao().updateRelationship(packet.originNodeId, RelationshipStatus.REQUEST_RECEIVED.name)
                    return
                }
                val plainBytes = CryptoManager.decryptFromPeer(
                    payloadB64 = packet.encryptedPayloadB64,
                    myEcdhPrivate = identity.ecdhPrivateKey,
                    peerEcdhPublicB64 = packet.senderEcdhPubKeyB64
                )
                val inner = chatAdapter.fromJson(String(plainBytes, Charsets.UTF_8)) ?: return
                val convId = privateConversationId(packet.originNodeId)
                val route = packet.routePath + identity.nodeId
                val deliveryState = if (packet.hopCount == 0) DeliveryStatus.DELIVERED_DIRECT else DeliveryStatus.DELIVERED_MESH
                database.messageDao().upsert(
                    MessageEntity(
                        packetId = packet.packetId,
                        conversationId = convId,
                        senderNodeId = packet.originNodeId,
                        senderName = packet.senderDisplayName,
                        messageType = inner.messageType,
                        contentEnc = localCipher.encryptText(inner.text),
                        mediaMimeType = inner.mediaMimeType,
                        mediaFileName = inner.mediaFileName,
                        mediaSizeBytes = inner.mediaSizeBytes,
                        timestamp = packet.createdAt,
                        expiresAt = packet.expiresAt,
                        deliveryStatus = deliveryState.name,
                        hopCount = packet.hopCount,
                        routePathJson = stringListAdapter.toJson(route),
                        transportUsed = transport.wireName,
                        isOutgoing = false
                    )
                )
                val existingConv = database.conversationDao().getById(convId)
                database.conversationDao().upsert(
                    ConversationEntity(
                        conversationId = convId,
                        isGroup = false,
                        title = packet.senderDisplayName,
                        peerNodeId = packet.originNodeId,
                        lastMessagePreviewEnc = localCipher.encryptText(inner.text.ifBlank { inner.mediaFileName ?: inner.messageType }),
                        lastMessageAt = packet.createdAt,
                        unreadCount = (existingConv?.unreadCount ?: 0) + 1,
                        lastHopCount = packet.hopCount,
                        lastRouteJson = stringListAdapter.toJson(route)
                    )
                )
                val title = packet.senderDisplayName
                val body = inner.text.ifBlank { inner.mediaFileName ?: inner.messageType }
                database.notificationDao().insert(
                    NotificationEntity(
                        id = UUID.randomUUID().toString(),
                        type = NotificationType.INCOMING_MESSAGE.name,
                        title = title,
                        body = body,
                        relatedNodeId = packet.originNodeId,
                        relatedConversationId = convId,
                        timestamp = now
                    )
                )
                OfflineNotificationHelper.showOfflineAlert(context, packet.packetId.hashCode(), title, body)
                val ack = router.buildDeliveryAck(packet, packet.senderEcdhPubKeyB64, now)
                router.markLocalSeen(ack.packetId, now)
                broadcastRawPacket(router.serializePacket(ack))
            }

            PacketType.GROUP_INVITE -> {
                val plainBytes = CryptoManager.decryptFromPeer(
                    payloadB64 = packet.encryptedPayloadB64,
                    myEcdhPrivate = identity.ecdhPrivateKey,
                    peerEcdhPublicB64 = packet.senderEcdhPubKeyB64
                )
                val invite = groupInviteAdapter.fromJson(String(plainBytes, Charsets.UTF_8)) ?: return
                database.groupDao().upsert(
                    GroupEntity(
                        groupId = invite.groupId,
                        name = invite.groupName,
                        creatorNodeId = packet.originNodeId,
                        groupKeyEnc = localCipher.encryptText(invite.groupKeyB64),
                        memberNodeIdsJson = stringListAdapter.toJson(invite.memberNodeIds),
                        createdAt = packet.createdAt
                    )
                )
                val convId = groupConversationId(invite.groupId)
                database.conversationDao().upsert(
                    ConversationEntity(
                        conversationId = convId,
                        isGroup = true,
                        title = invite.groupName,
                        lastMessagePreviewEnc = localCipher.encryptText(invite.groupName),
                        lastMessageAt = packet.createdAt
                    )
                )
            }

            PacketType.GROUP_MESSAGE -> {
                val groupId = packet.destinationNodeId.removePrefix(MeshRouter.GROUP_PREFIX)
                val group = database.groupDao().getById(groupId) ?: return
                val keyBytes = Base64.getDecoder().decode(localCipher.decryptText(group.groupKeyEnc))
                val plainBytes = CryptoManager.decryptAesGcm(packet.encryptedPayloadB64, SecretKeySpec(keyBytes, "AES"))
                val inner = chatAdapter.fromJson(String(plainBytes, Charsets.UTF_8)) ?: return
                val convId = groupConversationId(groupId)
                val route = packet.routePath + identity.nodeId
                val deliveryState = if (packet.hopCount == 0) DeliveryStatus.DELIVERED_DIRECT else DeliveryStatus.DELIVERED_MESH
                database.messageDao().upsert(
                    MessageEntity(
                        packetId = packet.packetId,
                        conversationId = convId,
                        senderNodeId = packet.originNodeId,
                        senderName = packet.senderDisplayName,
                        messageType = inner.messageType,
                        contentEnc = localCipher.encryptText(inner.text),
                        mediaMimeType = inner.mediaMimeType,
                        mediaFileName = inner.mediaFileName,
                        mediaSizeBytes = inner.mediaSizeBytes,
                        timestamp = packet.createdAt,
                        expiresAt = packet.expiresAt,
                        deliveryStatus = deliveryState.name,
                        hopCount = packet.hopCount,
                        routePathJson = stringListAdapter.toJson(route),
                        transportUsed = transport.wireName,
                        isOutgoing = false
                    )
                )
                val existingConv = database.conversationDao().getById(convId)
                database.conversationDao().upsert(
                    ConversationEntity(
                        conversationId = convId,
                        isGroup = true,
                        title = group.name,
                        lastMessagePreviewEnc = localCipher.encryptText("${packet.senderDisplayName}: ${inner.text.ifBlank { inner.mediaFileName ?: inner.messageType }}"),
                        lastMessageAt = packet.createdAt,
                        unreadCount = (existingConv?.unreadCount ?: 0) + 1,
                        lastHopCount = packet.hopCount,
                        lastRouteJson = stringListAdapter.toJson(route)
                    )
                )
                OfflineNotificationHelper.showOfflineAlert(
                    context,
                    packet.packetId.hashCode(),
                    group.name,
                    "${packet.senderDisplayName}: ${inner.text.ifBlank { inner.mediaFileName ?: inner.messageType }}"
                )
                val ack = router.buildDeliveryAck(packet, packet.senderEcdhPubKeyB64, now)
                router.markLocalSeen(ack.packetId, now)
                broadcastRawPacket(router.serializePacket(ack))
            }

            PacketType.MEDIA_CHUNK -> {
                val plainBytes = if (packet.destinationNodeId.startsWith(MeshRouter.GROUP_PREFIX)) {
                    val gid = packet.destinationNodeId.removePrefix(MeshRouter.GROUP_PREFIX)
                    val group = database.groupDao().getById(gid) ?: return
                    val keyBytes = Base64.getDecoder().decode(localCipher.decryptText(group.groupKeyEnc))
                    CryptoManager.decryptAesGcm(packet.encryptedPayloadB64, SecretKeySpec(keyBytes, "AES"))
                } else {
                    CryptoManager.decryptFromPeer(packet.encryptedPayloadB64, identity.ecdhPrivateKey, packet.senderEcdhPubKeyB64)
                }
                val chunk = mediaChunkAdapter.fromJson(String(plainBytes, Charsets.UTF_8)) ?: return
                chunkMetadata.putIfAbsent(chunk.transferId, chunk)
                val map = chunkReassembly.getOrPut(chunk.transferId) { ConcurrentHashMap() }
                map[chunk.chunkIndex] = Base64.getDecoder().decode(chunk.chunkDataB64)
                if (map.size == chunk.totalChunks) {
                    val assembled = ByteArrayOutputStream()
                    for (idx in 0 until chunk.totalChunks) {
                        val part = map[idx] ?: return
                        assembled.write(part)
                    }
                    chunkReassembly.remove(chunk.transferId)
                    val meta = chunkMetadata.remove(chunk.transferId) ?: chunk
                    val savedFile = mediaFileManager.saveReceivedMediaBytes(meta.fileName, assembled.toByteArray())
                    val existingMsg = database.messageDao().getByPacketId(meta.messagePacketId)
                    if (existingMsg != null) {
                        database.messageDao().upsert(
                            existingMsg.copy(
                                mediaLocalPath = savedFile.absolutePath,
                                mediaSizeBytes = savedFile.length(),
                                mediaMimeType = meta.mimeType
                            )
                        )
                    }
                }
            }

            PacketType.DELIVERY_ACK -> {
                val plainBytes = CryptoManager.decryptFromPeer(
                    payloadB64 = packet.encryptedPayloadB64,
                    myEcdhPrivate = identity.ecdhPrivateKey,
                    peerEcdhPublicB64 = packet.senderEcdhPubKeyB64
                )
                val ack = ackAdapter.fromJson(String(plainBytes, Charsets.UTF_8)) ?: return
                val status = if (ack.totalHops == 0) DeliveryStatus.DELIVERED_DIRECT else DeliveryStatus.DELIVERED_MESH
                database.messageDao().updateDelivery(
                    packetId = ack.originalPacketId,
                    status = status.name,
                    hopCount = ack.totalHops,
                    routePathJson = stringListAdapter.toJson(ack.observedRoutePath),
                    transportUsed = transport.wireName
                )
                database.pendingPacketDao().updateStatus(ack.originalPacketId, PacketQueueStatus.DELIVERED.name)
            }
        }
    }

    private fun activeTransportSummary(): String {
        val active = _transportStates.value.filter { it.value.first }.keys.map { it.wireName }
        return if (active.isEmpty()) "OFFLINE_QUEUE" else active.joinToString("+")
    }

    companion object {
        fun privateConversationId(peerNodeId: String): String = "peer:$peerNodeId"
        fun groupConversationId(groupId: String): String = "group:$groupId"
    }
}
