package com.example.mesh

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class WifiDirectTransport(
    private val context: Context,
    private val listener: TransportListener
) : MeshTransport {

    override val transportType: TransportType = TransportType.WIFI_DIRECT

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val manager: WifiP2pManager? =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val activeSockets = ConcurrentHashMap<String, Socket>()
    private val outputStreams = ConcurrentHashMap<String, DataOutputStream>()
    private val discoveredServices = ConcurrentHashMap<String, String>()

    @Volatile
    private var isStarted = false
    @Volatile
    private var receiverRegistered = false
    @Volatile
    private var localNodeId = ""

    override fun start(localNodeId: String, localDisplayName: String, batterySaver: Boolean) {
        if (isStarted) return
        val caps = DeviceCapabilityInspector.inspect(context).firstOrNull { it.type == TransportType.WIFI_DIRECT }
        if (caps?.status != TechStatus.READY) {
            listener.onTransportStatusChanged(transportType, false, "Wi-Fi Direct not ready: ${caps?.status}")
            return
        }
        val mgr = manager ?: return
        this.localNodeId = localNodeId
        channel = mgr.initialize(context, context.mainLooper, null)
        isStarted = true
        registerReceiver()
        registerLocalService(localNodeId, localDisplayName)
        discoverDnsSdServices()
        listener.onTransportStatusChanged(transportType, true, "Wi-Fi P2P service active")
    }

    override fun stop() {
        isStarted = false
        serverJob?.cancel()
        try {
            serverSocket?.close()
            if (receiverRegistered) {
                context.unregisterReceiver(p2pReceiver)
                receiverRegistered = false
            }
            channel?.let { ch ->
                manager?.clearLocalServices(ch, null)
                manager?.clearServiceRequests(ch, null)
                manager?.removeGroup(ch, null)
            }
            activeSockets.values.forEach { it.close() }
        } catch (_: Exception) {
        }
        activeSockets.keys.toList().forEach { listener.onPeerDisconnected(it, transportType) }
        activeSockets.clear()
        outputStreams.clear()
        discoveredServices.clear()
        listener.onTransportStatusChanged(transportType, false, "Wi-Fi Direct stopped")
    }

    override fun triggerScan() {
        if (!isStarted) return
        val ch = channel ?: return
        try {
            manager?.discoverPeers(ch, null)
            manager?.discoverServices(ch, null)
        } catch (_: Exception) {
        }
    }

    override suspend fun sendPacket(endpointKey: String, data: ByteArray): Boolean {
        val out = outputStreams[endpointKey] ?: return false
        return try {
            synchronized(out) {
                out.writeByte(FRAME_PACKET.toInt())
                out.writeInt(data.size)
                out.write(data)
                out.flush()
            }
            true
        } catch (_: Exception) {
            closeSocket(endpointKey)
            false
        }
    }

    override suspend fun broadcastPacket(data: ByteArray): Int {
        var count = 0
        for (ep in outputStreams.keys.toList()) {
            if (sendPacket(ep, data)) count++
        }
        return count
    }

    override suspend fun sendFile(endpointKey: String, file: File): Boolean {
        val out = outputStreams[endpointKey] ?: return false
        if (!file.exists()) return false
        return try {
            val nameBytes = file.name.toByteArray(Charsets.UTF_8)
            val fileLen = file.length()
            synchronized(out) {
                out.writeByte(FRAME_FILE.toInt())
                out.writeInt(nameBytes.size)
                out.write(nameBytes)
                out.writeLong(fileLen)
                FileInputStream(file).use { fis ->
                    val buffer = ByteArray(8192)
                    while (true) {
                        val read = fis.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                    }
                }
                out.flush()
            }
            true
        } catch (_: Exception) {
            closeSocket(endpointKey)
            false
        }
    }

    override fun connectedEndpointKeys(): List<String> = activeSockets.keys.toList()

    private fun registerLocalService(nodeId: String, displayName: String) {
        val ch = channel ?: return
        val record = mapOf("nodeId" to nodeId, "name" to displayName.take(24))
        val serviceInfo = WifiP2pDnsSdServiceInfo.newInstance(SERVICE_INSTANCE, SERVICE_TYPE, record)
        manager?.addLocalService(ch, serviceInfo, null)
    }

    private fun discoverDnsSdServices() {
        val mgr = manager ?: return
        val ch = channel ?: return
        mgr.setDnsSdResponseListeners(
            ch,
            { _, _, _ -> },
            { fullDomain, record, device ->
                if (fullDomain.contains(SERVICE_INSTANCE) || record.containsKey("nodeId")) {
                    val peerNodeId = record["nodeId"]
                    val peerName = record["name"] ?: device.deviceName ?: device.deviceAddress
                    discoveredServices[device.deviceAddress] = peerNodeId ?: peerName
                    listener.onPeerDiscovered(
                        LivePeerLink(
                            endpointKey = device.deviceAddress,
                            nodeId = peerNodeId,
                            displayName = peerName,
                            transport = transportType,
                            isConnected = activeSockets.containsKey(device.deviceAddress)
                        )
                    )
                    if (peerNodeId != null && localNodeId < peerNodeId && !activeSockets.containsKey(device.deviceAddress)) {
                        connectToDevice(device)
                    }
                }
            }
        )
        val request = WifiP2pDnsSdServiceRequest.newInstance()
        mgr.addServiceRequest(ch, request, null)
        mgr.discoverServices(ch, null)
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        val ch = channel ?: return
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager?.connect(ch, config, null)
    }

    private fun onGroupConnected(groupOwnerIp: String, isGroupOwner: Boolean) {
        if (isGroupOwner) {
            startGroupOwnerServer()
        } else {
            connectClientSocket(groupOwnerIp)
        }
    }

    private fun startGroupOwnerServer() {
        if (serverJob?.isActive == true) return
        serverJob = scope.launch {
            try {
                val srv = ServerSocket(TCP_PORT)
                serverSocket = srv
                while (isActive && isStarted) {
                    val sock = srv.accept()
                    handleSocket(sock)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun connectClientSocket(hostIp: String) {
        if (activeSockets.containsKey(hostIp)) return
        scope.launch {
            try {
                val sock = Socket()
                sock.connect(InetSocketAddress(hostIp, TCP_PORT), 6000)
                handleSocket(sock)
            } catch (_: Exception) {
            }
        }
    }

    private fun handleSocket(socket: Socket) {
        val key = socket.inetAddress?.hostAddress ?: return
        activeSockets[key] = socket
        outputStreams[key] = DataOutputStream(socket.outputStream)
        listener.onPeerConnected(
            LivePeerLink(
                endpointKey = key,
                nodeId = null,
                displayName = "Wi-Fi P2P ($key)",
                transport = transportType,
                isConnected = true
            )
        )
        scope.launch {
            try {
                val input = DataInputStream(socket.inputStream)
                while (isActive && isStarted && !socket.isClosed) {
                    val frameType = input.readByte()
                    if (frameType == FRAME_PACKET) {
                        val len = input.readInt()
                        if (len <= 0 || len > MAX_P2P_PACKET) break
                        val buf = ByteArray(len)
                        input.readFully(buf)
                        listener.onPacketReceived(key, transportType, buf)
                    } else if (frameType == FRAME_FILE) {
                        val nameLen = input.readInt()
                        if (nameLen <= 0 || nameLen > 512) break
                        val nameBytes = ByteArray(nameLen)
                        input.readFully(nameBytes)
                        val safeName = File(String(nameBytes, Charsets.UTF_8)).name
                            .replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF ]"), "_")
                            .ifBlank { "p2p_file.bin" }
                        val fileLen = input.readLong()
                        if (fileLen <= 0L || fileLen > MAX_P2P_FILE) break
                        val outDir = File(context.cacheDir, "p2p_rx").apply { mkdirs() }
                        val outFile = File(outDir, "${System.currentTimeMillis()}_$safeName")
                        if (!outFile.canonicalPath.startsWith(outDir.canonicalPath + File.separator)) break
                        FileOutputStream(outFile).use { fos ->
                            var remaining = fileLen
                            val buf = ByteArray(8192)
                            while (remaining > 0) {
                                val toRead = minOf(remaining, buf.size.toLong()).toInt()
                                val read = input.read(buf, 0, toRead)
                                if (read <= 0) break
                                fos.write(buf, 0, read)
                                remaining -= read
                            }
                        }
                        listener.onFileReceived(key, transportType, outFile)
                    }
                }
            } catch (_: Exception) {
            } finally {
                closeSocket(key)
            }
        }
    }

    private fun closeSocket(key: String) {
        activeSockets.remove(key)?.let {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
        outputStreams.remove(key)
        listener.onPeerDisconnected(key, transportType)
    }

    private fun registerReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(p2pReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(p2pReceiver, filter)
        }
        receiverRegistered = true
    }

    private val p2pReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val ch = channel ?: return
            when (intent?.action) {
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    @Suppress("DEPRECATION")
                    val netInfo = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                    if (netInfo?.isConnected == true) {
                        manager?.requestConnectionInfo(ch) { info ->
                            val ownerIp = info?.groupOwnerAddress?.hostAddress
                            if (info?.groupFormed == true && !ownerIp.isNullOrBlank()) {
                                onGroupConnected(ownerIp, info.isGroupOwner)
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        private const val SERVICE_INSTANCE = "_wasl_mesh"
        private const val SERVICE_TYPE = "_presence._tcp"
        private const val TCP_PORT = 47831
        private const val FRAME_PACKET: Byte = 1
        private const val FRAME_FILE: Byte = 2
        private const val MAX_P2P_PACKET = 4_194_304
        private const val MAX_P2P_FILE = 104_857_600L
    }
}
