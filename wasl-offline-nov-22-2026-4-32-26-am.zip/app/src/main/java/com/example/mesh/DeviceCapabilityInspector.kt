package com.example.mesh

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability

object DeviceCapabilityInspector {

    fun requiredMeshPermissions(): List<String> {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        return list.distinct()
    }

    fun missingMeshPermissions(context: Context): List<String> =
        requiredMeshPermissions().filter { perm ->
            ContextCompat.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED
        }

    fun hasBluetoothPermissions(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            has(context, Manifest.permission.BLUETOOTH_SCAN) &&
                has(context, Manifest.permission.BLUETOOTH_ADVERTISE) &&
                has(context, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            has(context, Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    fun hasWifiDirectPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            has(context, Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            has(context, Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    fun inspect(context: Context): List<TechnologyCapability> {
        val pm = context.packageManager
        val btManager = runCatching {
            context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        }.getOrNull()
        val btAdapter = runCatching { btManager?.adapter }.getOrNull()
        val btEnabled = runCatching { btAdapter?.isEnabled == true }.getOrDefault(false)

        val wifiManager = runCatching {
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        }.getOrNull()
        val wifiEnabled = runCatching { wifiManager?.isWifiEnabled == true }.getOrDefault(false)

        val hasBleHw = runCatching { pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE) }.getOrDefault(false)
        val hasBtHw = runCatching { pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH) }.getOrDefault(false)
        val hasWifiDirectHw = runCatching { pm.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT) }.getOrDefault(false)

        val btPerm = hasBluetoothPermissions(context)
        val wifiPerm = hasWifiDirectPermission(context)

        val gmsAvailable = try {
            GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
        } catch (_: Exception) {
            false
        }

        val bleStatus = when {
            !hasBleHw -> TechStatus.UNSUPPORTED
            !btPerm -> TechStatus.NEEDS_PERMISSION
            !btEnabled -> TechStatus.DISABLED
            else -> TechStatus.READY
        }

        val classicStatus = when {
            !hasBtHw -> TechStatus.UNSUPPORTED
            !btPerm -> TechStatus.NEEDS_PERMISSION
            !btEnabled -> TechStatus.DISABLED
            else -> TechStatus.READY
        }

        val wifiDirectStatus = when {
            !hasWifiDirectHw -> TechStatus.UNSUPPORTED
            !wifiPerm -> TechStatus.NEEDS_PERMISSION
            !wifiEnabled -> TechStatus.DISABLED
            else -> TechStatus.READY
        }

        val nearbyStatus = when {
            !gmsAvailable -> TechStatus.UNSUPPORTED
            !btPerm && !wifiPerm -> TechStatus.NEEDS_PERMISSION
            !btEnabled && !wifiEnabled -> TechStatus.DISABLED
            else -> TechStatus.READY
        }

        return listOf(
            TechnologyCapability(TransportType.BLE, bleStatus, hasBleHw, btEnabled, btPerm),
            TechnologyCapability(TransportType.BLUETOOTH_CLASSIC, classicStatus, hasBtHw, btEnabled, btPerm),
            TechnologyCapability(TransportType.WIFI_DIRECT, wifiDirectStatus, hasWifiDirectHw, wifiEnabled, wifiPerm),
            TechnologyCapability(TransportType.NEARBY_CONNECTIONS, nearbyStatus, gmsAvailable, btEnabled || wifiEnabled, btPerm || wifiPerm)
        )
    }

    private fun has(context: Context, permission: String): Boolean =
        runCatching {
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
}
