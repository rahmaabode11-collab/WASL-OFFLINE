package com.example.mesh

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class BluetoothClassicTransport(
    private val context: Context,
    private val listener: TransportListener
) : MeshTransport {

    override val transportType: TransportType = TransportType.BLUETOOTH_CLASSIC

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? get() = bluetoothManager?.adapter

    private var serverSocket: BluetoothServerSocket? = null
    private var acceptJob: Job? = null
    private val activeSockets = ConcurrentHashMap<String, BluetoothSocket>()
    private val outputStreams = ConcurrentHashMap<String, DataOutputStream>()

    @Volatile
    private var isStarted = false
    @Volatile
    private var receiverRegistered = false

    override fun start(localNodeId: String, localDisplayName: String, batterySaver: Boolean) {
        if (isStarted) return
        val caps = DeviceCapabilityInspector.inspect(context)
            .firstOrNull { it.type == TransportType.BLUETOOTH_CLASSIC }
        if (caps?.status != TechStatus.READY) {
            listener.onTransportStatusChanged(transportType, false, "BT Classic not ready: ${caps?.status}")
            return
        }
        isStarted = true
        registerDiscoveryReceiver()
        startAcceptLoop()
        connectBondedPeers()
        listener.onTransportStatusChanged(transportType, true, "RFCOMM listener active")
    }

    override fun stop() {
        isStarted = false
        acceptJob?.cancel()
        try {
            serverSocket?.close()
            if (receiverRegistered) {
                context.unregisterReceiver(discoveryReceiver)
                receiverRegistered = false
            }
            activeSockets.values.forEach { it.close() }
        } catch (_: Exception) {
        }
        activeSockets.keys.toList().forEach { addr ->
            listener.onPeerDisconnected(addr, transportType)
        }
        activeSockets.clear()
        outputStreams.clear()
        serverSocket = null
        listener.onTransportStatusChanged(transportType, false, "BT Classic stopped")
    }

    override fun triggerScan() {
        if (!isStarted) return
        try {
            val bt = adapter ?: return
            if (bt.isDiscovering) bt.cancelDiscovery()
            bt.startDiscovery()
            connectBondedPeers()
        } catch (_: Exception) {
        }
    }

    override suspend fun sendPacket(endpointKey: String, data: ByteArray): Boolean {
        val out = outputStreams[endpointKey] ?: return false
        return try {
            synchronized(out) {
                out.writeInt(data.size)
                out.write(data)
                out.flush()
            }
            true
        } catch (_: Exception) {
            closeSocket(endpointKey)
            false
        }
    }

    override suspend fun broadcastPacket(data: ByteArray): Int {
        var sent = 0
        for (key in outputStreams.keys.toList()) {
            if (sendPacket(key, data)) sent++
        }
        return sent
    }

    override fun connectedEndpointKeys(): List<String> = activeSockets.keys.toList()

    private fun startAcceptLoop() {
        acceptJob = scope.launch {
            while (isActive && isStarted) {
                try {
                    val srv = adapter?.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, WASL_RFCOMM_UUID)
                        ?: break
                    serverSocket = srv
                    val client = srv.accept()
                    handleConnectedSocket(client)
                } catch (_: Exception) {
                    if (!isStarted) break
                }
            }
        }
    }

    private fun connectBondedPeers() {
        val bt = adapter ?: return
        scope.launch {
            val bonded = try {
                bt.bondedDevices?.toList().orEmpty()
            } catch (_: Exception) {
                emptyList()
            }
            for (device in bonded) {
                val addr = device.address ?: continue
                if (!activeSockets.containsKey(addr)) {
                    tryConnectDevice(device)
                }
            }
        }
    }

    private fun tryConnectDevice(device: BluetoothDevice) {
        val addr = device.address ?: return
        if (activeSockets.containsKey(addr)) return
        scope.launch {
            try {
                adapter?.cancelDiscovery()
                val sock = device.createInsecureRfcommSocketToServiceRecord(WASL_RFCOMM_UUID)
                sock.connect()
                handleConnectedSocket(sock)
            } catch (_: Exception) {
                // Target device isn't listening on WASL RFCOMM UUID
            }
        }
    }

    private fun handleConnectedSocket(socket: BluetoothSocket) {
        val addr = socket.remoteDevice?.address ?: return
        activeSockets[addr] = socket
        outputStreams[addr] = DataOutputStream(socket.outputStream)
        listener.onPeerConnected(
            LivePeerLink(
                endpointKey = addr,
                nodeId = null,
                displayName = socket.remoteDevice?.name ?: addr,
                transport = transportType,
                isConnected = true
            )
        )
        scope.launch {
            try {
                val input = DataInputStream(socket.inputStream)
                while (isActive && isStarted && socket.isConnected) {
                    val length = input.readInt()
                    if (length <= 0 || length > MAX_RFCOMM_FRAME) break
                    val buf = ByteArray(length)
                    input.readFully(buf)
                    listener.onPacketReceived(addr, transportType, buf)
                }
            } catch (_: Exception) {
            } finally {
                closeSocket(addr)
            }
        }
    }

    private fun closeSocket(addr: String) {
        activeSockets.remove(addr)?.let {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
        outputStreams.remove(addr)
        listener.onPeerDisconnected(addr, transportType)
    }

    private fun registerDiscoveryReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        context.registerReceiver(discoveryReceiver, filter)
        receiverRegistered = true
    }

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == BluetoothDevice.ACTION_FOUND) {
                @Suppress("DEPRECATION")
                val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
                val addr = device.address ?: return
                listener.onPeerDiscovered(
                    LivePeerLink(
                        endpointKey = addr,
                        nodeId = null,
                        displayName = device.name ?: addr,
                        transport = transportType,
                        isConnected = activeSockets.containsKey(addr)
                    )
                )
            }
        }
    }

    companion object {
        private const val SERVICE_NAME = "WASL_OFFLINE_MESH"
        val WASL_RFCOMM_UUID: UUID = UUID.fromString("9E2B6C40-87A1-4B8F-9F1E-5741534C0001")
        private const val MAX_RFCOMM_FRAME = 2_097_152
    }
}
