package com.example.mesh

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.example.WaslApplication
import com.example.localization.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MeshForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as WaslApplication
        if (intent?.action == ACTION_STOP) {
            app.meshEngine.stopMesh()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val initialNotif = OfflineNotificationHelper.buildServiceNotification(
            context = this,
            connectedCount = app.meshEngine.livePeers.value.values.count { it.isConnected },
            isArabic = true
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                OfflineNotificationHelper.SERVICE_NOTIFICATION_ID,
                initialNotif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(OfflineNotificationHelper.SERVICE_NOTIFICATION_ID, initialNotif)
        }

        app.meshEngine.startMesh()

        serviceScope.launch {
            combine(
                app.meshEngine.livePeers,
                app.preferencesRepository.settingsFlow
            ) { peers, settings ->
                peers.values.count { it.isConnected } to (settings.language == AppLanguage.ARABIC)
            }.collect { (connectedCount, isArabic) ->
                val updated = OfflineNotificationHelper.buildServiceNotification(
                    context = this@MeshForegroundService,
                    connectedCount = connectedCount,
                    isArabic = isArabic
                )
                val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.notify(OfflineNotificationHelper.SERVICE_NOTIFICATION_ID, updated)
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val ACTION_START = "com.example.wasl.ACTION_START_MESH"
        private const val ACTION_STOP = "com.example.wasl.ACTION_STOP_MESH"

        fun start(context: Context) {
            val intent = Intent(context, MeshForegroundService::class.java).apply { action = ACTION_START }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, MeshForegroundService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }
}
