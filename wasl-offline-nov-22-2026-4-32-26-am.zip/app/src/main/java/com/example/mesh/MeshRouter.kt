package com.example.mesh

import com.example.crypto.CryptoManager
import com.example.crypto.DeviceIdentityKeys
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

sealed class RouteDecision {
    data object DropDuplicateOrExpired : RouteDecision()
    data object DropInvalidSignature : RouteDecision()
    data object DropBlockedOrigin : RouteDecision()
    data class DeliverLocally(
        val packet: MeshPacket,
        val shouldAlsoRelay: Boolean,
        val forwardedPacket: MeshPacket?
    ) : RouteDecision()

    data class RelayOnly(
        val forwardedPacket: MeshPacket
    ) : RouteDecision()
}

class MeshRouter(
    private val localIdentity: DeviceIdentityKeys
) {
    private val seenLru = object : LinkedHashMap<String, Long>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean {
            return size > 512
        }
    }

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val packetAdapter = moshi.adapter(MeshPacket::class.java)

    fun serializePacket(packet: MeshPacket): ByteArray =
        packetAdapter.toJson(packet).toByteArray(Charsets.UTF_8)

    fun deserializePacket(bytes: ByteArray): MeshPacket? =
        try {
            packetAdapter.fromJson(String(bytes, Charsets.UTF_8))
        } catch (_: Exception) {
            null
        }

    fun signOutgoingPacket(packet: MeshPacket): MeshPacket {
        val signature = CryptoManager.signData(
            packet.canonicalSigningBytes(),
            localIdentity.signingPrivateKey
        )
        return packet.copy(signatureB64 = signature)
    }

    @Synchronized
    fun evaluateIncomingPacket(
        packet: MeshPacket,
        now: Long,
        alreadySeenInDb: Boolean,
        isOriginBlocked: Boolean,
        relayEnabled: Boolean,
        localGroupIds: Set<String>
    ): RouteDecision {
        if (packet.originNodeId == localIdentity.nodeId) {
            return RouteDecision.DropDuplicateOrExpired
        }
        if (seenLru.containsKey(packet.packetId) || alreadySeenInDb) {
            return RouteDecision.DropDuplicateOrExpired
        }
        if (packet.expiresAt <= now) {
            return RouteDecision.DropDuplicateOrExpired
        }
        // Verify sender's ECDSA signature and that originNodeId matches public key
        val expectedNodeId = CryptoManager.deriveNodeId(packet.senderSigningPubKeyB64)
        if (expectedNodeId != packet.originNodeId ||
            !CryptoManager.verifySignature(
                packet.canonicalSigningBytes(),
                packet.signatureB64,
                packet.senderSigningPubKeyB64
            )
        ) {
            return RouteDecision.DropInvalidSignature
        }

        seenLru[packet.packetId] = now

        if (isOriginBlocked) {
            return RouteDecision.DropBlockedOrigin
        }

        val isBroadcast = packet.destinationNodeId == DESTINATION_BROADCAST
        val isForMeDirect = packet.destinationNodeId == localIdentity.nodeId
        val isForMyGroup = packet.destinationNodeId.startsWith(GROUP_PREFIX) &&
            localGroupIds.contains(packet.destinationNodeId.removePrefix(GROUP_PREFIX))

        val canForward = relayEnabled &&
            !isBroadcast &&
            !isForMeDirect &&
            packet.hopCount < packet.maxHops &&
            !packet.routePath.contains(localIdentity.nodeId)

        val canForwardGroup = relayEnabled &&
            packet.destinationNodeId.startsWith(GROUP_PREFIX) &&
            packet.hopCount < packet.maxHops &&
            !packet.routePath.contains(localIdentity.nodeId)

        val relayedPacket = if (canForward || canForwardGroup) {
            packet.copy(
                hopCount = packet.hopCount + 1,
                routePath = packet.routePath + localIdentity.nodeId
            )
        } else {
            null
        }

        return if (isBroadcast || isForMeDirect || isForMyGroup) {
            RouteDecision.DeliverLocally(
                packet = packet,
                shouldAlsoRelay = isForMyGroup && relayedPacket != null,
                forwardedPacket = if (isForMyGroup) relayedPacket else null
            )
        } else if (relayedPacket != null) {
            RouteDecision.RelayOnly(forwardedPacket = relayedPacket)
        } else {
            RouteDecision.DropDuplicateOrExpired
        }
    }

    fun buildDeliveryAck(
        originalPacket: MeshPacket,
        recipientEcdhPubB64: String,
        now: Long = System.currentTimeMillis()
    ): MeshPacket {
        val observedRoute = originalPacket.routePath + localIdentity.nodeId
        val ackPayload = InnerAckPayload(
            originalPacketId = originalPacket.packetId,
            receiverNodeId = localIdentity.nodeId,
            deliveredAt = now,
            observedRoutePath = observedRoute,
            totalHops = originalPacket.hopCount
        )
        val payloadBytes = moshi.adapter(InnerAckPayload::class.java).toJson(ackPayload).toByteArray(Charsets.UTF_8)
        val encrypted = CryptoManager.encryptForPeer(
            plaintext = payloadBytes,
            myEcdhPrivate = localIdentity.ecdhPrivateKey,
            peerEcdhPublicB64 = recipientEcdhPubB64
        )
        return signOutgoingPacket(
            MeshPacket(
                packetType = PacketType.DELIVERY_ACK.name,
                originNodeId = localIdentity.nodeId,
                destinationNodeId = originalPacket.originNodeId,
                senderDisplayName = localIdentity.nodeId,
                senderSigningPubKeyB64 = localIdentity.signingPublicKeyB64,
                senderEcdhPubKeyB64 = localIdentity.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = originalPacket.maxHops,
                routePath = emptyList(),
                createdAt = now,
                expiresAt = now + 12L * 3600_000L,
                encryptedPayloadB64 = encrypted
            )
        )
    }

    @Synchronized
    fun markLocalSeen(packetId: String, now: Long = System.currentTimeMillis()) {
        seenLru[packetId] = now
    }

    companion object {
        const val DESTINATION_BROADCAST = "BROADCAST"
        const val GROUP_PREFIX = "GROUP:"
    }
}
