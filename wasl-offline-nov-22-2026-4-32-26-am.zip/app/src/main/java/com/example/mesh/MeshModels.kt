package com.example.mesh

import com.squareup.moshi.JsonClass
import java.util.UUID

enum class TransportType(val wireName: String) {
    NEARBY_CONNECTIONS("NEARBY"),
    WIFI_DIRECT("WIFI_DIRECT"),
    BLUETOOTH_CLASSIC("BT_CLASSIC"),
    BLE("BLE")
}

enum class TechStatus {
    READY,
    DISABLED,
    NEEDS_PERMISSION,
    UNSUPPORTED
}

data class TechnologyCapability(
    val type: TransportType,
    val status: TechStatus,
    val hardwareSupported: Boolean,
    val radioEnabled: Boolean,
    val permissionGranted: Boolean
)

enum class PacketType {
    NODE_ANNOUNCE,
    CONTACT_REQUEST,
    CONTACT_ACCEPT,
    CHAT_MESSAGE,
    GROUP_INVITE,
    GROUP_MESSAGE,
    DELIVERY_ACK,
    MEDIA_CHUNK
}

@JsonClass(generateAdapter = true)
data class MeshPacket(
    val packetId: String = UUID.randomUUID().toString(),
    val packetType: String,
    val originNodeId: String,
    val destinationNodeId: String,
    val senderDisplayName: String,
    val senderSigningPubKeyB64: String,
    val senderEcdhPubKeyB64: String,
    val hopCount: Int = 0,
    val maxHops: Int = 6,
    val routePath: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long,
    val encryptedPayloadB64: String,
    val signatureB64: String = ""
) {
    fun canonicalSigningBytes(): ByteArray {
        val canonical = buildString {
            append(packetId).append('|')
            append(packetType).append('|')
            append(originNodeId).append('|')
            append(destinationNodeId).append('|')
            append(senderSigningPubKeyB64).append('|')
            append(senderEcdhPubKeyB64).append('|')
            append(maxHops).append('|')
            append(createdAt).append('|')
            append(expiresAt).append('|')
            append(encryptedPayloadB64)
        }
        return canonical.toByteArray(Charsets.UTF_8)
    }
}

@JsonClass(generateAdapter = true)
data class InnerChatPayload(
    val messageType: String,
    val text: String = "",
    val mediaFileName: String? = null,
    val mediaMimeType: String? = null,
    val mediaSizeBytes: Long = 0L,
    val mediaTransferId: String? = null,
    val groupId: String? = null
)

@JsonClass(generateAdapter = true)
data class InnerGroupInvite(
    val groupId: String,
    val groupName: String,
    val groupKeyB64: String,
    val memberNodeIds: List<String>
)

@JsonClass(generateAdapter = true)
data class InnerAckPayload(
    val originalPacketId: String,
    val receiverNodeId: String,
    val deliveredAt: Long,
    val observedRoutePath: List<String>,
    val totalHops: Int
)

@JsonClass(generateAdapter = true)
data class InnerAnnouncePayload(
    val relayEnabled: Boolean,
    val supportedTransports: List<String>,
    val knownDirectPeers: List<String>,
    val announcedAt: Long
)

@JsonClass(generateAdapter = true)
data class InnerMediaChunk(
    val transferId: String,
    val conversationId: String,
    val messagePacketId: String,
    val fileName: String,
    val mimeType: String,
    val messageType: String,
    val totalChunks: Int,
    val chunkIndex: Int,
    val chunkDataB64: String
)

data class LivePeerLink(
    val endpointKey: String,
    val nodeId: String?,
    val displayName: String,
    val transport: TransportType,
    val isConnected: Boolean,
    val rssiDbm: Int? = null,
    val lastSeenAt: Long = System.currentTimeMillis()
)

data class RouteObservation(
    val destinationNodeId: String,
    val nextHopPeerKey: String,
    val hopDistance: Int,
    val observedAt: Long
)
