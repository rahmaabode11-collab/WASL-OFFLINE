package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ContactEntity::class,
        ConversationEntity::class,
        MessageEntity::class,
        GroupEntity::class,
        PendingPacketEntity::class,
        SeenPacketEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class WaslDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun groupDao(): GroupDao
    abstract fun pendingPacketDao(): PendingPacketDao
    abstract fun seenPacketDao(): SeenPacketDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: WaslDatabase? = null

        fun getInstance(context: Context): WaslDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    WaslDatabase::class.java,
                    "wasl_offline_mesh.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
