package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class RelationshipStatus {
    DISCOVERED,
    REQUEST_SENT,
    REQUEST_RECEIVED,
    APPROVED,
    BLOCKED
}

enum class MessageType {
    TEXT,
    VOICE,
    IMAGE,
    VIDEO,
    FILE
}

enum class DeliveryStatus {
    QUEUED,
    RELAYING,
    DELIVERED_DIRECT,
    DELIVERED_MESH,
    EXPIRED,
    FAILED
}

enum class PacketQueueStatus {
    PENDING,
    DELIVERED,
    EXPIRED
}

enum class NotificationType {
    CONTACT_REQUEST,
    INCOMING_MESSAGE,
    RELAY_DELIVERED,
    MESSAGE_EXPIRED,
    NETWORK_EVENT
}

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val nodeId: String,
    val displayName: String,
    val signingPubKeyB64: String,
    val ecdhPubKeyB64: String,
    val fingerprint: String,
    val relationshipStatus: String = RelationshipStatus.DISCOVERED.name,
    val lastSeenAt: Long = System.currentTimeMillis(),
    val lastTransport: String = "",
    val isDirectlyConnected: Boolean = false,
    val hopDistance: Int = 1,
    val rssiDbm: Int? = null
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val conversationId: String,
    val isGroup: Boolean,
    val title: String,
    val peerNodeId: String? = null,
    val lastMessagePreviewEnc: String = "",
    val lastMessageAt: Long = 0L,
    val unreadCount: Int = 0,
    val lastHopCount: Int = 0,
    val lastRouteJson: String = "[]"
)

@Entity(
    tableName = "messages",
    indices = [Index(value = ["conversationId", "timestamp"])]
)
data class MessageEntity(
    @PrimaryKey val packetId: String,
    val conversationId: String,
    val senderNodeId: String,
    val senderName: String,
    val messageType: String = MessageType.TEXT.name,
    val contentEnc: String,
    val mediaLocalPath: String? = null,
    val mediaMimeType: String? = null,
    val mediaFileName: String? = null,
    val mediaSizeBytes: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long,
    val deliveryStatus: String = DeliveryStatus.QUEUED.name,
    val hopCount: Int = 0,
    val routePathJson: String = "[]",
    val transportUsed: String = "",
    val isOutgoing: Boolean
)

@Entity(tableName = "groups")
data class GroupEntity(
    @PrimaryKey val groupId: String,
    val name: String,
    val creatorNodeId: String,
    val groupKeyEnc: String,
    val memberNodeIdsJson: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "pending_packets",
    indices = [Index(value = ["status", "expiresAt"])]
)
data class PendingPacketEntity(
    @PrimaryKey val packetId: String,
    val destinationNodeId: String,
    val packetJson: String,
    val hopCount: Int,
    val maxHops: Int,
    val createdAt: Long,
    val expiresAt: Long,
    val attemptCount: Int = 0,
    val lastAttemptAt: Long = 0L,
    val status: String = PacketQueueStatus.PENDING.name
)

@Entity(tableName = "seen_packets")
data class SeenPacketEntity(
    @PrimaryKey val packetId: String,
    val seenAt: Long,
    val expiresAt: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val type: String,
    val title: String,
    val body: String,
    val relatedNodeId: String? = null,
    val relatedConversationId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val actionHandled: Boolean = false
)
