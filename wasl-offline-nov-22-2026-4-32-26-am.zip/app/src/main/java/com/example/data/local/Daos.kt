package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY isDirectlyConnected DESC, lastSeenAt DESC")
    fun observeAllContacts(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE relationshipStatus = 'APPROVED' ORDER BY displayName ASC")
    fun observeApprovedContacts(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE relationshipStatus = 'BLOCKED' ORDER BY displayName ASC")
    fun observeBlockedContacts(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE nodeId = :nodeId LIMIT 1")
    suspend fun getById(nodeId: String): ContactEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(contact: ContactEntity)

    @Query("UPDATE contacts SET relationshipStatus = :status WHERE nodeId = :nodeId")
    suspend fun updateRelationship(nodeId: String, status: String)

    @Query("UPDATE contacts SET isDirectlyConnected = :connected, lastSeenAt = :seenAt, lastTransport = :transport, hopDistance = :hops, rssiDbm = :rssi WHERE nodeId = :nodeId")
    suspend fun updateLinkState(
        nodeId: String,
        connected: Boolean,
        seenAt: Long,
        transport: String,
        hops: Int,
        rssi: Int?
    )

    @Query("UPDATE contacts SET isDirectlyConnected = 0")
    suspend fun clearAllDirectConnections()

    @Query("DELETE FROM contacts")
    suspend fun deleteAll()
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE isGroup = 0 ORDER BY lastMessageAt DESC")
    fun observePrivateConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE isGroup = 1 ORDER BY lastMessageAt DESC")
    fun observeGroupConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY lastMessageAt DESC")
    fun observeAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE conversationId = :conversationId LIMIT 1")
    suspend fun getById(conversationId: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(conversation: ConversationEntity)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE conversationId = :conversationId")
    suspend fun markRead(conversationId: String)

    @Query("DELETE FROM conversations WHERE conversationId = :conversationId")
    suspend fun deleteById(conversationId: String)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun observeMessages(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE mediaLocalPath IS NOT NULL AND mediaLocalPath != '' ORDER BY timestamp DESC")
    fun observeMediaMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE packetId = :packetId LIMIT 1")
    suspend fun getByPacketId(packetId: String): MessageEntity?

    @Query("SELECT COUNT(*) FROM messages WHERE isOutgoing = 1 AND (deliveryStatus = 'DELIVERED_DIRECT' OR deliveryStatus = 'DELIVERED_MESH')")
    fun observeDeliveredCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM messages WHERE isOutgoing = 1 AND (deliveryStatus = 'QUEUED' OR deliveryStatus = 'RELAYING')")
    fun observePendingMessageCount(): Flow<Int>

    @Query("SELECT * FROM messages WHERE hopCount > 0 ORDER BY timestamp DESC LIMIT 20")
    fun observeRecentRoutedMessages(): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(message: MessageEntity)

    @Query("UPDATE messages SET deliveryStatus = :status, hopCount = :hopCount, routePathJson = :routePathJson, transportUsed = :transportUsed WHERE packetId = :packetId")
    suspend fun updateDelivery(
        packetId: String,
        status: String,
        hopCount: Int,
        routePathJson: String,
        transportUsed: String
    )

    @Query("UPDATE messages SET deliveryStatus = 'EXPIRED' WHERE (deliveryStatus = 'QUEUED' OR deliveryStatus = 'RELAYING') AND expiresAt < :now")
    suspend fun markExpiredMessages(now: Long): Int

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteByConversation(conversationId: String)

    @Query("DELETE FROM messages")
    suspend fun deleteAll()
}

@Dao
interface GroupDao {
    @Query("SELECT * FROM groups ORDER BY createdAt DESC")
    fun observeAllGroups(): Flow<List<GroupEntity>>

    @Query("SELECT * FROM groups WHERE groupId = :groupId LIMIT 1")
    suspend fun getById(groupId: String): GroupEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(group: GroupEntity)

    @Query("DELETE FROM groups")
    suspend fun deleteAll()
}

@Dao
interface PendingPacketDao {
    @Query("SELECT * FROM pending_packets WHERE status = 'PENDING' AND expiresAt > :now ORDER BY createdAt ASC")
    suspend fun getActivePendingPackets(now: Long): List<PendingPacketEntity>

    @Query("SELECT COUNT(*) FROM pending_packets WHERE status = 'PENDING'")
    fun observePendingCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(packet: PendingPacketEntity)

    @Query("UPDATE pending_packets SET status = :status WHERE packetId = :packetId")
    suspend fun updateStatus(packetId: String, status: String)

    @Query("UPDATE pending_packets SET attemptCount = attemptCount + 1, lastAttemptAt = :now WHERE packetId = :packetId")
    suspend fun recordAttempt(packetId: String, now: Long)

    @Query("UPDATE pending_packets SET status = 'EXPIRED' WHERE status = 'PENDING' AND expiresAt <= :now")
    suspend fun expireOldPackets(now: Long): Int

    @Query("SELECT * FROM pending_packets WHERE status = 'PENDING' AND expiresAt <= :now")
    suspend fun findNewlyExpiringPackets(now: Long): List<PendingPacketEntity>

    @Query("DELETE FROM pending_packets WHERE expiresAt < :olderThan")
    suspend fun pruneExpired(olderThan: Long)

    @Query("DELETE FROM pending_packets")
    suspend fun deleteAll()
}

@Dao
interface SeenPacketDao {
    @Query("SELECT EXISTS(SELECT 1 FROM seen_packets WHERE packetId = :packetId)")
    suspend fun exists(packetId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(seen: SeenPacketEntity)

    @Query("DELETE FROM seen_packets WHERE expiresAt < :now")
    suspend fun pruneExpired(now: Long)

    @Query("DELETE FROM seen_packets")
    suspend fun deleteAll()
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
    fun observeUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllRead()

    @Query("UPDATE notifications SET actionHandled = 1, isRead = 1 WHERE id = :id")
    suspend fun markActionHandled(id: String)

    @Query("DELETE FROM notifications")
    suspend fun deleteAll()
}
