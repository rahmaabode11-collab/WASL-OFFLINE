package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.localization.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.waslDataStore: DataStore<Preferences> by preferencesDataStore(name = "wasl_prefs")

data class UserSettings(
    val isRegistered: Boolean = false,
    val displayName: String = "",
    val language: AppLanguage = AppLanguage.ARABIC,
    val relayEnabled: Boolean = true,
    val maxHops: Int = 6,
    val messageTtlHours: Int = 24,
    val batterySaverScan: Boolean = true,
    val requireContactApproval: Boolean = true,
    val lastSuccessfulConnectionAt: Long = 0L
)

class PreferencesRepository(private val context: Context) {

    val settingsFlow: Flow<UserSettings> = context.waslDataStore.data.map { prefs ->
        UserSettings(
            isRegistered = prefs[KEY_REGISTERED] ?: false,
            displayName = prefs[KEY_DISPLAY_NAME] ?: "",
            language = AppLanguage.fromCode(prefs[KEY_LANGUAGE]),
            relayEnabled = prefs[KEY_RELAY_ENABLED] ?: true,
            maxHops = (prefs[KEY_MAX_HOPS] ?: 6).coerceIn(1, 8),
            messageTtlHours = (prefs[KEY_TTL_HOURS] ?: 24).coerceIn(6, 72),
            batterySaverScan = prefs[KEY_BATTERY_SAVER] ?: true,
            requireContactApproval = prefs[KEY_REQUIRE_APPROVAL] ?: true,
            lastSuccessfulConnectionAt = prefs[KEY_LAST_CONN] ?: 0L
        )
    }

    suspend fun completeRegistration(displayName: String, language: AppLanguage) {
        context.waslDataStore.edit { prefs ->
            prefs[KEY_REGISTERED] = true
            prefs[KEY_DISPLAY_NAME] = displayName.trim()
            prefs[KEY_LANGUAGE] = language.code
        }
    }

    suspend fun updateDisplayName(displayName: String) {
        context.waslDataStore.edit { it[KEY_DISPLAY_NAME] = displayName.trim() }
    }

    suspend fun updateLanguage(language: AppLanguage) {
        context.waslDataStore.edit { it[KEY_LANGUAGE] = language.code }
    }

    suspend fun updateRelayEnabled(enabled: Boolean) {
        context.waslDataStore.edit { it[KEY_RELAY_ENABLED] = enabled }
    }

    suspend fun updateMaxHops(hops: Int) {
        context.waslDataStore.edit { it[KEY_MAX_HOPS] = hops.coerceIn(1, 8) }
    }

    suspend fun updateMessageTtlHours(hours: Int) {
        context.waslDataStore.edit { it[KEY_TTL_HOURS] = hours.coerceIn(6, 72) }
    }

    suspend fun updateBatterySaverScan(enabled: Boolean) {
        context.waslDataStore.edit { it[KEY_BATTERY_SAVER] = enabled }
    }

    suspend fun updateRequireContactApproval(required: Boolean) {
        context.waslDataStore.edit { it[KEY_REQUIRE_APPROVAL] = required }
    }

    suspend fun recordSuccessfulConnection(timestamp: Long = System.currentTimeMillis()) {
        context.waslDataStore.edit { it[KEY_LAST_CONN] = timestamp }
    }

    suspend fun clearAll() {
        context.waslDataStore.edit { it.clear() }
    }

    companion object {
        private val KEY_REGISTERED = booleanPreferencesKey("is_registered")
        private val KEY_DISPLAY_NAME = stringPreferencesKey("display_name")
        private val KEY_LANGUAGE = stringPreferencesKey("language_code")
        private val KEY_RELAY_ENABLED = booleanPreferencesKey("relay_enabled")
        private val KEY_MAX_HOPS = intPreferencesKey("max_hops")
        private val KEY_TTL_HOURS = intPreferencesKey("message_ttl_hours")
        private val KEY_BATTERY_SAVER = booleanPreferencesKey("battery_saver_scan")
        private val KEY_REQUIRE_APPROVAL = booleanPreferencesKey("require_contact_approval")
        private val KEY_LAST_CONN = longPreferencesKey("last_successful_connection_at")
    }
}
