package com.example.media

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class VoiceRecorderManager(
    private val context: Context,
    private val mediaFileManager: MediaFileManager
) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var player: MediaPlayer? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _playingPath = MutableStateFlow<String?>(null)
    val playingPath: StateFlow<String?> = _playingPath.asStateFlow()

    fun startRecording(): Boolean {
        if (_isRecording.value) return false
        val outFile = mediaFileManager.createVoiceOutputFile()
        return try {
            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            rec.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(48_000)
                setAudioSamplingRate(16_000)
                setOutputFile(outFile.absolutePath)
                prepare()
                start()
            }
            recorder = rec
            currentFile = outFile
            _isRecording.value = true
            true
        } catch (_: Exception) {
            outFile.delete()
            recorder = null
            currentFile = null
            _isRecording.value = false
            false
        }
    }

    fun stopRecording(): File? {
        if (!_isRecording.value) return null
        val file = currentFile
        try {
            recorder?.stop()
        } catch (_: Exception) {
            file?.delete()
            return null
        } finally {
            try {
                recorder?.release()
            } catch (_: Exception) {
            }
            recorder = null
            currentFile = null
            _isRecording.value = false
        }
        return file?.takeIf { it.exists() && it.length() > 0L }
    }

    fun cancelRecording() {
        val file = currentFile
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null
        currentFile = null
        _isRecording.value = false
        file?.delete()
    }

    fun togglePlayback(filePath: String) {
        if (_playingPath.value == filePath) {
            stopPlayback()
            return
        }
        stopPlayback()
        val f = File(filePath)
        if (!f.exists()) return
        try {
            val mp = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                setOnCompletionListener {
                    stopPlayback()
                }
                start()
            }
            player = mp
            _playingPath.value = filePath
        } catch (_: Exception) {
            stopPlayback()
        }
    }

    fun stopPlayback() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        _playingPath.value = null
    }
}
