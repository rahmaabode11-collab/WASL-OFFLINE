package com.example.media

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class CopiedMediaInfo(
    val file: File,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long
)

class MediaFileManager(private val context: Context) {

    private val mediaRoot: File
        get() = File(context.filesDir, "media").apply { mkdirs() }

    fun createVoiceOutputFile(): File {
        val dir = File(mediaRoot, "voice").apply { mkdirs() }
        return File(dir, "voice_${System.currentTimeMillis()}.m4a")
    }

    fun copyUriToPrivateMedia(uri: Uri, subDir: String = "shared"): CopiedMediaInfo? {
        return try {
            val resolver = context.contentResolver
            val mimeType = resolver.getType(uri) ?: "application/octet-stream"
            var displayName = queryDisplayName(uri)
            if (displayName.isNullOrBlank()) {
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType) ?: "bin"
                displayName = "wasl_${UUID.randomUUID().toString().take(8)}.$ext"
            }
            val safeName = File(displayName).name.replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF ]"), "_")
            val targetDir = File(mediaRoot, subDir).apply { mkdirs() }
            val destFile = File(targetDir, "${System.currentTimeMillis()}_$safeName")
            resolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return null
            CopiedMediaInfo(
                file = destFile,
                fileName = safeName,
                mimeType = mimeType,
                sizeBytes = destFile.length()
            )
        } catch (_: Exception) {
            null
        }
    }

    fun saveReceivedMediaBytes(fileName: String, bytes: ByteArray): File {
        val dir = File(mediaRoot, "received").apply { mkdirs() }
        val baseName = File(fileName).name.replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF ]"), "_")
        val safeName = baseName.ifBlank { "received_${System.currentTimeMillis()}.bin" }
        val target = File(dir, "${System.currentTimeMillis()}_$safeName")
        require(target.canonicalPath.startsWith(dir.canonicalPath + File.separator)) { "Invalid destination path" }
        target.writeBytes(bytes)
        return target
    }

    fun openFileWithSystemViewer(path: String, mimeType: String?) {
        val file = File(path)
        if (!file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType ?: "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    fun wipeAllMedia() {
        mediaRoot.deleteRecursively()
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        } catch (_: Exception) {
            null
        }
    }
}
