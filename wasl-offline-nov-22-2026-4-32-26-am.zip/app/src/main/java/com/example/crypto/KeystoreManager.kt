package com.example.crypto

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.util.Base64
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec

class KeystoreManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private var cachedIdentity: DeviceIdentityKeys? = null
    private var cachedStorageKey: SecretKey? = null

    @Synchronized
    fun getOrCreateIdentity(): DeviceIdentityKeys {
        cachedIdentity?.let { return it }

        val sigPub = prefs.getString(KEY_SIGNING_PUB, null)
        val sigPrivEnc = prefs.getString(KEY_SIGNING_PRIV_WRAPPED, null)
        val ecdhPub = prefs.getString(KEY_ECDH_PUB, null)
        val ecdhPrivEnc = prefs.getString(KEY_ECDH_PRIV_WRAPPED, null)

        if (sigPub != null && sigPrivEnc != null && ecdhPub != null && ecdhPrivEnc != null) {
            val restored = try {
                val sigPrivBytes = unwrapBytes(sigPrivEnc)
                val ecdhPrivBytes = unwrapBytes(ecdhPrivEnc)
                DeviceIdentityKeys(
                    nodeId = CryptoManager.deriveNodeId(sigPub),
                    fingerprint = CryptoManager.deriveFingerprint(sigPub),
                    signingPublicKeyB64 = sigPub,
                    signingPrivateKey = CryptoManager.decodePrivateKey(sigPrivBytes),
                    ecdhPublicKeyB64 = ecdhPub,
                    ecdhPrivateKey = CryptoManager.decodePrivateKey(ecdhPrivBytes)
                )
            } catch (_: Exception) {
                null
            }
            if (restored != null) {
                cachedIdentity = restored
                return restored
            }
        }

        return rotateIdentity()
    }

    @Synchronized
    fun rotateIdentity(): DeviceIdentityKeys {
        val identity = CryptoManager.generateIdentity()
        val sigPrivWrapped = wrapBytes(identity.signingPrivateKey.encoded)
        val ecdhPrivWrapped = wrapBytes(identity.ecdhPrivateKey.encoded)
        prefs.edit()
            .putString(KEY_SIGNING_PUB, identity.signingPublicKeyB64)
            .putString(KEY_SIGNING_PRIV_WRAPPED, sigPrivWrapped)
            .putString(KEY_ECDH_PUB, identity.ecdhPublicKeyB64)
            .putString(KEY_ECDH_PRIV_WRAPPED, ecdhPrivWrapped)
            .apply()
        cachedIdentity = identity
        return identity
    }

    @Synchronized
    fun getOrCreateLocalStorageKey(): SecretKey {
        cachedStorageKey?.let { return it }
        val wrapped = prefs.getString(KEY_LOCAL_DB_WRAPPED, null)
        val existing = if (wrapped != null) {
            try {
                val raw = unwrapBytes(wrapped)
                SecretKeySpec(raw, "AES")
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }
        val key = existing ?: run {
            val fresh = CryptoManager.generateAes256Key()
            val freshWrapped = wrapBytes(fresh.encoded)
            prefs.edit().putString(KEY_LOCAL_DB_WRAPPED, freshWrapped).apply()
            fresh
        }
        cachedStorageKey = key
        return key
    }

    @Synchronized
    fun clearAllKeys() {
        prefs.edit().clear().apply()
        cachedIdentity = null
        cachedStorageKey = null
    }

    private fun wrapBytes(plain: ByteArray): String {
        val ksKey = getOrCreateKeystoreKey()
        if (ksKey != null) {
            try {
                return CryptoManager.encryptAesGcm(plain, ksKey)
            } catch (_: Exception) {
                // Fall back to local software wrapper if Keystore cipher fails on device/emulator
            }
        }
        return CryptoManager.encryptAesGcm(plain, getOrCreateFallbackWrapperKey())
    }

    private fun unwrapBytes(wrappedB64: String): ByteArray {
        val ksKey = getOrCreateKeystoreKey()
        if (ksKey != null) {
            try {
                return CryptoManager.decryptAesGcm(wrappedB64, ksKey)
            } catch (_: Exception) {
                // Retry with fallback wrapper key if that key wrapped the blob
            }
        }
        return CryptoManager.decryptAesGcm(wrappedB64, getOrCreateFallbackWrapperKey())
    }

    private fun getOrCreateKeystoreKey(): SecretKey? {
        return try {
            val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            val existing = ks.getKey(KEYSTORE_ALIAS, null) as? SecretKey
            if (existing != null) {
                existing
            } else {
                val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                val spec = KeyGenParameterSpec.Builder(
                    KEYSTORE_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                generator.init(spec)
                generator.generateKey()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun getOrCreateFallbackWrapperKey(): SecretKey {
        val fallbackB64 = prefs.getString(KEY_TEST_FALLBACK, null)
        return if (fallbackB64 != null) {
            SecretKeySpec(Base64.getDecoder().decode(fallbackB64), "AES")
        } else {
            val fresh = CryptoManager.generateAes256Key()
            prefs.edit().putString(KEY_TEST_FALLBACK, Base64.getEncoder().encodeToString(fresh.encoded)).apply()
            fresh
        }
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEYSTORE_ALIAS = "wasl_offline_master_key_v1"
        private const val PREFS_NAME = "wasl_secure_keystore_prefs"
        private const val KEY_SIGNING_PUB = "signing_pub_b64"
        private const val KEY_SIGNING_PRIV_WRAPPED = "signing_priv_wrapped"
        private const val KEY_ECDH_PUB = "ecdh_pub_b64"
        private const val KEY_ECDH_PRIV_WRAPPED = "ecdh_priv_wrapped"
        private const val KEY_LOCAL_DB_WRAPPED = "local_db_key_wrapped"
        private const val KEY_TEST_FALLBACK = "jvm_test_wrapper_fallback"
    }
}
