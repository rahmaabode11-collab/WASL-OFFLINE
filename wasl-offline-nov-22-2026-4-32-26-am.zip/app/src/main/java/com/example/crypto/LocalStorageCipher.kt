package com.example.crypto

import javax.crypto.SecretKey

class LocalStorageCipher(private val storageKeyProvider: () -> SecretKey) {

    fun encryptText(plaintext: String): String {
        if (plaintext.isEmpty()) return ""
        val encrypted = CryptoManager.encryptAesGcm(
            plaintext.toByteArray(Charsets.UTF_8),
            storageKeyProvider()
        )
        return "$PREFIX$encrypted"
    }

    fun decryptText(stored: String): String {
        if (stored.isEmpty()) return ""
        if (!stored.startsWith(PREFIX)) return stored
        return try {
            val payload = stored.removePrefix(PREFIX)
            val plain = CryptoManager.decryptAesGcm(payload, storageKeyProvider())
            String(plain, Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    companion object {
        private const val PREFIX = "enc:v1:"
    }
}
