package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.FolderShared
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.localization.LocalStrings
import com.example.mesh.DeviceCapabilityInspector
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatsHubScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FileSharingScreen
import com.example.ui.screens.NearbyDevicesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SecuritySettingsScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaslOfflineTheme

object WaslRoutes {
    const val WELCOME = "welcome"
    const val CHATS = "chats"
    const val NEARBY = "nearby"
    const val DASHBOARD = "dashboard"
    const val FILES = "files"
    const val CHAT_DETAIL = "chat_detail"
    const val NOTIFICATIONS = "notifications"
    const val PROFILE = "profile"
    const val SECURITY = "security"
}

private data class TopTabItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WaslAppRoot(viewModel: WaslViewModel = viewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val identity by viewModel.identityUi.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val approvedContacts by viewModel.approvedContacts.collectAsStateWithLifecycle()
    val blockedContacts by viewModel.blockedContacts.collectAsStateWithLifecycle()
    val privateConvs by viewModel.privateConversations.collectAsStateWithLifecycle()
    val groupConvs by viewModel.groupConversations.collectAsStateWithLifecycle()
    val allConvs by viewModel.allConversations.collectAsStateWithLifecycle()
    val mediaMessages by viewModel.mediaMessages.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val unreadNotifs by viewModel.unreadNotifications.collectAsStateWithLifecycle()
    val livePeers by viewModel.livePeers.collectAsStateWithLifecycle()
    val isMeshRunning by viewModel.isMeshRunning.collectAsStateWithLifecycle()
    val dashboardMetrics by viewModel.dashboardMetrics.collectAsStateWithLifecycle()
    val isRecordingVoice by viewModel.voiceRecorderManager.isRecording.collectAsStateWithLifecycle()
    val playingVoicePath by viewModel.voiceRecorderManager.playingPath.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var permRefreshTick by remember { mutableIntStateOf(0) }
    val missingPermissions = remember(permRefreshTick) {
        DeviceCapabilityInspector.missingMeshPermissions(context)
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        permRefreshTick++
        viewModel.refreshCapabilities()
        if (settings.isRegistered) {
            viewModel.startMeshService()
        }
    }

    val requestMeshPermissions = {
        val missing = DeviceCapabilityInspector.missingMeshPermissions(context)
        if (missing.isNotEmpty()) {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    WaslOfflineTheme(language = settings.language) {
        val strings = LocalStrings.current
        if (!settings.isRegistered) {
            WelcomeScreen(
                currentLanguage = settings.language,
                hasMissingPermissions = missingPermissions.isNotEmpty(),
                onLanguageChange = viewModel::setLanguage,
                onRequestPermissions = requestMeshPermissions,
                onCompleteRegistration = { name ->
                    viewModel.completeRegistration(name, settings.language)
                }
            )
            return@WaslOfflineTheme
        }

        val navController = rememberNavController()
        val backEntry by navController.currentBackStackEntryAsState()
        val currentRoute = backEntry?.destination?.route

        val tabs = listOf(
            TopTabItem(WaslRoutes.CHATS, strings.navChats, Icons.AutoMirrored.Rounded.Chat, "nav_chats"),
            TopTabItem(WaslRoutes.NEARBY, strings.navNearby, Icons.Rounded.Radar, "nav_nearby"),
            TopTabItem(WaslRoutes.DASHBOARD, strings.navMesh, Icons.Rounded.Hub, "nav_mesh"),
            TopTabItem(WaslRoutes.FILES, strings.navFiles, Icons.Rounded.FolderShared, "nav_files")
        )
        val isPrimaryTab = tabs.any { it.route == currentRoute }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(NavyBackground)
        ) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = NavyBackground,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                topBar = {
                    if (isPrimaryTab) {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
                            title = {
                                Text(
                                    text = strings.appName,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CyanAccent
                                )
                            },
                            actions = {
                                IconButton(
                                    onClick = { navController.navigate(WaslRoutes.NOTIFICATIONS) },
                                    modifier = Modifier.testTag("top_notifications_button")
                                ) {
                                    BadgedBox(
                                        badge = {
                                            if (unreadNotifs > 0) {
                                                Badge(containerColor = CyanAccent) {
                                                    Text(unreadNotifs.toString())
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Notifications,
                                            contentDescription = strings.navNotifications
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { navController.navigate(WaslRoutes.PROFILE) },
                                    modifier = Modifier.testTag("top_profile_button")
                                ) {
                                    Icon(Icons.Rounded.Person, contentDescription = strings.navProfile)
                                }
                                IconButton(
                                    onClick = { navController.navigate(WaslRoutes.SECURITY) },
                                    modifier = Modifier.testTag("top_security_button")
                                ) {
                                    Icon(Icons.Rounded.Security, contentDescription = strings.navSecurity)
                                }
                            }
                        )
                    }
                },
                bottomBar = {
                    if (isPrimaryTab && !useRail) {
                        NavigationBar(
                            containerColor = NavySurface,
                            windowInsets = WindowInsets.safeDrawing
                        ) {
                            tabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(tab.route) {
                                            popUpTo(WaslRoutes.CHATS) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = CyanAccent,
                                        selectedTextColor = CyanAccent,
                                        indicatorColor = ElectricBlue.copy(alpha = 0.22f),
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isPrimaryTab && useRail) {
                        NavigationRail(
                            containerColor = NavySurface,
                            modifier = Modifier
                                .fillMaxHeight()
                                .windowInsetsPadding(WindowInsets.safeDrawing)
                        ) {
                            tabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(tab.route) {
                                            popUpTo(WaslRoutes.CHATS) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = CyanAccent,
                                        selectedTextColor = CyanAccent,
                                        indicatorColor = ElectricBlue.copy(alpha = 0.22f),
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = WaslRoutes.CHATS,
                            modifier = Modifier.widthIn(max = 860.dp).fillMaxSize()
                        ) {
                            composable(WaslRoutes.CHATS) {
                                ChatsHubScreen(
                                    privateConversations = privateConvs,
                                    groupConversations = groupConvs,
                                    approvedContacts = approvedContacts,
                                    onOpenConversation = { conv ->
                                        navController.navigate("${WaslRoutes.CHAT_DETAIL}/${Uri.encode(conv.conversationId)}")
                                    },
                                    onStartPrivateChat = { peerNodeId ->
                                        viewModel.openOrCreatePrivateChat(peerNodeId) { convId ->
                                            navController.navigate("${WaslRoutes.CHAT_DETAIL}/${Uri.encode(convId)}")
                                        }
                                    },
                                    onCreateGroup = { groupName, memberIds ->
                                        viewModel.createGroup(groupName, memberIds) { convId ->
                                            navController.navigate("${WaslRoutes.CHAT_DETAIL}/${Uri.encode(convId)}")
                                        }
                                    }
                                )
                            }

                            composable(WaslRoutes.NEARBY) {
                                NearbyDevicesScreen(
                                    isMeshRunning = isMeshRunning,
                                    hasMissingPermissions = missingPermissions.isNotEmpty(),
                                    livePeers = livePeers,
                                    contacts = contacts,
                                    onRequestPermissions = requestMeshPermissions,
                                    onStartMesh = viewModel::startMeshService,
                                    onStopMesh = viewModel::stopMeshService,
                                    onScanNow = viewModel::triggerScan,
                                    onSendRequest = viewModel::sendContactRequest,
                                    onAcceptRequest = { viewModel.acceptContactRequest(it) },
                                    onRejectRequest = { viewModel.rejectContactRequest(it) },
                                    onOpenChat = { peerNodeId ->
                                        viewModel.openOrCreatePrivateChat(peerNodeId) { convId ->
                                            navController.navigate("${WaslRoutes.CHAT_DETAIL}/${Uri.encode(convId)}")
                                        }
                                    },
                                    onBlockUser = viewModel::blockUser
                                )
                            }

                            composable(WaslRoutes.DASHBOARD) {
                                DashboardScreen(
                                    localNodeId = identity.nodeId,
                                    metrics = dashboardMetrics
                                )
                            }

                            composable(WaslRoutes.FILES) {
                                FileSharingScreen(
                                    conversations = allConvs,
                                    mediaTransfers = mediaMessages,
                                    onSendMediaToConversation = { conv, uri, forceType ->
                                        viewModel.sendMediaFromUri(conv.conversationId, conv.isGroup, uri, forceType)
                                    },
                                    onOpenFile = { path, mime ->
                                        viewModel.mediaFileManager.openFileWithSystemViewer(path, mime)
                                    }
                                )
                            }

                            composable(
                                route = "${WaslRoutes.CHAT_DETAIL}/{conversationId}",
                                arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
                            ) { entry ->
                                val convId = Uri.decode(entry.arguments?.getString("conversationId").orEmpty())
                                val conv = allConvs.firstOrNull { it.conversationId == convId }
                                val isGroup = conv?.isGroup ?: convId.startsWith("group:")
                                val peerNodeId = conv?.peerNodeId ?: if (!isGroup) convId.removePrefix("peer:") else null
                                val peerContact = peerNodeId?.let { pid -> contacts.firstOrNull { it.nodeId == pid } }
                                val messages by remember(convId) {
                                    viewModel.observeMessages(convId)
                                }.collectAsStateWithLifecycle(initialValue = emptyList())

                                LaunchedEffect(convId) {
                                    viewModel.markConversationRead(convId)
                                }

                                ChatDetailScreen(
                                    conversationId = convId,
                                    title = conv?.title ?: peerContact?.displayName ?: convId,
                                    isGroup = isGroup,
                                    peerContact = peerContact,
                                    messages = messages,
                                    isRecordingVoice = isRecordingVoice,
                                    playingVoicePath = playingVoicePath,
                                    onBack = { navController.popBackStack() },
                                    onSendText = { txt -> viewModel.sendTextMessage(convId, isGroup, txt) },
                                    onSendMediaUri = { uri, type -> viewModel.sendMediaFromUri(convId, isGroup, uri, type) },
                                    onStartVoiceRecord = { viewModel.voiceRecorderManager.startRecording() },
                                    onStopAndSendVoice = {
                                        val recorded = viewModel.voiceRecorderManager.stopRecording()
                                        if (recorded != null) {
                                            viewModel.sendVoiceFile(convId, isGroup, recorded)
                                        }
                                    },
                                    onToggleVoicePlay = { path -> viewModel.voiceRecorderManager.togglePlayback(path) },
                                    onOpenFile = { path, mime -> viewModel.mediaFileManager.openFileWithSystemViewer(path, mime) },
                                    onBlockPeer = viewModel::blockUser,
                                    onClearHistory = { viewModel.clearConversationHistory(convId) }
                                )
                            }

                            composable(WaslRoutes.NOTIFICATIONS) {
                                NotificationsScreen(
                                    notifications = notifications,
                                    onBack = { navController.popBackStack() },
                                    onMarkAllRead = viewModel::markAllNotificationsRead,
                                    onAcceptContactRequest = { nodeId, notifId ->
                                        viewModel.acceptContactRequest(nodeId, notifId)
                                    },
                                    onRejectContactRequest = { nodeId, notifId ->
                                        viewModel.rejectContactRequest(nodeId, notifId)
                                    },
                                    onOpenConversation = { convId ->
                                        navController.navigate("${WaslRoutes.CHAT_DETAIL}/${Uri.encode(convId)}")
                                    }
                                )
                            }

                            composable(WaslRoutes.PROFILE) {
                                ProfileScreen(
                                    settings = settings,
                                    identity = identity,
                                    onBack = { navController.popBackStack() },
                                    onUpdateDisplayName = viewModel::updateDisplayName,
                                    onLanguageChange = viewModel::setLanguage,
                                    onRelayToggle = viewModel::updateRelayEnabled,
                                    onBatterySaverToggle = viewModel::updateBatterySaver
                                )
                            }

                            composable(WaslRoutes.SECURITY) {
                                SecuritySettingsScreen(
                                    settings = settings,
                                    blockedContacts = blockedContacts,
                                    onBack = { navController.popBackStack() },
                                    onRequireApprovalToggle = viewModel::updateRequireApproval,
                                    onMaxHopsChange = viewModel::updateMaxHops,
                                    onExpiryHoursChange = viewModel::updateMessageTtlHours,
                                    onUnblockUser = viewModel::unblockUser,
                                    onRotateKeys = viewModel::rotateIdentityKeys,
                                    onWipeAllData = viewModel::wipeAllLocalData
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
