package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.WaslApplication
import com.example.data.local.ContactEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.GroupEntity
import com.example.data.local.MessageEntity
import com.example.data.local.MessageType
import com.example.data.local.NotificationEntity
import com.example.data.local.RelationshipStatus
import com.example.data.local.UserSettings
import com.example.localization.AppLanguage
import com.example.mesh.LivePeerLink
import com.example.mesh.MeshEngine
import com.example.mesh.MeshForegroundService
import com.example.mesh.TechnologyCapability
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class IdentityUi(
    val nodeId: String,
    val fingerprint: String,
    val signingPublicKeyB64: String
)

data class ConversationUi(
    val conversationId: String,
    val isGroup: Boolean,
    val title: String,
    val peerNodeId: String?,
    val lastPreview: String,
    val lastMessageAt: Long,
    val unreadCount: Int,
    val lastHopCount: Int,
    val lastRoute: List<String>
)

data class MessageUi(
    val packetId: String,
    val conversationId: String,
    val senderNodeId: String,
    val senderName: String,
    val messageType: MessageType,
    val text: String,
    val mediaLocalPath: String?,
    val mediaMimeType: String?,
    val mediaFileName: String?,
    val mediaSizeBytes: Long,
    val timestamp: Long,
    val expiresAt: Long,
    val deliveryStatus: DeliveryStatus,
    val hopCount: Int,
    val routePath: List<String>,
    val transportUsed: String,
    val isOutgoing: Boolean
)

data class DashboardMetricsUi(
    val isMeshRunning: Boolean = false,
    val connectedDevicesCount: Int = 0,
    val nearbyAvailableCount: Int = 0,
    val activeRelayNodesCount: Int = 0,
    val avgHops: Double = 0.0,
    val maxHopsObserved: Int = 0,
    val pendingMessagesCount: Int = 0,
    val deliveredMessagesCount: Int = 0,
    val lastSuccessfulConnectionAt: Long = 0L,
    val capabilities: List<TechnologyCapability> = emptyList(),
    val recentRoutes: List<MessageUi> = emptyList(),
    val livePeers: List<LivePeerLink> = emptyList()
)

class WaslViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as WaslApplication
    private val db = app.database
    private val prefs = app.preferencesRepository
    private val cipher = app.localStorageCipher
    private val engine = app.meshEngine
    val mediaFileManager = app.mediaFileManager
    val voiceRecorderManager = app.voiceRecorderManager

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val listAdapter = moshi.adapter<List<String>>(
        Types.newParameterizedType(List::class.java, String::class.java)
    )

    val settings: StateFlow<UserSettings> = prefs.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        UserSettings()
    )

    private val _identityUi = MutableStateFlow(loadIdentityUi())
    val identityUi: StateFlow<IdentityUi> = _identityUi

    val contacts: StateFlow<List<ContactEntity>> = db.contactDao().observeAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val approvedContacts: StateFlow<List<ContactEntity>> = db.contactDao().observeApprovedContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blockedContacts: StateFlow<List<ContactEntity>> = db.contactDao().observeBlockedContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val privateConversations: StateFlow<List<ConversationUi>> = db.conversationDao()
        .observePrivateConversations()
        .map { list -> list.map { it.toUi() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groupConversations: StateFlow<List<ConversationUi>> = db.conversationDao()
        .observeGroupConversations()
        .map { list -> list.map { it.toUi() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allConversations: StateFlow<List<ConversationUi>> = db.conversationDao()
        .observeAllConversations()
        .map { list -> list.map { it.toUi() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groups: StateFlow<List<GroupEntity>> = db.groupDao().observeAllGroups()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mediaMessages: StateFlow<List<MessageUi>> = db.messageDao().observeMediaMessages()
        .map { list -> list.map { it.toUi() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = db.notificationDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotifications: StateFlow<Int> = db.notificationDao().observeUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val livePeers: StateFlow<List<LivePeerLink>> = engine.livePeers
        .map { it.values.sortedByDescending { link -> link.isConnected } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isMeshRunning: StateFlow<Boolean> = engine.isRunning

    val dashboardMetrics: StateFlow<DashboardMetricsUi> = combine(
        engine.isRunning,
        engine.livePeers,
        engine.activeRelayPeers,
        engine.capabilities,
        db.pendingPacketDao().observePendingCount(),
        db.messageDao().observeDeliveredCount(),
        db.messageDao().observeRecentRoutedMessages(),
        prefs.settingsFlow
    ) { values ->
        val running = values[0] as Boolean
        @Suppress("UNCHECKED_CAST")
        val peersMap = values[1] as Map<String, LivePeerLink>
        @Suppress("UNCHECKED_CAST")
        val relaySet = values[2] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val caps = values[3] as List<TechnologyCapability>
        val pendingCount = values[4] as Int
        val deliveredCount = values[5] as Int
        @Suppress("UNCHECKED_CAST")
        val routed = values[6] as List<MessageEntity>
        val userSettings = values[7] as UserSettings

        val peerList = peersMap.values.toList()
        val connectedPeers = peerList.count { it.isConnected }
        val hopsList = routed.map { it.hopCount }
        val avgHops = if (hopsList.isEmpty()) 0.0 else hopsList.average()
        val maxHops = hopsList.maxOrNull() ?: 0

        DashboardMetricsUi(
            isMeshRunning = running,
            connectedDevicesCount = connectedPeers,
            nearbyAvailableCount = peerList.size,
            activeRelayNodesCount = relaySet.size,
            avgHops = avgHops,
            maxHopsObserved = maxHops,
            pendingMessagesCount = pendingCount,
            deliveredMessagesCount = deliveredCount,
            lastSuccessfulConnectionAt = userSettings.lastSuccessfulConnectionAt,
            capabilities = caps,
            recentRoutes = routed.map { it.toUi() },
            livePeers = peerList
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetricsUi())

    init {
        engine.refreshCapabilities()
    }

    fun observeMessages(conversationId: String): Flow<List<MessageUi>> =
        db.messageDao().observeMessages(conversationId).map { list -> list.map { it.toUi() } }

    fun completeRegistration(displayName: String, language: AppLanguage) {
        viewModelScope.launch {
            prefs.completeRegistration(displayName, language)
            _identityUi.value = loadIdentityUi()
            MeshForegroundService.start(app)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { prefs.updateLanguage(language) }
    }

    fun updateDisplayName(name: String) {
        viewModelScope.launch { prefs.updateDisplayName(name) }
    }

    fun updateRelayEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.updateRelayEnabled(enabled) }
    }

    fun updateBatterySaver(enabled: Boolean) {
        viewModelScope.launch { prefs.updateBatterySaverScan(enabled) }
    }

    fun updateRequireApproval(required: Boolean) {
        viewModelScope.launch { prefs.updateRequireContactApproval(required) }
    }

    fun updateMaxHops(hops: Int) {
        viewModelScope.launch { prefs.updateMaxHops(hops) }
    }

    fun updateMessageTtlHours(hours: Int) {
        viewModelScope.launch { prefs.updateMessageTtlHours(hours) }
    }

    fun startMeshService() {
        engine.refreshCapabilities()
        MeshForegroundService.start(app)
    }

    fun stopMeshService() {
        MeshForegroundService.stop(app)
    }

    fun triggerScan() {
        engine.triggerImmediateScan()
    }

    fun refreshCapabilities() {
        engine.refreshCapabilities()
    }

    fun sendContactRequest(nodeId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            engine.sendContactRequest(nodeId)
        }
    }

    fun acceptContactRequest(nodeId: String, notificationId: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            engine.acceptContactRequest(nodeId)
            notificationId?.let { db.notificationDao().markActionHandled(it) }
        }
    }

    fun rejectContactRequest(nodeId: String, notificationId: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            db.contactDao().updateRelationship(nodeId, RelationshipStatus.DISCOVERED.name)
            notificationId?.let { db.notificationDao().markActionHandled(it) }
        }
    }

    fun blockUser(nodeId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.contactDao().updateRelationship(nodeId, RelationshipStatus.BLOCKED.name)
        }
    }

    fun unblockUser(nodeId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.contactDao().updateRelationship(nodeId, RelationshipStatus.DISCOVERED.name)
        }
    }

    fun markConversationRead(conversationId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.conversationDao().markRead(conversationId)
        }
    }

    fun openOrCreatePrivateChat(peerNodeId: String, onReady: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val contact = db.contactDao().getById(peerNodeId) ?: return@launch
            val convId = MeshEngine.privateConversationId(peerNodeId)
            if (db.conversationDao().getById(convId) == null) {
                db.conversationDao().upsert(
                    ConversationEntity(
                        conversationId = convId,
                        isGroup = false,
                        title = contact.displayName,
                        peerNodeId = peerNodeId,
                        lastMessageAt = System.currentTimeMillis()
                    )
                )
            }
            viewModelScope.launch(Dispatchers.Main) { onReady(convId) }
        }
    }

    fun createGroup(name: String, memberNodeIds: List<String>, onCreated: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val convId = engine.createGroup(name, memberNodeIds)
            viewModelScope.launch(Dispatchers.Main) { onCreated(convId) }
        }
    }

    fun sendTextMessage(conversationId: String, isGroup: Boolean, text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            if (isGroup) {
                val groupId = conversationId.removePrefix("group:")
                engine.sendGroupMessage(groupId, trimmed, MessageType.TEXT)
            } else {
                val peerNodeId = conversationId.removePrefix("peer:")
                engine.sendPrivateMessage(peerNodeId, trimmed, MessageType.TEXT)
            }
        }
    }

    fun sendMediaFromUri(conversationId: String, isGroup: Boolean, uri: Uri, forceType: MessageType? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val info = mediaFileManager.copyUriToPrivateMedia(uri) ?: return@launch
            val detectedType = forceType ?: when {
                info.mimeType.startsWith("image/") -> MessageType.IMAGE
                info.mimeType.startsWith("video/") -> MessageType.VIDEO
                info.mimeType.startsWith("audio/") -> MessageType.VOICE
                else -> MessageType.FILE
            }
            if (isGroup) {
                val groupId = conversationId.removePrefix("group:")
                engine.sendGroupMessage(
                    groupId = groupId,
                    text = "",
                    messageType = detectedType,
                    mediaFile = info.file,
                    mediaMimeType = info.mimeType,
                    mediaFileName = info.fileName
                )
            } else {
                val peerNodeId = conversationId.removePrefix("peer:")
                engine.sendPrivateMessage(
                    peerNodeId = peerNodeId,
                    text = "",
                    messageType = detectedType,
                    mediaFile = info.file,
                    mediaMimeType = info.mimeType,
                    mediaFileName = info.fileName
                )
            }
        }
    }

    fun sendVoiceFile(conversationId: String, isGroup: Boolean, file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            if (isGroup) {
                val groupId = conversationId.removePrefix("group:")
                engine.sendGroupMessage(
                    groupId = groupId,
                    text = "",
                    messageType = MessageType.VOICE,
                    mediaFile = file,
                    mediaMimeType = "audio/mp4",
                    mediaFileName = file.name
                )
            } else {
                val peerNodeId = conversationId.removePrefix("peer:")
                engine.sendPrivateMessage(
                    peerNodeId = peerNodeId,
                    text = "",
                    messageType = MessageType.VOICE,
                    mediaFile = file,
                    mediaMimeType = "audio/mp4",
                    mediaFileName = file.name
                )
            }
        }
    }

    fun clearConversationHistory(conversationId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.messageDao().deleteByConversation(conversationId)
            db.conversationDao().deleteById(conversationId)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch(Dispatchers.IO) {
            db.notificationDao().markAllRead()
        }
    }

    fun rotateIdentityKeys() {
        engine.rotateIdentityKeys()
        _identityUi.value = loadIdentityUi()
    }

    fun wipeAllLocalData() {
        viewModelScope.launch(Dispatchers.IO) {
            engine.stopMesh()
            db.messageDao().deleteAll()
            db.conversationDao().deleteAll()
            db.groupDao().deleteAll()
            db.contactDao().deleteAll()
            db.pendingPacketDao().deleteAll()
            db.seenPacketDao().deleteAll()
            db.notificationDao().deleteAll()
            mediaFileManager.wipeAllMedia()
            app.keystoreManager.clearAllKeys()
            prefs.clearAll()
            _identityUi.value = loadIdentityUi()
        }
    }

    private fun loadIdentityUi(): IdentityUi {
        val id = engine.currentIdentity()
        return IdentityUi(
            nodeId = id.nodeId,
            fingerprint = id.fingerprint,
            signingPublicKeyB64 = id.signingPublicKeyB64
        )
    }

    private fun ConversationEntity.toUi(): ConversationUi {
        val route = try {
            listAdapter.fromJson(lastRouteJson).orEmpty()
        } catch (_: Exception) {
            emptyList()
        }
        return ConversationUi(
            conversationId = conversationId,
            isGroup = isGroup,
            title = title,
            peerNodeId = peerNodeId,
            lastPreview = cipher.decryptText(lastMessagePreviewEnc),
            lastMessageAt = lastMessageAt,
            unreadCount = unreadCount,
            lastHopCount = lastHopCount,
            lastRoute = route
        )
    }

    private fun MessageEntity.toUi(): MessageUi {
        val route = try {
            listAdapter.fromJson(routePathJson).orEmpty()
        } catch (_: Exception) {
            emptyList()
        }
        return MessageUi(
            packetId = packetId,
            conversationId = conversationId,
            senderNodeId = senderNodeId,
            senderName = senderName,
            messageType = runCatching { MessageType.valueOf(messageType) }.getOrDefault(MessageType.TEXT),
            text = cipher.decryptText(contentEnc),
            mediaLocalPath = mediaLocalPath,
            mediaMimeType = mediaMimeType,
            mediaFileName = mediaFileName,
            mediaSizeBytes = mediaSizeBytes,
            timestamp = timestamp,
            expiresAt = expiresAt,
            deliveryStatus = runCatching { DeliveryStatus.valueOf(deliveryStatus) }.getOrDefault(DeliveryStatus.QUEUED),
            hopCount = hopCount,
            routePath = route,
            transportUsed = transportUsed,
            isOutgoing = isOutgoing
        )
    }
}
