package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ContactEntity
import com.example.data.local.RelationshipStatus
import com.example.localization.LocalStrings
import com.example.mesh.LivePeerLink
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.MeshRadarCanvas
import com.example.ui.components.PermissionBannerCard
import com.example.ui.components.StatusPill
import com.example.ui.components.TransportBadge
import com.example.ui.components.WaslCard
import com.example.ui.theme.AmberRelaying
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun NearbyDevicesScreen(
    isMeshRunning: Boolean,
    hasMissingPermissions: Boolean,
    livePeers: List<LivePeerLink>,
    contacts: List<ContactEntity>,
    onRequestPermissions: () -> Unit,
    onStartMesh: () -> Unit,
    onStopMesh: () -> Unit,
    onScanNow: () -> Unit,
    onSendRequest: (String) -> Unit,
    onAcceptRequest: (String) -> Unit,
    onRejectRequest: (String) -> Unit,
    onOpenChat: (String) -> Unit,
    onBlockUser: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val visibleContacts = contacts.filter { it.relationshipStatus != RelationshipStatus.BLOCKED.name }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (hasMissingPermissions) {
            item {
                PermissionBannerCard(onGrantPermissions = onRequestPermissions)
            }
        }

        // Radar & Controls Card
        item {
            WaslCard(modifier = Modifier.fillMaxWidth(), containerColor = NavySurfaceElevated) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.nearbyTitle, style = MaterialTheme.typography.titleLarge)
                        StatusPill(
                            label = if (isMeshRunning) strings.meshServiceActive else strings.meshServicePaused,
                            color = if (isMeshRunning) TealMeshOnline else AmberRelaying
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    MeshRadarCanvas(
                        isScanning = isMeshRunning,
                        peers = livePeers,
                        modifier = Modifier
                            .size(185.dp)
                            .testTag("mesh_radar_canvas")
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = if (isMeshRunning) strings.scanningActiveLabel else strings.additionalRelayHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { if (isMeshRunning) onStopMesh() else onStartMesh() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("toggle_mesh_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isMeshRunning) CoralAlert else ElectricBlue,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = if (isMeshRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(if (isMeshRunning) strings.stopMeshBtn else strings.startMeshBtn)
                        }
                        OutlinedButton(
                            onClick = onScanNow,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("scan_now_button")
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.scanNowBtn)
                        }
                    }
                }
            }
        }

        // Live radio links discovered across transports
        if (livePeers.isNotEmpty()) {
            item {
                Text(
                    text = "${strings.nearbyDevicesFound} (${livePeers.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyanAccent
                )
            }
            items(livePeers, key = { "${it.transport.wireName}:${it.endpointKey}" }) { link ->
                WaslCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(link.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = link.nodeId ?: link.endpointKey,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = link.rssiDbm?.let {
                                    String.format(strings.signalRssiEstimatedOnly, it)
                                } ?: strings.signalUnknownNotVerified,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            TransportBadge(link.transport)
                            StatusPill(
                                label = if (link.isConnected) strings.directLinkLabel else strings.nearbyAvailableMetric,
                                color = if (link.isConnected) TealMeshOnline else CyanAccent
                            )
                        }
                    }
                }
            }
        }

        // Known Mesh Contacts / Nodes
        if (visibleContacts.isNotEmpty()) {
            item {
                Text(
                    text = strings.approvedContact,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            items(visibleContacts, key = { it.nodeId }) { contact ->
                ContactActionCard(
                    contact = contact,
                    onSendRequest = { onSendRequest(contact.nodeId) },
                    onAcceptRequest = { onAcceptRequest(contact.nodeId) },
                    onRejectRequest = { onRejectRequest(contact.nodeId) },
                    onOpenChat = { onOpenChat(contact.nodeId) },
                    onBlockUser = { onBlockUser(contact.nodeId) }
                )
            }
        }

        if (livePeers.isEmpty() && visibleContacts.isEmpty()) {
            item {
                EmptyStatePanel(
                    icon = Icons.Rounded.Radar,
                    title = strings.noNearbyPeersTitle,
                    body = strings.noNearbyPeersBody
                )
            }
        }
    }
}

@Composable
private fun ContactActionCard(
    contact: ContactEntity,
    onSendRequest: () -> Unit,
    onAcceptRequest: () -> Unit,
    onRejectRequest: () -> Unit,
    onOpenChat: () -> Unit,
    onBlockUser: () -> Unit
) {
    val strings = LocalStrings.current
    val status = runCatching { RelationshipStatus.valueOf(contact.relationshipStatus) }
        .getOrDefault(RelationshipStatus.DISCOVERED)

    WaslCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Devices, contentDescription = null, tint = CyanAccent)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(contact.displayName, style = MaterialTheme.typography.titleMedium)
                        Text(contact.nodeId, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
                StatusPill(
                    label = if (contact.hopDistance <= 1) strings.directLinkLabel else "${contact.hopDistance} ${strings.hopsUnit}",
                    color = if (contact.isDirectlyConnected) TealMeshOnline else CyanAccent
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (status) {
                    RelationshipStatus.DISCOVERED -> {
                        Button(
                            onClick = onSendRequest,
                            modifier = Modifier.weight(1f).testTag("send_request_${contact.nodeId}")
                        ) {
                            Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.sendContactRequest)
                        }
                    }
                    RelationshipStatus.REQUEST_SENT -> {
                        StatusPill(label = strings.requestSent, color = AmberRelaying)
                        Spacer(Modifier.weight(1f))
                    }
                    RelationshipStatus.REQUEST_RECEIVED -> {
                        Button(
                            onClick = onAcceptRequest,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TealMeshOnline, contentColor = Color.Black)
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.acceptRequest)
                        }
                        OutlinedButton(onClick = onRejectRequest, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.rejectRequest)
                        }
                    }
                    RelationshipStatus.APPROVED -> {
                        Button(
                            onClick = onOpenChat,
                            modifier = Modifier.weight(1f).testTag("open_chat_${contact.nodeId}")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.navChats)
                        }
                    }
                    RelationshipStatus.BLOCKED -> Unit
                }
                IconButton(onClick = onBlockUser) {
                    Icon(Icons.Rounded.Block, contentDescription = strings.blockUser, tint = CoralAlert)
                }
            }
        }
    }
}
