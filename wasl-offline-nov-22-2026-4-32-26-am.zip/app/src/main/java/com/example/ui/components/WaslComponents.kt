package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.LocalStrings
import com.example.mesh.LivePeerLink
import com.example.mesh.TransportType
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WaslCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NavyOutline.copy(alpha = 0.65f),
    containerColor: Color = NavySurface,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        content()
    }
}

@Composable
fun StatusPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (leadingIcon != null) {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(14.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(color)
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TransportBadge(transport: TransportType) {
    val icon = when (transport) {
        TransportType.BLE -> Icons.Rounded.Bluetooth
        TransportType.BLUETOOTH_CLASSIC -> Icons.Rounded.Bluetooth
        TransportType.WIFI_DIRECT -> Icons.Rounded.WifiTethering
        TransportType.NEARBY_CONNECTIONS -> Icons.Rounded.NearMe
    }
    val label = when (transport) {
        TransportType.BLE -> "BLE"
        TransportType.BLUETOOTH_CLASSIC -> "BT Classic"
        TransportType.WIFI_DIRECT -> "Wi-Fi P2P"
        TransportType.NEARBY_CONNECTIONS -> "Nearby"
    }
    StatusPill(label = label, color = CyanAccent, leadingIcon = icon)
}

@Composable
fun PermissionBannerCard(
    onGrantPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    WaslCard(
        modifier = modifier.fillMaxWidth(),
        borderColor = CyanAccent.copy(alpha = 0.55f),
        containerColor = NavySurfaceElevated
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Security,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = strings.permissionGrantTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = strings.permissionGrantBody,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onGrantPermissions,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("grant_permissions_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricBlue,
                    contentColor = Color.White
                )
            ) {
                Text(strings.grantPermissionsBtn)
            }
        }
    }
}

@Composable
fun MeshRadarCanvas(
    isScanning: Boolean,
    peers: List<LivePeerLink>,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "radar")
    val pulse by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )
    val sweep by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = (minOf(size.width, size.height) / 2f) * 0.9f

            // Background glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ElectricBlue.copy(alpha = 0.22f), Color.Transparent),
                    center = center,
                    radius = maxRadius
                ),
                radius = maxRadius,
                center = center
            )

            // Static concentric rings
            listOf(0.35f, 0.65f, 0.95f).forEach { factor ->
                drawCircle(
                    color = NavyOutline.copy(alpha = 0.7f),
                    radius = maxRadius * factor,
                    center = center,
                    style = Stroke(width = 1.5f)
                )
            }

            if (isScanning) {
                val r1 = maxRadius * pulse
                drawCircle(
                    color = CyanAccent.copy(alpha = (1f - pulse) * 0.65f),
                    radius = r1,
                    center = center,
                    style = Stroke(width = 3f)
                )
                val radAngle = (sweep * PI / 180.0)
                val endX = center.x + (maxRadius * cos(radAngle)).toFloat()
                val endY = center.y + (maxRadius * sin(radAngle)).toFloat()
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(CyanAccent.copy(alpha = 0.85f), Color.Transparent),
                        start = center,
                        end = Offset(endX, endY)
                    ),
                    start = center,
                    end = Offset(endX, endY),
                    strokeWidth = 3f,
                    cap = StrokeCap.Round
                )
            }

            // Plot live discovered/connected peer dots deterministically around center
            peers.take(12).forEachIndexed { idx, peer ->
                val angle = (idx * (360.0 / maxOf(peers.size, 1)) - 90.0) * PI / 180.0
                val ringFactor = if (peer.isConnected) 0.42f else 0.78f
                val px = center.x + (maxRadius * ringFactor * cos(angle)).toFloat()
                val py = center.y + (maxRadius * ringFactor * sin(angle)).toFloat()
                val dotColor = if (peer.isConnected) TealMeshOnline else CyanAccent
                drawLine(
                    color = dotColor.copy(alpha = if (peer.isConnected) 0.55f else 0.22f),
                    start = center,
                    end = Offset(px, py),
                    strokeWidth = if (peer.isConnected) 2.5f else 1.2f
                )
                drawCircle(
                    color = dotColor,
                    radius = if (peer.isConnected) 11f else 8f,
                    center = Offset(px, py)
                )
            }

            // Local device center beacon
            drawCircle(
                color = ElectricBlue,
                radius = 16f,
                center = center
            )
            drawCircle(
                color = CyanAccent,
                radius = 7f,
                center = center
            )
        }
    }
}

@Composable
fun MeshTopologyCanvas(
    localNodeId: String,
    peers: List<LivePeerLink>,
    relayNodeIdsCount: Int,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(NavyBackground)
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = minOf(size.width, size.height) * 0.36f

        peers.take(8).forEachIndexed { idx, peer ->
            val angle = (idx * (360.0 / maxOf(peers.size, 1)) - 45.0) * PI / 180.0
            val p = Offset(
                x = center.x + (radius * cos(angle)).toFloat(),
                y = center.y + (radius * sin(angle)).toFloat()
            )
            val linkColor = if (peer.isConnected) TealMeshOnline else CyanAccent.copy(alpha = 0.4f)
            drawLine(
                color = linkColor,
                start = center,
                end = p,
                strokeWidth = if (peer.isConnected) 4f else 2f
            )
            drawCircle(color = linkColor, radius = 14f, center = p)
        }

        // Local central node
        drawCircle(color = ElectricBlue.copy(alpha = 0.3f), radius = 34f, center = center)
        drawCircle(color = ElectricBlue, radius = 20f, center = center)
        drawCircle(color = Color.White, radius = 6f, center = center)
    }
}

@Composable
fun EmptyStatePanel(
    icon: ImageVector,
    title: String,
    body: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(ElectricBlue.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun E2eeShieldNote(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ElectricBlue.copy(alpha = 0.1f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.Lock,
            contentDescription = null,
            tint = CyanAccent,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

fun formatTimestamp(ts: Long): String {
    if (ts <= 0L) return "—"
    val fmt = SimpleDateFormat("HH:mm • dd MMM", Locale.getDefault())
    return fmt.format(Date(ts))
}

fun formatShortTime(ts: Long): String {
    if (ts <= 0L) return ""
    val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    return fmt.format(Date(ts))
}

fun formatBytes(bytes: Long): String {
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
        else -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    }
}
