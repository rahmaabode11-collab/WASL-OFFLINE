package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.local.ContactEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.MessageType
import com.example.localization.LocalStrings
import com.example.ui.MessageUi
import com.example.ui.components.E2eeShieldNote
import com.example.ui.components.formatBytes
import com.example.ui.components.formatShortTime
import com.example.ui.theme.AmberRelaying
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    conversationId: String,
    title: String,
    isGroup: Boolean,
    peerContact: ContactEntity?,
    messages: List<MessageUi>,
    isRecordingVoice: Boolean,
    playingVoicePath: String?,
    onBack: () -> Unit,
    onSendText: (String) -> Unit,
    onSendMediaUri: (Uri, MessageType?) -> Unit,
    onStartVoiceRecord: () -> Unit,
    onStopAndSendVoice: () -> Unit,
    onToggleVoicePlay: (String) -> Unit,
    onOpenFile: (String, String?) -> Unit,
    onBlockPeer: (String) -> Unit,
    onClearHistory: () -> Unit
) {
    val strings = LocalStrings.current
    val context = LocalContext.current
    var draft by remember { mutableStateOf("") }
    var menuExpanded by remember { mutableStateOf(false) }
    var inspectRouteMessage by remember { mutableStateOf<MessageUi?>(null) }
    var showFingerprintDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    BackHandler(onBack = onBack)

    val visualMediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { onSendMediaUri(it, null) }
    }

    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { onSendMediaUri(it, MessageType.FILE) }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onStartVoiceRecord()
    }

    Scaffold(
        containerColor = NavyBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back)
                    }
                },
                title = {
                    Column {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        val subtitle = when {
                            peerContact?.isDirectlyConnected == true ->
                                "${strings.directLinkLabel} • ${peerContact.lastTransport}"
                            peerContact != null -> peerContact.nodeId
                            else -> strings.groupChatsTab
                        }
                        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                            containerColor = NavySurfaceElevated
                        ) {
                            if (!isGroup && peerContact != null) {
                                DropdownMenuItem(
                                    text = { Text(strings.verifyFingerprint) },
                                    leadingIcon = { Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = CyanAccent) },
                                    onClick = {
                                        menuExpanded = false
                                        showFingerprintDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.blockUser, color = CoralAlert) },
                                    leadingIcon = { Icon(Icons.Rounded.Block, contentDescription = null, tint = CoralAlert) },
                                    onClick = {
                                        menuExpanded = false
                                        onBlockPeer(peerContact.nodeId)
                                        onBack()
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text(strings.clearChat) },
                                leadingIcon = { Icon(Icons.Rounded.DeleteOutline, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    onClearHistory()
                                    onBack()
                                }
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                color = NavySurface,
                tonalElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .imePadding()
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    if (isRecordingVoice) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(CoralAlert.copy(alpha = 0.16f))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Mic, contentDescription = null, tint = CoralAlert)
                                Spacer(Modifier.width(8.dp))
                                Text(strings.recordingVoice, color = CoralAlert, style = MaterialTheme.typography.labelLarge)
                            }
                            TextButton(
                                onClick = onStopAndSendVoice,
                                modifier = Modifier.testTag("stop_voice_record_button")
                            ) {
                                Icon(Icons.Rounded.Stop, contentDescription = null, tint = CyanAccent)
                                Spacer(Modifier.width(4.dp))
                                Text(strings.tapToStopRecord, color = CyanAccent)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    visualMediaPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                    )
                                },
                                modifier = Modifier.testTag("attach_media_button")
                            ) {
                                Icon(Icons.Rounded.Image, contentDescription = strings.imageAttachmentLabel, tint = CyanAccent)
                            }
                            IconButton(
                                onClick = { documentPicker.launch(arrayOf("*/*")) },
                                modifier = Modifier.testTag("attach_file_button")
                            ) {
                                Icon(Icons.Rounded.AttachFile, contentDescription = strings.fileAttachmentLabel, tint = CyanAccent)
                            }
                            OutlinedTextField(
                                value = draft,
                                onValueChange = { draft = it },
                                placeholder = { Text(strings.messageHint, color = TextMuted) },
                                maxLines = 4,
                                shape = RoundedCornerShape(22.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanAccent,
                                    unfocusedBorderColor = NavyOutline,
                                    focusedContainerColor = NavyBackground,
                                    unfocusedContainerColor = NavyBackground
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("message_composer_input")
                            )
                            if (draft.isBlank()) {
                                IconButton(
                                    onClick = {
                                        val granted = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (granted) onStartVoiceRecord()
                                        else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(NavySurfaceElevated)
                                        .testTag("record_voice_button")
                                ) {
                                    Icon(Icons.Rounded.Mic, contentDescription = strings.voiceMessageLabel, tint = CyanAccent)
                                }
                            } else {
                                IconButton(
                                    onClick = {
                                        onSendText(draft)
                                        draft = ""
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(ElectricBlue)
                                        .testTag("send_message_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = strings.send, tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                E2eeShieldNote(strings.e2eeActiveTitle)
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.packetId }) { msg ->
                    MessageBubble(
                        msg = msg,
                        isGroup = isGroup,
                        isPlaying = msg.mediaLocalPath != null && msg.mediaLocalPath == playingVoicePath,
                        onToggleVoice = { msg.mediaLocalPath?.let(onToggleVoicePlay) },
                        onOpenFile = { msg.mediaLocalPath?.let { p -> onOpenFile(p, msg.mediaMimeType) } },
                        onInspectRoute = { inspectRouteMessage = msg }
                    )
                }
            }
        }
    }

    inspectRouteMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { inspectRouteMessage = null },
            containerColor = NavySurfaceElevated,
            title = { Text(strings.routeLabel) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${strings.hopsUnit}: ${msg.hopCount}", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                    if (msg.transportUsed.isNotBlank()) {
                        Text("Transport: ${msg.transportUsed}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    if (msg.routePath.isEmpty()) {
                        Text(strings.directLinkLabel, style = MaterialTheme.typography.bodyMedium)
                    } else {
                        Text(
                            text = msg.routePath.joinToString("  →  "),
                            style = MaterialTheme.typography.labelSmall,
                            color = TealMeshOnline
                        )
                    }
                    if (msg.deliveryStatus == DeliveryStatus.EXPIRED || msg.deliveryStatus == DeliveryStatus.FAILED) {
                        Text(strings.undeliveredExplanation, style = MaterialTheme.typography.bodySmall, color = CoralAlert)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { inspectRouteMessage = null }) { Text(strings.confirmBtn) }
            }
        )
    }

    if (showFingerprintDialog && peerContact != null) {
        AlertDialog(
            onDismissRequest = { showFingerprintDialog = false },
            containerColor = NavySurfaceElevated,
            title = { Text(strings.verifyFingerprint) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(peerContact.displayName, style = MaterialTheme.typography.titleMedium)
                    Text(peerContact.nodeId, style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    Text(peerContact.fingerprint, style = MaterialTheme.typography.labelSmall, color = TealMeshOnline)
                }
            },
            confirmButton = {
                TextButton(onClick = { showFingerprintDialog = false }) { Text(strings.confirmBtn) }
            }
        )
    }
}

@Composable
private fun MessageBubble(
    msg: MessageUi,
    isGroup: Boolean,
    isPlaying: Boolean,
    onToggleVoice: () -> Unit,
    onOpenFile: () -> Unit,
    onInspectRoute: () -> Unit
) {
    val strings = LocalStrings.current
    val align = if (msg.isOutgoing) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleColor = if (msg.isOutgoing) ElectricBlue.copy(alpha = 0.28f) else NavySurfaceElevated
    val shape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (msg.isOutgoing) 18.dp else 4.dp,
        bottomEnd = if (msg.isOutgoing) 4.dp else 18.dp
    )

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = align) {
        Column(
            modifier = Modifier
                .widthIn(max = 310.dp)
                .clip(shape)
                .background(bubbleColor)
                .clickable(onClick = onInspectRoute)
                .padding(12.dp)
        ) {
            if (isGroup && !msg.isOutgoing) {
                Text(msg.senderName, style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                Spacer(Modifier.height(4.dp))
            }

            when (msg.messageType) {
                MessageType.IMAGE -> {
                    val path = msg.mediaLocalPath
                    if (path != null && File(path).exists()) {
                        AsyncImage(
                            model = File(path),
                            contentDescription = msg.mediaFileName ?: strings.imageAttachmentLabel,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(170.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(onClick = onOpenFile)
                        )
                    } else {
                        AttachmentStub(Icons.Rounded.Image, msg.mediaFileName ?: strings.imageAttachmentLabel, msg.mediaSizeBytes, onOpenFile)
                    }
                }
                MessageType.VIDEO -> {
                    AttachmentStub(Icons.Rounded.Videocam, msg.mediaFileName ?: strings.videoAttachmentLabel, msg.mediaSizeBytes, onOpenFile)
                }
                MessageType.VOICE -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NavySurface)
                            .clickable(onClick = onToggleVoice)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = strings.voiceMessageLabel,
                            tint = CyanAccent
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(strings.voiceMessageLabel, style = MaterialTheme.typography.labelLarge)
                            Text(formatBytes(msg.mediaSizeBytes), style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                    }
                }
                MessageType.FILE -> {
                    AttachmentStub(Icons.Rounded.AttachFile, msg.mediaFileName ?: strings.fileAttachmentLabel, msg.mediaSizeBytes, onOpenFile)
                }
                MessageType.TEXT -> Unit
            }

            if (msg.text.isNotBlank()) {
                Text(
                    text = msg.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = formatShortTime(msg.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
                if (msg.hopCount > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Hub, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("${msg.hopCount}", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                }
                if (msg.isOutgoing) {
                    val (statusIcon, statusTint) = when (msg.deliveryStatus) {
                        DeliveryStatus.QUEUED -> Icons.Rounded.Schedule to TextMuted
                        DeliveryStatus.RELAYING -> Icons.Rounded.Done to AmberRelaying
                        DeliveryStatus.DELIVERED_DIRECT -> Icons.Rounded.DoneAll to TealMeshOnline
                        DeliveryStatus.DELIVERED_MESH -> Icons.Rounded.DoneAll to CyanAccent
                        DeliveryStatus.EXPIRED, DeliveryStatus.FAILED -> Icons.Rounded.ErrorOutline to CoralAlert
                    }
                    Icon(
                        imageVector = statusIcon,
                        contentDescription = msg.deliveryStatus.name,
                        tint = statusTint,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
            if (msg.deliveryStatus == DeliveryStatus.EXPIRED || msg.deliveryStatus == DeliveryStatus.FAILED) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = strings.statusExpired,
                    style = MaterialTheme.typography.labelSmall,
                    color = CoralAlert
                )
            }
        }
    }
}

@Composable
private fun AttachmentStub(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    name: String,
    sizeBytes: Long,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NavySurface)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = CyanAccent)
        Spacer(Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.labelLarge, maxLines = 1)
            Text(formatBytes(sizeBytes), style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
    }
}
