package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ContactEntity
import com.example.localization.LocalStrings
import com.example.ui.ConversationUi
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.StatusPill
import com.example.ui.components.WaslCard
import com.example.ui.components.formatShortTime
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun ChatsHubScreen(
    privateConversations: List<ConversationUi>,
    groupConversations: List<ConversationUi>,
    approvedContacts: List<ContactEntity>,
    onOpenConversation: (ConversationUi) -> Unit,
    onStartPrivateChat: (String) -> Unit,
    onCreateGroup: (String, List<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }

    val list = if (selectedTab == 0) privateConversations else groupConversations
    val filtered = remember(list, searchQuery) {
        if (searchQuery.isBlank()) list
        else list.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                it.lastPreview.contains(searchQuery, ignoreCase = true)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = NavySurface,
                contentColor = CyanAccent,
                indicator = { positions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(positions[selectedTab]),
                        color = CyanAccent
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    modifier = Modifier.testTag("tab_private_chats"),
                    text = { Text(strings.privateChatsTab) },
                    icon = {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.Chat,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    modifier = Modifier.testTag("tab_group_chats"),
                    text = { Text(strings.groupChatsTab) },
                    icon = {
                        Icon(
                            imageVector = Icons.Rounded.Group,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchConversations, color = TextMuted) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = TextMuted) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = NavyOutline,
                    focusedContainerColor = NavySurface,
                    unfocusedContainerColor = NavySurface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("search_conversations_input")
            )

            if (filtered.isEmpty()) {
                EmptyStatePanel(
                    icon = if (selectedTab == 0) Icons.AutoMirrored.Rounded.Chat else Icons.Rounded.Group,
                    title = if (selectedTab == 0) strings.noConversationsTitle else strings.noGroupsTitle,
                    body = if (selectedTab == 0) strings.noConversationsBody else strings.noGroupsBody,
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.conversationId }) { conv ->
                        ConversationRowCard(
                            conv = conv,
                            onClick = { onOpenConversation(conv) }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                if (selectedTab == 0) showNewChatDialog = true
                else showCreateGroupDialog = true
            },
            containerColor = ElectricBlue,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag(if (selectedTab == 0) "fab_new_chat" else "fab_create_group")
        ) {
            Icon(
                imageVector = if (selectedTab == 0) Icons.Rounded.Add else Icons.Rounded.GroupAdd,
                contentDescription = if (selectedTab == 0) strings.newChat else strings.createGroup
            )
        }
    }

    if (showNewChatDialog) {
        AlertDialog(
            onDismissRequest = { showNewChatDialog = false },
            containerColor = NavySurfaceElevated,
            title = { Text(strings.newChat) },
            text = {
                if (approvedContacts.isEmpty()) {
                    Text(strings.noApprovedContactsForGroup, color = TextSecondary)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        approvedContacts.forEach { contact ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(NavySurface)
                                    .clickable {
                                        showNewChatDialog = false
                                        onStartPrivateChat(contact.nodeId)
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Person, contentDescription = null, tint = CyanAccent)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(contact.displayName, style = MaterialTheme.typography.titleMedium)
                                    Text(contact.nodeId, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNewChatDialog = false }) { Text(strings.cancelBtn) }
            }
        )
    }

    if (showCreateGroupDialog) {
        CreateGroupDialog(
            approvedContacts = approvedContacts,
            onDismiss = { showCreateGroupDialog = false },
            onCreate = { groupName, memberIds ->
                showCreateGroupDialog = false
                onCreateGroup(groupName, memberIds)
            }
        )
    }
}

@Composable
private fun ConversationRowCard(
    conv: ConversationUi,
    onClick: () -> Unit
) {
    val strings = LocalStrings.current
    WaslCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("conversation_card_${conv.conversationId}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(ElectricBlue.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (conv.isGroup) Icons.Rounded.Group else Icons.Rounded.Person,
                    contentDescription = null,
                    tint = CyanAccent
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = conv.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (conv.lastMessageAt > 0L) {
                        Text(
                            text = formatShortTime(conv.lastMessageAt),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = TealMeshOnline,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = conv.lastPreview.ifBlank { conv.peerNodeId ?: conv.conversationId },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (conv.lastHopCount > 0) {
                        StatusPill(
                            label = "${conv.lastHopCount} ${strings.hopsUnit}",
                            color = CyanAccent,
                            leadingIcon = Icons.Rounded.Hub
                        )
                    }
                    if (conv.unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(CyanAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = conv.unreadCount.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateGroupDialog(
    approvedContacts: List<ContactEntity>,
    onDismiss: () -> Unit,
    onCreate: (String, List<String>) -> Unit
) {
    val strings = LocalStrings.current
    var groupName by remember { mutableStateOf("") }
    val selectedIds = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavySurfaceElevated,
        title = { Text(strings.createGroup) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    label = { Text(strings.groupNameLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_name_input")
                )
                Text(strings.selectMembers, style = MaterialTheme.typography.labelLarge)
                if (approvedContacts.isEmpty()) {
                    Text(strings.noApprovedContactsForGroup, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                } else {
                    approvedContacts.forEach { contact ->
                        val checked = selectedIds.contains(contact.nodeId)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    if (checked) selectedIds.remove(contact.nodeId)
                                    else selectedIds.add(contact.nodeId)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    if (it) selectedIds.add(contact.nodeId) else selectedIds.remove(contact.nodeId)
                                }
                            )
                            Column {
                                Text(contact.displayName, style = MaterialTheme.typography.bodyMedium)
                                Text(contact.nodeId, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (groupName.trim().length >= 2) {
                        onCreate(groupName.trim(), selectedIds.toList())
                    }
                },
                enabled = groupName.trim().length >= 2,
                modifier = Modifier.testTag("confirm_create_group_button")
            ) {
                Text(strings.createGroupBtn)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancelBtn) }
        }
    )
}
