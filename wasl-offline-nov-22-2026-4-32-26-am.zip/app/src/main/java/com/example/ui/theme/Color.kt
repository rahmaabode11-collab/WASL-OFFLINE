package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WASL OFFLINE Dark Navy & Cyan/Electric Blue Palette
val NavyVoid = Color(0xFF050D1A)
val NavyBackground = Color(0xFF071224)
val NavySurface = Color(0xFF0D1B33)
val NavySurfaceElevated = Color(0xFF132544)
val NavySurfaceHigh = Color(0xFF1A3158)
val NavyOutline = Color(0xFF254273)

val ElectricBlue = Color(0xFF2979FF)
val ElectricBlueSoft = Color(0xFF5393FF)
val ElectricBlueContainer = Color(0xFF10316B)

val CyanAccent = Color(0xFF00E5FF)
val CyanSoft = Color(0xFF6EFFFF)
val CyanContainer = Color(0xFF063A4D)

val TealMeshOnline = Color(0xFF00E676)
val AmberRelaying = Color(0xFFFFAB40)
val CoralAlert = Color(0xFFFF5252)

val TextPrimary = Color(0xFFF1F6FF)
val TextSecondary = Color(0xFFA7B8D6)
val TextMuted = Color(0xFF6E84AB)
