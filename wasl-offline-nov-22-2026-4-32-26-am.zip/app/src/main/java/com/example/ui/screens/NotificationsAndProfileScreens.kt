package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.NotificationEntity
import com.example.data.local.NotificationType
import com.example.data.local.UserSettings
import com.example.localization.AppLanguage
import com.example.localization.LocalStrings
import com.example.ui.IdentityUi
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.WaslCard
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    notifications: List<NotificationEntity>,
    onBack: () -> Unit,
    onMarkAllRead: () -> Unit,
    onAcceptContactRequest: (nodeId: String, notificationId: String) -> Unit,
    onRejectContactRequest: (nodeId: String, notificationId: String) -> Unit,
    onOpenConversation: (String) -> Unit
) {
    val strings = LocalStrings.current
    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = NavyBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back)
                    }
                },
                title = { Text(strings.notificationsTitle) },
                actions = {
                    if (notifications.isNotEmpty()) {
                        TextButton(onClick = onMarkAllRead) {
                            Text(strings.markAllRead, color = CyanAccent)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (notifications.isEmpty()) {
            EmptyStatePanel(
                icon = Icons.Rounded.NotificationsNone,
                title = strings.noNotificationsTitle,
                body = strings.noNotificationsBody,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notifications, key = { it.id }) { notif ->
                    WaslCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = notif.relatedConversationId != null) {
                                notif.relatedConversationId?.let(onOpenConversation)
                            },
                        borderColor = if (!notif.isRead) CyanAccent.copy(alpha = 0.65f) else NavyOutline
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(notif.title, style = MaterialTheme.typography.titleMedium)
                                Text(formatTimestamp(notif.timestamp), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                            Text(notif.body, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                            if (notif.type == NotificationType.CONTACT_REQUEST.name &&
                                !notif.actionHandled &&
                                notif.relatedNodeId != null
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { onAcceptContactRequest(notif.relatedNodeId, notif.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = TealMeshOnline, contentColor = Color.Black)
                                    ) {
                                        Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.acceptRequest)
                                    }
                                    OutlinedButton(
                                        onClick = { onRejectContactRequest(notif.relatedNodeId, notif.id) }
                                    ) {
                                        Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.rejectRequest)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    settings: UserSettings,
    identity: IdentityUi,
    onBack: () -> Unit,
    onUpdateDisplayName: (String) -> Unit,
    onLanguageChange: (AppLanguage) -> Unit,
    onRelayToggle: (Boolean) -> Unit,
    onBatterySaverToggle: (Boolean) -> Unit
) {
    val strings = LocalStrings.current
    val context = LocalContext.current
    var nameDraft by remember(settings.displayName) { mutableStateOf(settings.displayName) }

    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = NavyBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back)
                    }
                },
                title = { Text(strings.profileTitle) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Identity Card
            WaslCard(modifier = Modifier.fillMaxWidth(), containerColor = NavySurfaceElevated) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Person, contentDescription = null, tint = CyanAccent)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.nodeIdLabel, style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    }
                    Text(identity.nodeId, style = MaterialTheme.typography.headlineSmall, color = CyanAccent)

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = TealMeshOnline, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(strings.securityFingerprintLabel, style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    }
                    Text(identity.fingerprint, style = MaterialTheme.typography.labelSmall, color = TealMeshOnline)

                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("fingerprint", "${identity.nodeId}\n${identity.fingerprint}"))
                            Toast.makeText(context, strings.copiedToast, Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.copyFingerprint)
                    }
                }
            }

            // Edit Display Name
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nameDraft,
                        onValueChange = { nameDraft = it },
                        label = { Text(strings.displayNameLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (nameDraft.trim().length >= 2) {
                                onUpdateDisplayName(nameDraft.trim())
                                Toast.makeText(context, strings.savedToast, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(strings.saveNameBtn)
                    }
                }
            }

            // Language Switcher
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Language, contentDescription = null, tint = CyanAccent)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.languageSelectLabel, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            val selected = settings.language == lang
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (selected) ElectricBlue.copy(alpha = 0.25f) else NavySurfaceElevated)
                                    .border(1.dp, if (selected) CyanAccent else NavyOutline, RoundedCornerShape(12.dp))
                                    .clickable { onLanguageChange(lang) }
                                    .padding(vertical = 12.dp)
                                    .testTag("profile_lang_${lang.code}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = lang.nativeLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) CyanAccent else TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Mesh Node Role & Battery Scan
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Hub, contentDescription = null, tint = CyanAccent)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.relayNodeToggleTitle, style = MaterialTheme.typography.titleMedium)
                            Text(strings.relayNodeToggleDesc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = settings.relayEnabled, onCheckedChange = onRelayToggle)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.BatterySaver, contentDescription = null, tint = TealMeshOnline)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.batteryScanTitle, style = MaterialTheme.typography.titleMedium)
                            Text(strings.batteryScanDesc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = settings.batterySaverScan, onCheckedChange = onBatterySaverToggle)
                    }
                }
            }
        }
    }
}
