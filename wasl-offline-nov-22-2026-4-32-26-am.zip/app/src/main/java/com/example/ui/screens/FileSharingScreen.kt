package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.MessageType
import com.example.localization.LocalStrings
import com.example.ui.ConversationUi
import com.example.ui.MessageUi
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.StatusPill
import com.example.ui.components.WaslCard
import com.example.ui.components.formatBytes
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun FileSharingScreen(
    conversations: List<ConversationUi>,
    mediaTransfers: List<MessageUi>,
    onSendMediaToConversation: (ConversationUi, Uri, MessageType?) -> Unit,
    onOpenFile: (String, String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    var selectedConv by remember(conversations) { mutableStateOf(conversations.firstOrNull()) }

    val visualPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = selectedConv
        if (uri != null && target != null) {
            onSendMediaToConversation(target, uri, null)
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        val target = selectedConv
        if (uri != null && target != null) {
            onSendMediaToConversation(target, uri, MessageType.FILE)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            WaslCard(modifier = Modifier.fillMaxWidth(), containerColor = NavySurfaceElevated) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(strings.fileSharingTitle, style = MaterialTheme.typography.titleLarge)
                    Text(strings.bleLargeFileWarning, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

                    Text(strings.selectTargetPeer, style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                    if (conversations.isEmpty()) {
                        Text(strings.noConversationsBody, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    } else {
                        conversations.forEach { conv ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(NavySurface)
                                    .clickable { selectedConv = conv }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedConv?.conversationId == conv.conversationId,
                                    onClick = { selectedConv = conv }
                                )
                                Text(conv.title, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                visualPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                )
                            },
                            enabled = selectedConv != null,
                            modifier = Modifier.weight(1f).testTag("share_photo_video_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color.White)
                        ) {
                            Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.sendPhotoVideoBtn)
                        }
                        OutlinedButton(
                            onClick = { filePicker.launch(arrayOf("*/*")) },
                            enabled = selectedConv != null,
                            modifier = Modifier.weight(1f).testTag("share_any_file_button")
                        ) {
                            Icon(Icons.Rounded.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.sendAnyFileBtn)
                        }
                    }
                }
            }
        }

        item {
            Text(strings.recentTransfersTitle, style = MaterialTheme.typography.titleMedium)
        }

        if (mediaTransfers.isEmpty()) {
            item {
                EmptyStatePanel(
                    icon = Icons.Rounded.FolderOpen,
                    title = strings.recentTransfersTitle,
                    body = strings.noTransfersYet
                )
            }
        } else {
            items(mediaTransfers, key = { it.packetId }) { transfer ->
                val icon = when (transfer.messageType) {
                    MessageType.IMAGE -> Icons.Rounded.Image
                    MessageType.VIDEO -> Icons.Rounded.Videocam
                    MessageType.VOICE -> Icons.Rounded.Mic
                    else -> Icons.Rounded.AttachFile
                }
                WaslCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, contentDescription = null, tint = CyanAccent)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(transfer.mediaFileName ?: transfer.messageType.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${formatBytes(transfer.mediaSizeBytes)} • ${formatTimestamp(transfer.timestamp)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                            Spacer(Modifier.height(4.dp))
                            StatusPill(
                                label = transfer.deliveryStatus.name,
                                color = if (transfer.deliveryStatus.name.startsWith("DELIVERED")) TealMeshOnline else CyanAccent
                            )
                        }
                        transfer.mediaLocalPath?.let { path ->
                            IconButton(onClick = { onOpenFile(path, transfer.mediaMimeType) }) {
                                Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = strings.openFileBtn, tint = CyanAccent)
                            }
                        }
                    }
                }
            }
        }
    }
}
