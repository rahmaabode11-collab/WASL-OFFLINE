package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.localization.LocalStrings
import com.example.localization.stringsFor

private val WaslDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = TextPrimary,
    primaryContainer = ElectricBlueContainer,
    onPrimaryContainer = CyanSoft,
    secondary = CyanAccent,
    onSecondary = NavyVoid,
    secondaryContainer = CyanContainer,
    onSecondaryContainer = CyanSoft,
    tertiary = TealMeshOnline,
    onTertiary = NavyVoid,
    background = NavyBackground,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavySurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = NavyVoid,
    surfaceContainerLow = NavySurface,
    surfaceContainer = NavySurfaceElevated,
    surfaceContainerHigh = NavySurfaceHigh,
    outline = NavyOutline,
    outlineVariant = NavyOutline.copy(alpha = 0.5f),
    error = CoralAlert,
    onError = TextPrimary
)

private val WaslShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun WaslOfflineTheme(
    language: AppLanguage = AppLanguage.ARABIC,
    content: @Composable () -> Unit
) {
    val isArabic = language == AppLanguage.ARABIC
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
    val strings = stringsFor(language)

    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalStrings provides strings
    ) {
        MaterialTheme(
            colorScheme = WaslDarkColorScheme,
            typography = buildWaslTypography(isArabic = isArabic),
            shapes = WaslShapes,
            content = content
        )
    }
}
