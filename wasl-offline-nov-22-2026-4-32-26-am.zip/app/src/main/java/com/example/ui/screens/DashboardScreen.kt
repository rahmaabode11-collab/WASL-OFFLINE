package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.LocalStrings
import com.example.mesh.TechStatus
import com.example.mesh.TransportType
import com.example.ui.DashboardMetricsUi
import com.example.ui.components.MeshTopologyCanvas
import com.example.ui.components.StatusPill
import com.example.ui.components.WaslCard
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AmberRelaying
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun DashboardScreen(
    localNodeId: String,
    metrics: DashboardMetricsUi,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current

    val statusLabel = when {
        metrics.connectedDevicesCount > 0 -> strings.statusMeshOnline
        metrics.isMeshRunning -> strings.statusMeshStandby
        else -> strings.statusNoPeers
    }
    val statusColor = when {
        metrics.connectedDevicesCount > 0 -> TealMeshOnline
        metrics.isMeshRunning -> AmberRelaying
        else -> CoralAlert
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("network_dashboard_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Network Status Header + Topology
        item {
            WaslCard(modifier = Modifier.fillMaxWidth(), containerColor = NavySurfaceElevated) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.dashboardTitle, style = MaterialTheme.typography.titleLarge)
                            Text(localNodeId, style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                        }
                        StatusPill(label = statusLabel, color = statusColor)
                    }

                    MeshTopologyCanvas(
                        localNodeId = localNodeId,
                        peers = metrics.livePeers,
                        relayNodeIdsCount = metrics.activeRelayNodesCount,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(155.dp)
                    )

                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Rounded.Info, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = strings.meshDisclaimerNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Metrics Grid (2 columns)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile(
                        title = strings.connectedDevicesMetric,
                        value = metrics.connectedDevicesCount.toString(),
                        icon = Icons.Rounded.Devices,
                        accent = TealMeshOnline,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        title = strings.nearbyAvailableMetric,
                        value = metrics.nearbyAvailableCount.toString(),
                        icon = Icons.Rounded.NearMe,
                        accent = CyanAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile(
                        title = strings.activeRelayNodesMetric,
                        value = metrics.activeRelayNodesCount.toString(),
                        icon = Icons.Rounded.Hub,
                        accent = ElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        title = strings.messageHopsMetric,
                        value = String.format(Locale.US, "%.1f / %d", metrics.avgHops, metrics.maxHopsObserved),
                        icon = Icons.Rounded.Share,
                        accent = CyanAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile(
                        title = strings.pendingMessagesMetric,
                        value = metrics.pendingMessagesCount.toString(),
                        icon = Icons.Rounded.Schedule,
                        accent = AmberRelaying,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        title = strings.deliveredMessagesMetric,
                        value = metrics.deliveredMessagesCount.toString(),
                        icon = Icons.Rounded.CheckCircle,
                        accent = TealMeshOnline,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Last Successful Connection
        item {
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.lastConnectionMetric, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = if (metrics.lastSuccessfulConnectionAt > 0L) {
                            formatTimestamp(metrics.lastSuccessfulConnectionAt)
                        } else {
                            strings.neverConnected
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent
                    )
                }
            }
        }

        // Supported Technologies Matrix
        item {
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.supportedTechTitle, style = MaterialTheme.typography.titleMedium)
                    metrics.capabilities.forEach { cap ->
                        val techName = when (cap.type) {
                            TransportType.BLE -> strings.techBle
                            TransportType.BLUETOOTH_CLASSIC -> strings.techBtClassic
                            TransportType.WIFI_DIRECT -> strings.techWifiDirect
                            TransportType.NEARBY_CONNECTIONS -> strings.techNearbyConnections
                        }
                        val techIcon = when (cap.type) {
                            TransportType.BLE, TransportType.BLUETOOTH_CLASSIC -> Icons.Rounded.Bluetooth
                            TransportType.WIFI_DIRECT -> Icons.Rounded.WifiTethering
                            TransportType.NEARBY_CONNECTIONS -> Icons.Rounded.NearMe
                        }
                        val (stateText, stateColor) = when (cap.status) {
                            TechStatus.READY -> strings.techAvailableReady to TealMeshOnline
                            TechStatus.DISABLED -> strings.techDisabled to AmberRelaying
                            TechStatus.NEEDS_PERMISSION -> strings.techNeedsPermission to CyanAccent
                            TechStatus.UNSUPPORTED -> strings.techUnsupported to CoralAlert
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(techIcon, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(techName, style = MaterialTheme.typography.bodyMedium)
                            }
                            StatusPill(label = stateText, color = stateColor)
                        }
                    }
                }
            }
        }

        // Observed Multi-Hop Routes
        item {
            Text(strings.activeRoutesTitle, style = MaterialTheme.typography.titleMedium)
        }
        if (metrics.recentRoutes.isEmpty()) {
            item {
                WaslCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = strings.noActiveRoutesBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(metrics.recentRoutes, key = { it.packetId }) { routed ->
                WaslCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(routed.senderName, style = MaterialTheme.typography.titleMedium)
                            StatusPill(label = "${routed.hopCount} ${strings.hopsUnit}", color = CyanAccent)
                        }
                        Text(
                            text = routed.routePath.joinToString(" → ").ifBlank { routed.transportUsed },
                            style = MaterialTheme.typography.labelSmall,
                            color = TealMeshOnline
                        )
                        Text(
                            text = formatTimestamp(routed.timestamp),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    WaslCard(modifier = modifier) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
                Text(value, style = MaterialTheme.typography.headlineSmall, color = accent)
            }
            Text(title, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
    }
}
