package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.EnhancedEncryption
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ContactEntity
import com.example.data.local.UserSettings
import com.example.localization.LocalStrings
import com.example.ui.components.WaslCard
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TealMeshOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecuritySettingsScreen(
    settings: UserSettings,
    blockedContacts: List<ContactEntity>,
    onBack: () -> Unit,
    onRequireApprovalToggle: (Boolean) -> Unit,
    onMaxHopsChange: (Int) -> Unit,
    onExpiryHoursChange: (Int) -> Unit,
    onUnblockUser: (String) -> Unit,
    onRotateKeys: () -> Unit,
    onWipeAllData: () -> Unit
) {
    val strings = LocalStrings.current
    var showWipeDialog by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = NavyBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back)
                    }
                },
                title = { Text(strings.securityTitle) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Cryptographic Protections Status
            WaslCard(modifier = Modifier.fillMaxWidth(), containerColor = NavySurfaceElevated) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = TealMeshOnline)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(strings.e2eeActiveTitle, style = MaterialTheme.typography.titleMedium, color = TealMeshOnline)
                            Text(strings.e2eeActiveDesc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Rounded.EnhancedEncryption, contentDescription = null, tint = CyanAccent)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(strings.localEncryptionTitle, style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                            Text(strings.localEncryptionDesc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                }
            }

            // Contact Approval Policy & Hop / Expiry Tuning
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.requireApprovalTitle, style = MaterialTheme.typography.titleMedium)
                            Text(strings.requireApprovalDesc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = settings.requireContactApproval, onCheckedChange = onRequireApprovalToggle)
                    }

                    Text("${strings.maxHopsTitle}: ${settings.maxHops}", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = settings.maxHops.toFloat(),
                        onValueChange = { onMaxHopsChange(it.roundToInt()) },
                        valueRange = 1f..8f,
                        steps = 6
                    )

                    Text(strings.messageExpiryTitle, style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(6, 24, 48, 72).forEach { hrs ->
                            FilterChip(
                                selected = settings.messageTtlHours == hrs,
                                onClick = { onExpiryHoursChange(hrs) },
                                label = { Text("$hrs ${strings.hoursUnit}") }
                            )
                        }
                    }
                }
            }

            // Blocked Users
            WaslCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Block, contentDescription = null, tint = CoralAlert)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.blockedUsersTitle, style = MaterialTheme.typography.titleMedium)
                    }
                    if (blockedContacts.isEmpty()) {
                        Text(strings.noBlockedUsers, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    } else {
                        blockedContacts.forEach { blocked ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(blocked.displayName, style = MaterialTheme.typography.bodyMedium)
                                    Text(blocked.nodeId, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                                TextButton(onClick = { onUnblockUser(blocked.nodeId) }) {
                                    Text(strings.unblockUser, color = CyanAccent)
                                }
                            }
                        }
                    }
                }
            }

            // Key Rotation & Wipe
            OutlinedButton(
                onClick = onRotateKeys,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("rotate_keys_button")
            ) {
                Icon(Icons.Rounded.Key, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(strings.rotateKeysBtn)
            }

            Button(
                onClick = { showWipeDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CoralAlert, contentColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("wipe_data_button")
            ) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(strings.wipeDataBtn)
            }
        }
    }

    if (showWipeDialog) {
        AlertDialog(
            onDismissRequest = { showWipeDialog = false },
            containerColor = NavySurfaceElevated,
            title = { Text(strings.wipeDataConfirmTitle) },
            text = { Text(strings.wipeDataConfirmBody, color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        showWipeDialog = false
                        onWipeAllData()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CoralAlert, contentColor = Color.White)
                ) {
                    Text(strings.confirmBtn)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeDialog = false }) { Text(strings.cancelBtn) }
            }
        )
    }
}
