package com.example

import com.example.crypto.CryptoManager
import com.example.mesh.MeshPacket
import com.example.mesh.MeshRouter
import com.example.mesh.PacketType
import com.example.mesh.RouteDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MeshRouterTest {

    @Test
    fun `multi-hop relay forwards packet, records route path, and prevents duplicate replay`() {
        val alice = CryptoManager.generateIdentity()
        val relay = CryptoManager.generateIdentity()
        val bob = CryptoManager.generateIdentity()

        val aliceRouter = MeshRouter(alice)
        val relayRouter = MeshRouter(relay)
        val bobRouter = MeshRouter(bob)

        val now = 1_700_000_000_000L
        val ciphertext = CryptoManager.encryptForPeer(
            "Hello Bob".toByteArray(),
            alice.ecdhPrivateKey,
            bob.ecdhPublicKeyB64
        )
        val packet = aliceRouter.signOutgoingPacket(
            MeshPacket(
                packetType = PacketType.CHAT_MESSAGE.name,
                originNodeId = alice.nodeId,
                destinationNodeId = bob.nodeId,
                senderDisplayName = "Alice",
                senderSigningPubKeyB64 = alice.signingPublicKeyB64,
                senderEcdhPubKeyB64 = alice.ecdhPublicKeyB64,
                hopCount = 0,
                maxHops = 5,
                createdAt = now,
                expiresAt = now + 3_600_000L,
                encryptedPayloadB64 = ciphertext
            )
        )

        // Relay node receives packet destined for Bob
        val relayDecision = relayRouter.evaluateIncomingPacket(
            packet = packet,
            now = now + 100,
            alreadySeenInDb = false,
            isOriginBlocked = false,
            relayEnabled = true,
            localGroupIds = emptySet()
        )
        assertTrue(relayDecision is RouteDecision.RelayOnly)
        val forwarded = (relayDecision as RouteDecision.RelayOnly).forwardedPacket
        assertEquals(1, forwarded.hopCount)
        assertEquals(listOf(relay.nodeId), forwarded.routePath)

        // Duplicate arrival at Relay is dropped
        val dupDecision = relayRouter.evaluateIncomingPacket(
            packet = packet,
            now = now + 200,
            alreadySeenInDb = false,
            isOriginBlocked = false,
            relayEnabled = true,
            localGroupIds = emptySet()
        )
        assertTrue(dupDecision is RouteDecision.DropDuplicateOrExpired)

        // Bob receives forwarded packet, verifies original signature intact despite hop increment
        val bobDecision = bobRouter.evaluateIncomingPacket(
            packet = forwarded,
            now = now + 300,
            alreadySeenInDb = false,
            isOriginBlocked = false,
            relayEnabled = true,
            localGroupIds = emptySet()
        )
        assertTrue(bobDecision is RouteDecision.DeliverLocally)
        val delivered = (bobDecision as RouteDecision.DeliverLocally).packet
        assertEquals(1, delivered.hopCount)
        assertEquals(listOf(relay.nodeId), delivered.routePath)

        val ack = bobRouter.buildDeliveryAck(delivered, alice.ecdhPublicKeyB64, now + 400)
        assertEquals(alice.nodeId, ack.destinationNodeId)
        assertEquals(PacketType.DELIVERY_ACK.name, ack.packetType)
    }

    @Test
    fun `expired or tampered or blocked packets are rejected`() {
        val alice = CryptoManager.generateIdentity()
        val relay = CryptoManager.generateIdentity()
        val bob = CryptoManager.generateIdentity()
        val aliceRouter = MeshRouter(alice)
        val relayRouter = MeshRouter(relay)
        val now = 1_700_000_000_000L

        val signed = aliceRouter.signOutgoingPacket(
            MeshPacket(
                packetType = PacketType.CHAT_MESSAGE.name,
                originNodeId = alice.nodeId,
                destinationNodeId = bob.nodeId,
                senderDisplayName = "Alice",
                senderSigningPubKeyB64 = alice.signingPublicKeyB64,
                senderEcdhPubKeyB64 = alice.ecdhPublicKeyB64,
                maxHops = 4,
                createdAt = now,
                expiresAt = now + 1000L,
                encryptedPayloadB64 = "ZmFrZQ=="
            )
        )

        // Tampered ciphertext fails ECDSA verification
        val tampered = signed.copy(encryptedPayloadB64 = "dGFtcGVyZWQ=")
        assertTrue(
            relayRouter.evaluateIncomingPacket(tampered, now + 10, false, false, true, emptySet())
                is RouteDecision.DropInvalidSignature
        )

        // Expired packet is dropped
        assertTrue(
            relayRouter.evaluateIncomingPacket(signed, now + 5000L, false, false, true, emptySet())
                is RouteDecision.DropDuplicateOrExpired
        )

        // Blocked origin is dropped
        assertTrue(
            relayRouter.evaluateIncomingPacket(signed, now + 10, false, true, true, emptySet())
                is RouteDecision.DropBlockedOrigin
        )
    }
}
