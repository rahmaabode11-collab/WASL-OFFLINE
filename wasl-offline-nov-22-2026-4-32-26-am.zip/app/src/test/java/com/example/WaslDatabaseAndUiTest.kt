package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextReplacement
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ContactEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.MessageEntity
import com.example.data.local.RelationshipStatus
import com.example.data.local.WaslDatabase
import com.example.localization.AppLanguage
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.WaslOfflineTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WaslDatabaseAndUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var db: WaslDatabase

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, WaslDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `room stores contacts and encrypted messages with hop status`() = runTest {
        db.contactDao().upsert(
            ContactEntity(
                nodeId = "WSL-AA11-BB22",
                displayName = "Zaid",
                signingPubKeyB64 = "pub1",
                ecdhPubKeyB64 = "ecdh1",
                fingerprint = "AA:BB",
                relationshipStatus = RelationshipStatus.APPROVED.name
            )
        )
        val approved = db.contactDao().observeApprovedContacts().first()
        assertEquals(1, approved.size)
        assertEquals("Zaid", approved[0].displayName)

        db.messageDao().upsert(
            MessageEntity(
                packetId = "pkt-1",
                conversationId = "peer:WSL-AA11-BB22",
                senderNodeId = "WSL-ME",
                senderName = "Me",
                contentEnc = "enc:v1:abc",
                timestamp = 1000L,
                expiresAt = 5000L,
                deliveryStatus = DeliveryStatus.DELIVERED_MESH.name,
                hopCount = 2,
                routePathJson = "[\"WSL-R1\",\"WSL-AA11-BB22\"]",
                isOutgoing = true
            )
        )
        val delivered = db.messageDao().observeDeliveredCount().first()
        assertEquals(1, delivered)
    }

    @Test
    fun `welcome screen supports language switch and registration callback`() {
        var registeredName = ""
        val selectedLang = androidx.compose.runtime.mutableStateOf(AppLanguage.ARABIC)

        composeRule.setContent {
            WaslOfflineTheme(language = selectedLang.value) {
                WelcomeScreen(
                    currentLanguage = selectedLang.value,
                    hasMissingPermissions = false,
                    onLanguageChange = { selectedLang.value = it },
                    onRequestPermissions = {},
                    onCompleteRegistration = { registeredName = it }
                )
            }
        }

        composeRule.onNodeWithTag("lang_option_en").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(AppLanguage.ENGLISH, selectedLang.value)

        composeRule.onNodeWithTag("registration_name_input").performScrollTo()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("registration_name_input").performTextReplacement("Tariq")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("complete_registration_button").performScrollTo()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("complete_registration_button").performClick()
        composeRule.waitForIdle()

        assertEquals("Tariq", registeredName)
        composeRule.onNodeWithTag("complete_registration_button").assertIsDisplayed()
    }

    @Test
    fun `android viewmodel factory creates WaslViewModel and MainActivity launches cleanly`() {
        val app = ApplicationProvider.getApplicationContext<WaslApplication>()
        val vm = androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory
            .getInstance(app)
            .create(com.example.ui.WaslViewModel::class.java)
        org.junit.Assert.assertTrue(vm.identityUi.value.nodeId.startsWith("WSL-"))

        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        org.junit.Assert.assertNotNull(controller.get())
        controller.pause().stop().destroy()
    }
}
