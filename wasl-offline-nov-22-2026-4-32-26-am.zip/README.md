# WASL OFFLINE

Decentralized offline Android mesh communication application built with Kotlin, Jetpack Compose, Material 3, Room, and Android Keystore cryptography.

## Core Capabilities
- **Zero Internet Requirement:** Works offline using **Bluetooth Low Energy (BLE)**, **Bluetooth Classic (RFCOMM)**, **Wi-Fi Direct (Wi-Fi P2P)**, and **Android Nearby Connections (`P2P_CLUSTER`)**.
- **Multi-Hop Store-and-Forward Mesh:** Intermediate smartphones relay signed, end-to-end encrypted packets across multiple hops (`maxHops` configurable 1–8), prevent duplicate loops via Room `seen_packets` + LRU deduplication, expire undelivered packets cleanly, and report exact hop counts and relay routes via signed `DELIVERY_ACK` packets.
- **End-to-End Security:** ECDSA P-256 packet signatures, ECDH P-256 + HKDF-SHA256 + AES-256-GCM pairwise and group encryption, Android Keystore key wrapping, encrypted local Room message fields, contact approval gating, and peer blocking.
- **Rich Offline Messaging:** 1-to-1 and group conversations, text, AAC voice notes, Photo Picker image/video sharing, Storage Access Framework file sharing, and local offline notifications.
- **Bilingual UI:** Full **Arabic (RTL)** and **English (LTR)** interfaces with a dark navy, electric blue, and cyan theme.

## Documentation
- [Installation & APK Build Guide](docs/INSTALLATION.md)
- [Automated & Multi-Device Testing Guide](docs/TESTING_GUIDE.md)
