# WASL OFFLINE — Installation & Build Guide

## Prerequisites
- **Android Studio** Ladybug / Meerkat or newer with JDK 17+ and Android SDK 36.
- **2 or more physical Android smartphones** (Android 7.0 / API 24 or higher; Android 12+ recommended for modern Nearby/BLE permissions).
- **No internet connection, SIM card, or Wi-Fi router required** during operation.

## Building the Installable APK
1. Open the project folder in Android Studio, or run from the project root terminal:
   ```bash
   gradle :app:assembleDebug
   ```
2. The installable APK is generated at:
   `app/build/outputs/apk/debug/app-debug.apk`
3. For a signed release APK/AAB, configure `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` environment variables and run:
   ```bash
   gradle :app:assembleRelease
   ```

## Installing on Multiple Physical Devices
1. Enable **USB Debugging** on each Android test phone (or transfer `app-debug.apk` via USB/local file manager and allow "Install unknown apps").
2. Install via ADB from a computer:
   ```bash
   adb -s <DEVICE_SERIAL_1> install -r app/build/outputs/apk/debug/app-debug.apk
   adb -s <DEVICE_SERIAL_2> install -r app/build/outputs/apk/debug/app-debug.apk
   adb -s <DEVICE_SERIAL_3> install -r app/build/outputs/apk/debug/app-debug.apk
   ```
3. On first launch on each device:
   - Select **العربية (RTL)** or **English (LTR)**.
   - Grant the **Nearby devices** (Bluetooth & Nearby Wi-Fi) and **Notifications** permissions when prompted.
   - Enter a display name and tap **Create Hardware Identity & Start** to generate hardware-backed ECDSA/ECDH keys in Android Keystore.
4. Ensure **Bluetooth** and **Wi-Fi** are turned ON (devices do **not** need to be connected to any Wi-Fi access point or cellular network).
5. On Android devices with aggressive OEM battery savers, optionally allow unrestricted background activity for `WASL OFFLINE` so `MeshForegroundService` can maintain continuous relay forwarding.
