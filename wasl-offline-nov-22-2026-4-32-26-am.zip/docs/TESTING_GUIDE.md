# WASL OFFLINE — Testing & Verification Guide

## 1. Automated Local Tests (JVM + Robolectric)
Run all unit and Robolectric tests locally without an emulator:
```bash
gradle :app:testDebugUnitTest
```
Covered test suites:
- **`CryptoManagerTest`**: ECDSA P-256 signature verification, tamper rejection, ECDH P-256 + HKDF-SHA256 + AES-256-GCM end-to-end encryption, third-party decryption rejection, and `LocalStorageCipher` at-rest database encryption.
- **`MeshRouterTest`**: Multi-hop forwarding (`hopCount` increment & `routePath` recording), duplicate `packetId` loop suppression, `DELIVERY_ACK` route reporting, tampered packet drop, TTL expiration rejection, and blocked node filtering.
- **`WaslDatabaseAndUiTest`**: In-memory Room DAO verification for contacts, conversations, and routed messages, plus Jetpack Compose UI test for language switching (Arabic RTL / English LTR) and registration.

## 2. Multi-Device Physical Testing Protocol

### Test A — Direct 2-Phone Offline Messaging & Media Transfer
1. Enable Airplane Mode on **Phone A** and **Phone B**, then re-enable **Bluetooth** and **Wi-Fi** (without joining any Wi-Fi network).
2. Open **WASL OFFLINE** on both phones and navigate to **Nearby Devices**.
3. Tap **Scan Now** on Phone A. Phone B appears with its `WSL-XXXX-XXXX` Node ID and active transport badge (`NEARBY`, `WIFI_DIRECT`, `BT_CLASSIC`, or `BLE`).
4. Send a Contact Request from Phone A and **Accept** it on Phone B (in Nearby Devices or Notifications).
5. Send a text message, a voice note (`RECORD_AUDIO`), an image (Android Photo Picker), and a document (SAF) from Phone A to Phone B.
6. Verify:
   - Message arrives on Phone B with a local notification.
   - Phone A shows `Delivered Directly` (`0 hops`).
   - **Mesh Hub (Dashboard)** increments `Connected Devices` and `Delivered Messages`.

### Test B — 3-Phone Multi-Hop Mesh Relay (No Direct Link Between A & C)
1. Place **Phone A** and **Phone C** out of direct Bluetooth/Wi-Fi Direct range of each other (e.g., opposite ends of a building/corridor).
2. Place **Phone B** midway between A and C with **Act as Mesh Relay Node** enabled in **Profile**.
3. Send a message from Phone A to Phone C (assuming C was previously approved when nearby, or via group chat).
4. Verify:
   - Phone A transmits to Phone B.
   - Phone B stores and relays the packet to Phone C without being able to decrypt the payload.
   - Phone C decrypts the message and emits a `DELIVERY_ACK`.
   - Phone A displays `Delivered via Mesh` with `1 hop` and tapping the bubble shows the actual route: `WSL-B -> WSL-C`.

### Test C — Store-and-Forward Delayed Delivery & Expiration
1. Power off or isolate **Phone C** completely.
2. Send a message from **Phone A** to **Phone C**. Verify status starts as `Queued Offline` (`Pending Queue = 1` on Dashboard).
3. Bring **Phone C** back into range of Phone A (or Phone B). Within 15–45 seconds, the pending packet is flushed and delivered, updating Phone A's message status to Delivered.
4. To test expiration: set **Pending Message Expiration** in **Security Settings**, keep the recipient unreachable past expiration, and verify the status transitions to `Expired Undelivered` with the explanation that additional relay phones are needed.
