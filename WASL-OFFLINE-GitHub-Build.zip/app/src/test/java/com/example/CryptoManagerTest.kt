package com.example

import com.example.crypto.CryptoManager
import com.example.crypto.LocalStorageCipher
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CryptoManagerTest {

    @Test
    fun `identity generation produces deterministic nodeId and valid ECDSA signature`() {
        val alice = CryptoManager.generateIdentity()
        assertTrue(alice.nodeId.startsWith("WSL-"))
        assertEquals(alice.nodeId, CryptoManager.deriveNodeId(alice.signingPublicKeyB64))

        val payload = "WASL-PACKET-CANONICAL".toByteArray(Charsets.UTF_8)
        val sig = CryptoManager.signData(payload, alice.signingPrivateKey)
        assertTrue(CryptoManager.verifySignature(payload, sig, alice.signingPublicKeyB64))

        val tampered = "WASL-PACKET-MODIFIED".toByteArray(Charsets.UTF_8)
        assertFalse(CryptoManager.verifySignature(tampered, sig, alice.signingPublicKeyB64))
    }

    @Test
    fun `ECDH pairwise encryption roundtrips and rejects third party`() {
        val alice = CryptoManager.generateIdentity()
        val bob = CryptoManager.generateIdentity()
        val eve = CryptoManager.generateIdentity()

        val message = "مرحباً من الشبكة المحلية أوفلاين".toByteArray(Charsets.UTF_8)
        val ciphertext = CryptoManager.encryptForPeer(
            plaintext = message,
            myEcdhPrivate = alice.ecdhPrivateKey,
            peerEcdhPublicB64 = bob.ecdhPublicKeyB64
        )

        val decryptedByBob = CryptoManager.decryptFromPeer(
            payloadB64 = ciphertext,
            myEcdhPrivate = bob.ecdhPrivateKey,
            peerEcdhPublicB64 = alice.ecdhPublicKeyB64
        )
        assertArrayEquals(message, decryptedByBob)

        val eveFailed = runCatching {
            CryptoManager.decryptFromPeer(
                payloadB64 = ciphertext,
                myEcdhPrivate = eve.ecdhPrivateKey,
                peerEcdhPublicB64 = alice.ecdhPublicKeyB64
            )
        }.isFailure
        assertTrue(eveFailed)
    }

    @Test
    fun `local storage cipher encrypts at rest and decrypts cleanly`() {
        val key = CryptoManager.generateAes256Key()
        val cipher = LocalStorageCipher { key }
        val secretText = "Encrypted local message content"
        val stored = cipher.encryptText(secretText)

        assertNotEquals(secretText, stored)
        assertTrue(stored.startsWith("enc:v1:"))
        assertEquals(secretText, cipher.decryptText(stored))
    }
}
