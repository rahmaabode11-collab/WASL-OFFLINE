package com.example.crypto

import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class DeviceIdentityKeys(
    val nodeId: String,
    val fingerprint: String,
    val signingPublicKeyB64: String,
    val signingPrivateKey: PrivateKey,
    val ecdhPublicKeyB64: String,
    val ecdhPrivateKey: PrivateKey
)

object CryptoManager {
    private const val EC_CURVE = "secp256r1"
    private const val SIGN_ALGO = "SHA256withECDSA"
    private const val AES_GCM = "AES/GCM/NoPadding"
    private const val GCM_IV_BYTES = 12
    private const val GCM_TAG_BITS = 128
    private val secureRandom = SecureRandom()

    fun generateIdentity(): DeviceIdentityKeys {
        val signingPair = generateEcKeyPair()
        val ecdhPair = generateEcKeyPair()
        val signingPubB64 = encodeKey(signingPair.public.encoded)
        val ecdhPubB64 = encodeKey(ecdhPair.public.encoded)
        return DeviceIdentityKeys(
            nodeId = deriveNodeId(signingPubB64),
            fingerprint = deriveFingerprint(signingPubB64),
            signingPublicKeyB64 = signingPubB64,
            signingPrivateKey = signingPair.private,
            ecdhPublicKeyB64 = ecdhPubB64,
            ecdhPrivateKey = ecdhPair.private
        )
    }

    fun generateEcKeyPair(): KeyPair {
        val gen = KeyPairGenerator.getInstance("EC")
        gen.initialize(ECGenParameterSpec(EC_CURVE), secureRandom)
        return gen.generateKeyPair()
    }

    fun decodePublicKey(base64: String): PublicKey {
        val bytes = Base64.getDecoder().decode(base64)
        return KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(bytes))
    }

    fun decodePrivateKey(bytes: ByteArray): PrivateKey {
        return KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(bytes))
    }

    fun encodeKey(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    fun deriveNodeId(signingPublicKeyB64: String): String {
        val digest = sha256(Base64.getDecoder().decode(signingPublicKeyB64))
        val part1 = "%02X%02X".format(digest[0], digest[1])
        val part2 = "%02X%02X".format(digest[2], digest[3])
        return "WSL-$part1-$part2"
    }

    fun deriveFingerprint(signingPublicKeyB64: String): String {
        val digest = sha256(Base64.getDecoder().decode(signingPublicKeyB64))
        return digest.take(16).joinToString(":") { "%02X".format(it) }
    }

    fun signData(data: ByteArray, privateKey: PrivateKey): String {
        val sig = Signature.getInstance(SIGN_ALGO)
        sig.initSign(privateKey, secureRandom)
        sig.update(data)
        return Base64.getEncoder().encodeToString(sig.sign())
    }

    fun verifySignature(data: ByteArray, signatureB64: String, publicKeyB64: String): Boolean {
        return try {
            val pubKey = decodePublicKey(publicKeyB64)
            val sigBytes = Base64.getDecoder().decode(signatureB64)
            val sig = Signature.getInstance(SIGN_ALGO)
            sig.initVerify(pubKey)
            sig.update(data)
            sig.verify(sigBytes)
        } catch (_: Exception) {
            false
        }
    }

    fun derivePairwiseAesKey(
        myEcdhPrivate: PrivateKey,
        peerEcdhPublicB64: String,
        contextInfo: ByteArray = "WASL-E2EE-V1".toByteArray(Charsets.UTF_8)
    ): SecretKey {
        val peerPub = decodePublicKey(peerEcdhPublicB64)
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(myEcdhPrivate)
        agreement.doPhase(peerPub, true)
        val sharedSecret = agreement.generateSecret()
        val keyBytes = hkdfSha256(
            ikm = sharedSecret,
            salt = "WASL-SALT-2026".toByteArray(Charsets.UTF_8),
            info = contextInfo,
            length = 32
        )
        return SecretKeySpec(keyBytes, "AES")
    }

    fun encryptForPeer(
        plaintext: ByteArray,
        myEcdhPrivate: PrivateKey,
        peerEcdhPublicB64: String,
        aad: ByteArray? = null
    ): String {
        val aesKey = derivePairwiseAesKey(myEcdhPrivate, peerEcdhPublicB64)
        return encryptAesGcm(plaintext, aesKey, aad)
    }

    fun decryptFromPeer(
        payloadB64: String,
        myEcdhPrivate: PrivateKey,
        peerEcdhPublicB64: String,
        aad: ByteArray? = null
    ): ByteArray {
        val aesKey = derivePairwiseAesKey(myEcdhPrivate, peerEcdhPublicB64)
        return decryptAesGcm(payloadB64, aesKey, aad)
    }

    fun generateAes256Key(): SecretKey {
        val bytes = ByteArray(32)
        secureRandom.nextBytes(bytes)
        return SecretKeySpec(bytes, "AES")
    }

    fun encryptAesGcm(plaintext: ByteArray, key: SecretKey, aad: ByteArray? = null): String {
        val iv = ByteArray(GCM_IV_BYTES)
        secureRandom.nextBytes(iv)
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        if (aad != null) cipher.updateAAD(aad)
        val encrypted = cipher.doFinal(plaintext)
        val combined = ByteArray(iv.size + encrypted.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(encrypted, 0, combined, iv.size, encrypted.size)
        return Base64.getEncoder().encodeToString(combined)
    }

    fun decryptAesGcm(combinedB64: String, key: SecretKey, aad: ByteArray? = null): ByteArray {
        val combined = Base64.getDecoder().decode(combinedB64)
        require(combined.size > GCM_IV_BYTES) { "Invalid ciphertext length" }
        val iv = combined.copyOfRange(0, GCM_IV_BYTES)
        val ciphertext = combined.copyOfRange(GCM_IV_BYTES, combined.size)
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        if (aad != null) cipher.updateAAD(aad)
        return cipher.doFinal(ciphertext)
    }

    fun sha256(input: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(input)

    private fun hkdfSha256(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = mac.doFinal(ikm)

        val result = ByteArray(length)
        var t = ByteArray(0)
        var offset = 0
        var counter = 1
        while (offset < length) {
            mac.init(SecretKeySpec(prk, "HmacSHA256"))
            mac.update(t)
            mac.update(info)
            mac.update(counter.toByte())
            t = mac.doFinal()
            val copyLen = minOf(t.size, length - offset)
            System.arraycopy(t, 0, result, offset, copyLen)
            offset += copyLen
            counter++
        }
        return result
    }
}
